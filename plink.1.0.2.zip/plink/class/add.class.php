<?php

class add extends plink
{
	static public $settings;
	function __construct()
	{
		global $PLINK_CONFIG, $PLUGIN_CONFIG;
		
		self::$settings = parent::$settings;
		$this->sys = new sys;
		$this->img = new img;
		if (isset(self::$settings['vkAutoPosting']['isActiveVk']) && self::$settings['vkAutoPosting']['isActiveVk'] == 'on' && isset(self::$settings['vkAutoPosting']['vkGroupId']) && isset(self::$settings['vkAutoPosting']['vkGroupSecret']) && isset(self::$settings['vkAutoPosting']['vkAppId']))
			$this->apivk 			= new apivk;
	}
	
	function insertPostToWp($post)
	{
		global $PLUGIN_CONFIG;
		
		$post_time						= date("Y-m-d H:i:s", time() + ($post['timePostMinus'] * 60));
		if (!isset($post['post_title']) || !isset($post['post_content']))
			return FALSE;
		
		if (!isset($post['post_logo']))
			$post['post_logo'] = '';
		//file_put_contents('test.txt', json_encode($post));
		$post_ar					= array(
			'comment_status'			=> $post['comment_status'], 
			'ping_status'				=> $post['ping_status'],
			'post_author'				=> (isset($post['post_author']) ? $post['post_author'] : ''),
			'post_date'					=> $post_time,
			'post_date_gmt'				=> $post_time,
			'post_title'				=> $this->sys->clean_trash($post['post_title']),
			'post_name'					=> $this->sys->clean_trash($post['post_name']),
			'post_content'				=> $this->sys->clean_trash($post['post_content']),
			'post_category'				=> (isset($post['post_category']) ? $post['post_category'] : ''),
			'post_status'				=> $post['post_status'], 
			'post_type' 				=> $post['post_type'],
			'tags_input'     			=> (isset($post['tags_input']) ? $post['tags_input'] : ''),
			'meta_input'				=> (isset($post['meta_input']) ? $post['meta_input'] : '')
		);
		//file_put_contents('test.txt', json_encode($post_ar));
		remove_filter('content_save_pre', 'wp_filter_post_kses');
  		remove_filter('content_filtered_save_pre', 'wp_filter_post_kses');
		
		$parent_post_id = wp_insert_post($post_ar, true);
		
//		print_r($post);
//		exit();
		if ($parent_post_id)
			return $parent_post_id;
		return false;
	}
	
	function insertPostToVk($parent_post_id)
	{
		global $PLUGIN_CONFIG;
		
		if (isset(self::$settings['vkAutoPosting']['isActiveVk']) && self::$settings['vkAutoPosting']['isActiveVk'] == 'on' && isset(self::$settings['vkAutoPosting']['vkGroupId']) && isset(self::$settings['vkAutoPosting']['vkGroupSecret']) && isset(self::$settings['vkAutoPosting']['vkAppId']))
		{
			if ($parent_post_id)
			{
				$time_file = $_SERVER['DOCUMENT_ROOT'] . $PLUGIN_CONFIG['time_file'];
				$last_social_time = trim(file_get_contents($time_file));
				if ($last_social_time > 0 && ($last_social_time + $PLUGIN_CONFIG['social_time']) < time() && isset($this->apivk))
				{
					$this->apivk->setVkWall($parent_post_id);
					file_put_contents($time_file, time());
				}
			}
		}
	}
	
	function generatePostMetaThumbnails($post, $parent_post_id)
	{
		global $PLUGIN_CONFIG;
		
		if (!empty(self::$settings['postSettings']['zagFontSize']))
		{
			if (!$post['post_logo'])
				$post['post_logo'] = $PLUGIN_CONFIG['social_img_bg'];
			$attch_url 		= wp_get_attachment_url(get_post_thumbnail_id($parent_post_id));
			$vk_img 		= $this->img->get_social_img($post['post_logo'], $parent_post_id);
			$twit_fb_img 	= $this->img->get_social_img($post['post_logo'], $parent_post_id, true);
			update_post_meta($parent_post_id, 'vk_img', $vk_img);
			update_post_meta($parent_post_id, 'tw_fb', $twit_fb_img);
		}
	}
	
	function setPostThumbnail($post, $parent_post_id)
	{
		$filetype = wp_check_filetype( basename($post['post_logo']), NULL);
		$wp_upload_dir = wp_upload_dir();
		$attachment = array(
			'guid'           => $post['post_logo'] ,
			'post_mime_type' => $filetype['type'],
			'post_title'     => $this->sys->clean_trash($post['post_title']),
			'post_content'   => '',
			'post_status'    => 'inherit'
		);
		$attach_id 		= wp_insert_attachment($attachment, $post['post_logo'], $parent_post_id);
		$attach_url 	= wp_get_attachment_url($attach_id);
		require_once(ABSPATH.'wp-admin/includes/image.php');
		$attach_data 	= wp_generate_attachment_metadata($attach_id, $attach_url);
		wp_update_attachment_metadata($attach_id, $attach_data);
		set_post_thumbnail($parent_post_id, $attach_id);
	}
	
	function insert_post($post)
	{
		global $PLUGIN_CONFIG;
		
		if(!function_exists('wp_get_current_user')) 
			include(ABSPATH . "wp-includes/pluggable.php"); 
		$parent_post_id = $this->insertPostToWp($post);
		if(!empty($parent_post_id))
			$this->setPostThumbnail($post, $parent_post_id);
		if (!empty(self::$settings['postSettings']['zagFontSize']))
			$this->generatePostMetaThumbnails($post, $parent_post_id);
		if (self::$settings['vkAutoPosting']['isActiveVk'] == 'on')
			$this->insertPostToVk($parent_post_id);
		
		return ($parent_post_id);
	}
	
	function main()
	{
		global $CONF_POST;

		$api 				= new api;
		$post 				= $api->get_new_post();
		if (!$post)
			return FALSE;
		
	}
}