<?php
class ground
{
	function saveGroundSettings($arr)
	{	
		global $PLUGIN_CONFIG;
		
		$a										= array();
		$groundId								= $this->sys->array_val($arr, 'groundId');
		array_push($a, array("add" => 0, "selector" => "#popUpGroundSettings",  "class" => "-1", "className" => "saving"));
		if (!is_numeric($groundId))
			return ($this->sys->msg("Ошибка в параметре Ground ID", "Настройки площадки", 1, $a));/*--error--*/
			
		$json = json_decode($this->sys->api($PLUGIN_CONFIG['core'], array(array('action' => 'getGround', 'type' => 1, 'groundId' => $groundId))), true);
		if (!$json['getGround'][0]['ground_id'])
			return ($this->sys->msg("Площадка не найдена", "Настройки площадки", 1, $a));/*--error--*/
			
		$ground									= $json['getGround'][0];

		$groundSettings = json_decode($ground['paramsList'], true);
		$groundSettings = $groundSettings['groundSettings'];
			
/*		$groundUrl								= 'https://'.$ground['domain'].'/wp-content/plugins/plink/'.$this->sys->cleanVar($ground['hash']).'.php';
		$json 									= json_decode($this->sys->api($groundUrl, array(array('action' => 'checkFile'),array('action' => 'getWPUsers'), array('action' => 'getWPCategory'))), true);*/
		$wpUsers								= api::getWpUsers();
		$wpCategory								= api::getWpCategory();
			
		
		/*if ($ground['userId'] != $userId)
			return ($this->sys->msg("У вас нет прав для редактирования данной площадки", "Настройки площадки", 1, $a));/*--error--*/
			
		$inp 									= array('status', 'cutImg', 'cutIframe', 'imgBlur', 'imgMirror', 'watermarkPosition', 'watermarkOpacity', 'zagSiteNameStatus', 'zagSiteName', 'zagFontFamily', 'zagFontSize', 'zagCategoryStatus', 'vkAppId','vkGroupId', 'vkGroupSecret','vkUserId','isActiveVk', 'vkPostsDayLimit', 'vkNightMode', 'site_name', 'replaceTitle', 'replaceMetad', 'replaceMetak', 'replaceTags', 'replaceText', 'myAvatarInput', 'dbEngine');
		$bigInp									= array('postsDayLimit', 'moneyDayLimit');
		$data									= array();
		foreach ($inp as $p)
			$data[$p]							= $this->sys->array_val($arr, $p);
		//print_r($data);
		if (isset($groundSettings) && !empty($groundSettings))
		{
			if (isset($groundSettings['dbEngine']) && !empty($groundSettings['dbEngine']) && isset($data['dbEngine']) && !empty($data['dbEngine']))
			{
				if ($data['dbEngine'] != $groundSettings['dbEngine'])
				{
					$engineRes = $this->sys->changeDbEngine($data['dbEngine']);
					if(isset($engineRes) && !empty($engineRes))
					{
						$updated = array();
						$failed = array();
						$tablesUpdated = '';
						foreach($engineRes as $key => $value)
						{
							if ($value == 1)
								$updated[] = $key;
							else
								$failed[] = $key;
						}
						
						if (isset($updated) && !empty($updated))
						{
							$tablesUpdated = implode(',', $updated);
							$a = $this->sys->msg("Таблицы ".$tablesUpdated." успешно обновили систему хранения данных на ".$data['dbEngine']." .", "Настройки площадки", 2, $a);
							//$a[] = $this->sys->msg("Таблицы ".$tablesUpdated." успешно обновили систему хранения данных на ".$data['dbEngine']." .", "Настройки площадки", 1, $a);
						}
						if (isset($failed) && !empty($failed))
						{
							$failedTables = implode(',', $failed);
							$a = $this->sys->msg("Ошибка. Таблицы ".$failedTables." не обновили систему хранения данных. Обратитесь в техподдержку для решения этого вопроса.", "Настройки площадки", 1, $a);
						}
							
					}
				}
			}
		}
		if ($data['status'] != 'on' && $data['status'] != '')
			return ($this->sys->msg("Ошибка. [G081445]".$data['status'], "Настройки площадки", 3, $a));/*--error--*/
		if ($data['status'] == 'on')
			$data['status'] = 1;
		if ($data['status'] == '')
			$data['status'] = 2;
		$hoursListLimit 						= array();
		$daysListLimit 							= array();
		$categoryLimit							= array();
		$cLim 									= array();
		for ($d = 1; $d <= 7; $d++)
		{
			$nd = $d - 1;
			foreach ($bigInp as $b)
			{
				$valInp 						= $this->sys->array_val($arr, $b.'_'.$nd);
				if (!$valInp)
					$valInp 					= '0';
				if (!is_numeric($valInp) && $valInp != '*')
					return ($this->sys->msg("В полях блока \"Лимиты по дням\" разрешено вводить только цифры или *", "Настройки площадки", 1, $a));/*--error--*/
				if ($valInp > 99999)
					$valInp 					= '*';
				$daysListLimit[$nd][$b] 		= $valInp;
			}
			for ($h = 0; $h <= 23; $h++)
			{
				$r = 0;
				$valHour 						= $this->sys->array_val($arr, 'd'.$nd.'h'.$h);
				if ($valHour == 1)
					$r 							= 1;
				$hoursListLimit[$nd][] 			= $r;
			}
		}
		
		foreach ($wpCategory as $c)
		{
			if (is_numeric($c->cat_ID))
			{
				$cLim[$c->cat_ID]['author'] 	= $this->sys->array_val($arr, 'userCat_catID'.$c->cat_ID);
				$cLim[$c->cat_ID]['limit'] 		= $this->sys->array_val($arr, 'dayCatLimit_catID'.$c->cat_ID);
				$cLim[$c->cat_ID]['cat_ID'] 	= $c->cat_ID;
			}
		}
		$data['categoryLimits']					= $cLim;
		$data['workHoursList'] 					= $hoursListLimit;
		$data['dayPostsLimit'] 					= $daysListLimit;
	
		//print_r($this->sys->get_client_info($ground['domain']));
		$paramsList 							= array(
				
				'domain'						=> $ground['domain'],
				'groundSettings'		=> array(
							'siteName'			=> $data['site_name'],
							'replaceTitle'		=> $data['replaceTitle'],
							'replaceMetad'		=> $data['replaceMetad'],
							'replaceMetak'		=> $data['replaceMetak'],
							'replaceTags'		=> $data['replaceTags'],
							'replaceText'		=> $data['replaceText'],
							'dbEngine' 			=> $data['dbEngine']
				),
				'postSettings'			=> array(
					'cutImg'					=> $data['cutImg'],
					'cutIframe'					=> $data['cutIframe'],
					'imgBlur'					=> $data['imgBlur'],
					'imgMirror'					=> $data['imgMirror'],
					'watermarkPosition'			=> $data['watermarkPosition'],
					'watermarkOpacity'			=> $data['watermarkOpacity'],
					'zagSiteNameStatus'			=> $data['zagSiteNameStatus'],
					'zagSiteName'				=> $data['zagSiteName'],
					'zagFontFamily'				=> $data['zagFontFamily'],
					'zagFontSize'				=> $data['zagFontSize'],
					'zagCategoryStatus'			=> $data['zagCategoryStatus'],
					'myAvatarInput' 			=> $data['myAvatarInput']
				),
				'vkAutoPosting'			=> array(
					'vkGroupId'					=> $data['vkGroupId'],
					'vkGroupSecret'				=> $data['vkGroupSecret'],
					'vkPostsDayLimit'			=> $data['vkPostsDayLimit'],
					'vkNightMode'				=> $data['vkNightMode'],
					'vkUserId' 					=> $data['vkUserId'],
					'vkAppId' 					=> $data['vkAppId'],
					'vkPostAuthor' 				=> $data['vkPostAuthor'],
					'isActiveVk' 				=> $data['isActiveVk']
				),
				'workHoursList' 				=> $data['workHoursList'],
				'dayPostsLimit'					=> $data['dayPostsLimit'],
				'categoryLimits'				=> $data['categoryLimits'],
			);
			if(!empty($paramsList['postSettings']['myAvatarInput']) && empty($paramsList['postSettings']['watermarkOpacity']))
				return ($this->sys->msg("Для корректной работы водяного знака установите \"Уровень прозрачности водяного знака\" от 1 до 100. Рекомендуемое значение: 60 ", "Настройки площадки", 1, $a));
			if(empty($paramsList['postSettings']['zagSiteName']) && !empty($paramsList['postSettings']['zagSiteNameStatus']))
				return ($this->sys->msg("Для корректной работы заглушки установите \"Имя сайта на заглушке\". Рекомендуемое значение: ".$ground['domain']." ", "Настройки площадки", 1, $a));
			
		$dataArray = array(
			'act'								=> $data['status'],
			'paramsList'						=> json_encode($paramsList, JSON_UNESCAPED_UNICODE)
		);
		 $x = array(array('action' => 'editGround', 'type' => '1', 'groundId' => $ground['ground_id'], 'data' => $dataArray));
		$rest = $this->sys->api($PLUGIN_CONFIG['core'], $x);
		$json									= json_decode($rest, true);
//		print_r($json);
//		exit();
		if ($json['editGround'][0]['ground_id'])
		{
			if ($json['editGround'][0]['act'] == 1)
				$t 								= -1;
			if ($json['editGround'][0]['act'] == 2)
				$t 								= 1;
			array_push($a, array("add" => 0, "selector" => ".clientBlock.c".$ground['ground_id'],  "class" => $t, "className" => "stoped"));
			$a = $this->sys->msg("Настройки сохранены", "Настройки площадки", 2, $a);
			return ($a);
		}
		return ($this->sys->msg("Произошла ошибка при сохранении настроек. Если ошибка повторится обратитесь в Службу Поддержки", "Настройки площадки", 1, $a));
	}
}