<?php
class sys 
{
	
	function changeDbEngine($engine_name)
	{
		global $wpdb;
		
		
		if ($engine_name == 'myisam')
			$engine = 'MyISAM';
		else if ($engine_name == 'innodb')
			$engine = 'InnoDB';
		
		$table_prefix = $wpdb->get_blog_prefix();
		$updated_tables = array('postmeta', 'posts');

		$res = array();
		foreach($updated_tables as $table)
		{
			$sql = 'ALTER TABLE '.$table_prefix.$table.' ENGINE='.$engine.' ;';
			$t = $wpdb->query($sql);
			$res[$table_prefix.$table] = $t;
		}
		if ($res)
			return $res;
		return FALSE;
	}
	
	function catalog_search($post)
	{
		global $PLUGIN_CONFIG;
		
		$searchCategoryListId 	= sys::array_val($post, "searchCategoryListId");
		$iks_start 				= sys::array_val($post, "iks_start");
		$iks_end 				= sys::array_val($post, "iks_end");
		$y_index_start 			= sys::array_val($post, "y_index_start");
		$y_index_end 			= sys::array_val($post, "y_index_end");
		$g_index_start 			= sys::array_val($post, "g_index_start");
		$g_index_end 			= sys::array_val($post, "g_index_end");
		$traffic_start 			= sys::array_val($post, "traffic_start");
		$traffic_end 			= sys::array_val($post, "traffic_end");
		$page 					= sys::array_val($post, "num_page");
		$reload 				= sys::array_val($post, "reload");
		$categoryList			= array();
		$a						= array();
		if (!$page || $page < 0 || $page > 99999)
			$page				= 1;
			
		if ($page == 1)
			$start = 0;	
		else
			$start					= ($page - 1) * $PLUGIN_CONFIG['catalog_page_lim'];	
		
		if ((!empty($iks_start) && !empty($iks_end) && (!is_numeric($iks_start))) || 
			(!empty($y_index_start) && !empty($y_index_end) && (!is_numeric($y_index_start))) || 
			(!empty($g_index_start) && !empty($g_index_end) && ((!is_numeric($g_index_start))) || 
			(!empty($traffic_start) && !empty($traffic_end) && (!is_numeric($traffic_start)))))
			return (sys::msg("Ошибка, укажите правильные параметры для поиска.", "Поиск по каталогу", 1, $a));
		if ($iks_start < 0 || $iks_end < 0 || $y_index_start < 0 || $y_index_end < 0 || $g_index_start < 0 || $g_index_end < 0 || $traffic_start < 0 || $traffic_end < 0)
			return (sys::msg("Ошибка, укажите правильные параметры для поиска.", "Поиск по каталогу", 1, $a));
		if (!empty($searchCategoryListId))
		{
			$category_ids = explode(",", $searchCategoryListId);
			foreach($category_ids as $cat)
			{
				if (!is_numeric($cat) || $cat < 0)
					return (sys::msg("Ошибка, неверный идентификатор категории.", "Поиск по каталогу", 1, $a));
				$categoryList[] = $cat;
			}
		}
		if (!$iks_start)
			$iks_start				= 0;
		if (!$iks_end)
			$iks_end				= '*';
		if (!$y_index_start)
			$y_index_start			= 0;
		if (!$y_index_end)
			$y_index_end			= '*';
		if (!$g_index_start)
			$g_index_start			= 0;
		if (!$g_index_end)
			$g_index_end			= '*';
		if (!$traffic_start)
			$traffic_start			= 0;
		if (!$traffic_end)
			$traffic_end			= '*';
		$searchData				= array(
				'iks_start'	 			=> $iks_start,
				'iks_end' 				=> $iks_end,
				'y_index_start' 		=> $y_index_start,
				'y_index_end' 			=> $y_index_end,
				'g_index_start' 		=> $g_index_start,
				'g_index_end' 			=> $g_index_end,
				'traffic_start' 		=> $traffic_start,
				'traffic_end' 			=> $traffic_end,
				'category_list'			=> $categoryList
		);
		$fields					= array(
			array('action' => 'getCatalog',	'start' => $start, 'limit' => $PLUGIN_CONFIG['catalog_page_lim'], 'searchParams' => $searchData),
			array('action' => 'getCatalogCategory')
		);
		//print_r($fields);
		//print_r(sys::api($site['api'], $fields));
		//print_r(sys::api($site['api'], $fields));
		$zx = sys::api($PLUGIN_CONFIG['core'], $fields);
		//print_r($json);
		$json					= json_decode($zx, true);
		//print_r($json);
		$html = ''; 
		$c = count($json['getCatalog'][0]['donors']);
		//exit();
		if ($c < $PLUGIN_CONFIG['catalog_page_lim'])
			array_push($a, array("add" => 0, "selector" => ".navigInFooter",	"html",  "class" => "1", "className" => "allIsLoad"));
		else if ($c == $PLUGIN_CONFIG['catalog_page_lim'])
			array_push($a, array("add" => 0, "selector" => ".navigInFooter",	"html",  "class" => "-1", "className" => "allIsLoad"));

		foreach($json['getCatalog'][0]['donors'] as $donor)
			include(WP_PLUGIN_DIR.'/plink/admin/partials/help/catalog_mini_donor.php');	
				//print_r();
		if ($c != 0 && $html)
		{
			if ($reload == 1)
				$add = 3;
			else
				$add = 1;
					
			array_push($a, array("add" => $add, "selector" => ".donListC", "html" => $html));
		}
		array_push($a,
			array("add" => 0, "selector" => ".navigInFooter",	"html",  "class" => "-1", "className" => "loading"),
			array("add" => 10, "selector" => "#searchCatalog input[name=reload]",	"html" => "0")
		);
		return $a;
	}
	
	function transliterate($value) {
  $converter = array(
		'а' => 'a',    'б' => 'b',    'в' => 'v',    'г' => 'g',    'д' => 'd',
		'е' => 'e',    'ё' => 'e',    'ж' => 'zh',   'з' => 'z',    'и' => 'i',
		'й' => 'y',    'к' => 'k',    'л' => 'l',    'м' => 'm',    'н' => 'n',
		'о' => 'o',    'п' => 'p',    'р' => 'r',    'с' => 's',    'т' => 't',
		'у' => 'u',    'ф' => 'f',    'х' => 'h',    'ц' => 'c',    'ч' => 'ch',
		'ш' => 'sh',   'щ' => 'sch',  'ь' => '',     'ы' => 'y',    'ъ' => '',
		'э' => 'e',    'ю' => 'yu',   'я' => 'ya',
 
		'А' => 'A',    'Б' => 'B',    'В' => 'V',    'Г' => 'G',    'Д' => 'D',
		'Е' => 'E',    'Ё' => 'E',    'Ж' => 'Zh',   'З' => 'Z',    'И' => 'I',
		'Й' => 'Y',    'К' => 'K',    'Л' => 'L',    'М' => 'M',    'Н' => 'N',
		'О' => 'O',    'П' => 'P',    'Р' => 'R',    'С' => 'S',    'Т' => 'T',
		'У' => 'U',    'Ф' => 'F',    'Х' => 'H',    'Ц' => 'C',    'Ч' => 'Ch',
		'Ш' => 'Sh',   'Щ' => 'Sch',  'Ь' => '',     'Ы' => 'Y',    'Ъ' => '',
		'Э' => 'E',    'Ю' => 'Yu',   'Я' => 'Ya',
	);
 
	$value = strtr($value, $converter);
		$value = strtolower($value);
		return $value;
}
	function getPostIdByMetaKey($meta_key, $meta_value)
	{
		global $wpdb;
		
		$table = $wpdb->prefix.'postmeta';

		$res = $wpdb->get_results("SELECT `post_id` FROM `".$table."` WHERE `".$table."`.`meta_key` = '".$meta_key."' AND `".$table."`.`meta_value` = ".$meta_value."", ARRAY_A);
		if (count($res) > 0)
			return $res[0];
		return false;
	}
	
	
	function newWatermark(){
		global $PLINK_CONFIG;
	
		$img			= new img;
		$a				= array();
		
		//print_r($_FILES);
		
		$avatar 	= $img->save_pc_image($_FILES['file-0'], $PLINK_CONFIG['path_watermark'], 2);
		if (!$avatar)
			return (self::msg("Ошибка при загрузке водяного знака", 'Модерация площадки',1, $a));
//		$PLINK_CONFIG['url_watermark'] = $PLINK_CONFIG['path_watermark'].$avatar;
//		self::createConfigFile($PLINK_CONFIG);
		
		array_push($a, 
				   array("add" => 0, "selector" => ".btnloader",  "class" => 1, "className" => "displayNone"), array("add" => 10, "selector" => ".setPhotoBl input[name=avatar]", "html" => '/wp-content/plugins/plink/resources/watermark/'.$avatar),
				   array("add" => 5, "selector" => ".ajaxProfileLogo",  "attr" => "src", "val" => $PLINK_CONFIG['url_watermark']),
				   array("add" => 10, "selector" => "input[name=myAvatarInput]",  "html" => $avatar)
				  
				  );
		return ($a);	
	}
	
	function array_val($arr, $name)
	{
		$ret = array();
		foreach ($arr as $a)
		{
			if ($a['name'] == $name)
				$ret[] = $a['value'];
		}
		if (count($ret) == 1)
			return ($ret[0]);
		if (count($ret) > 1)
			return ($ret);
		return (NULL);
	}
	
	function cleanVar($var)
	{
		$var		= trim($var);
		$var		= htmlentities($var);
		return $var;
	}
	
	function getFavIcon($url, $type = 1)
	{
		global $PLUGIN_CONFIG;
		
		if (!$url)
			return $PLUGIN_CONFIG['badFavicon'];
		if (!stristr($url, 'http'))
		{
			//print_r($url);
			$newurl = "https://cdn.plink.top/".$url;
			if (filter_var($newurl, FILTER_VALIDATE_URL))
				return $newurl;
			else
				return $PLUGIN_CONFIG['badFavicon'];
		}
	}
	
	function valid_phone($phone)
	{
		if (preg_match("/^(\+)[0-9]{11,14}$/", $phone))
					return TRUE;
				return FALSE;
	}
	
	function valid_password($pass)
	{
		if (strlen($pass) < 8)
			return false;
        if(!preg_match("/([0-9]+)/", $pass))
        	return false;
        if(!preg_match("/([a-z]+)/", $pass))
        	return false;
        if(!preg_match("/([A-Z]+)/", $pass))
        	return false;
		return true;
	}
	
	function valid_nick($nick)
	{
		preg_match('/^[a-zA-z]{1}[a-zA-Z0-9]{4,20}$/', $nick, $matches, PREG_OFFSET_CAPTURE, 0);
		if (!$matches[0][0])
			return false;
		return true;
	}
	
	function getGroundStatus($act)
	{
		$a = array();
		if ($act == 1)
		{
			$a['status'] = "В работе";
			$a['work'] = ' active';
			$a['act'] = 1;
		}
		if ($act == 2)
		{
			$a['status'] = "Приостановлена";
			$a['stop'] = ' active';
			$a['act'] = 2;
		}
		if ($act == 3)
		{
			$a['status'] = "Удалена";
			$a['listDisactive'] = ' disable';
			$a['act'] = 1;
		}
		if ($act == 4)
		{
			$a['status'] = "Не активирована";
			$a['listDisactive'] = ' disable';
			$a['act'] = 1;
		}
		return $a;
	}
	
	function generateDaysTable($d)
	{
		$days 				= array('Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота', 'Воскресенье');
		$i 					= 0;
		$html				= '<div class="categoryListBlock dayLimits row nopad"><div class="donorList">
	<div class="oneCategory top row">
		<div class="col s2">День</div>
		<div class="col s5">Публикаций в день</div>
		<div class="col s5">Бюджет на день</div>
	</div>';
		foreach ($days as $day)
		{
			$html .= '<div class="oneCategory bot row nomar">
				<div class="col s2 dayNameTable"><span class="datTtl">'.$day.'</span></div>
				<div class="col s5 listNoPad"><input name="postsDayLimit_'.$i.'" value="'.(!empty($d[$i]['postsDayLimit']) ? $d[$i]['postsDayLimit'] : '*').'"></div>
				<div class="col s5 listNoPad"><input name="moneyDayLimit_'.$i.'" value="'.(!empty($d[$i]['moneyDayLimit']) ? $d[$i]['moneyDayLimit'] : '*').'"></div>
			</div>';
			$i++;
		}
		
		$html .= '</div></div>';
		
		return $html;
	}
	
	function generateHoursTable($w)
	{
		$days 				= array('Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс');
		$hours 				= array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23');
		$html				= '<div class="hourTable">
				<div class="dayCol">
					<div class="hoursList top"><div class="hourOne dayL">&nbsp;</div>';
					foreach ($hours as $h)
					{
						$html	   .= '<div class="hourOne hourTableTop" onclick="dayAndHourSet('.$h.')">'.$h.'</div>';
					}
				$html	   .= '
					</div>
				</div>
		';
		$a = 0;
		foreach ($days as $d)
		{
				$h = 0;
				if ($a == 5 || $a == 6)
					$cl = ' hd';
				else
					$cl = '';
				$html	   .= '
				<div class="dayCol">
					<div class="hoursList"><div class="hourOne t1 dayL'.$cl.'" onclick="daySet('.$a.')">'.$d.'</div>';
					foreach ($hours as $h)
					{
						if ($w[$a][$h]) {$class = ' active'; $val = '1';} else {$val = '0';}
						$html	   .= '<div class="hourOne d'.$a.'h'.$h.' fl'.$class.'" onclick="hourSet('.$a.', '.$h.')"><i class="fas fa-check"></i><input type="hidden" name="d'.$a.'h'.$h.'" value="'.$val.'"></div>';
						$h++;
						unset($class, $val);
					}
				$html	   .= '
					</div>
				</div>
				';
			$a++;
		}
		$html			   .= '</div>';
		return ($html);
	}
	
	function my_serialize(&$arr,$pos){
	  $arr = serialize($arr);
	}

	function my_unserialize(&$arr,$pos){
	  $arr = unserialize($arr);
	}

	//make a copy
	
	
	function checkGroundSettings($new)
	{
		/*
		Проверяет текущие настройки сохраненные в базе и те которые пришли с постом
		Коды ответов:
		-1 - Не пришли новые настройки
		*/
		$old = get_option('ground_settings', '');
//		print_r($old);
//		exit();
		if (!$new)
			return -1;
		$diff = array_diff($old, $new);
		$first_array_s = $old;
		$second_array_s = $new;

		// serialize all sub-arrays
		array_walk($first_array_s, array($this, 'my_serialize'));
		array_walk($second_array_s,array($this, 'my_serialize'));

		// array_diff the serialized versions
		$diff = array_diff($first_array_s, $second_array_s);
		array_walk($diff, array($this,'my_unserialize'));
		if (empty($old))
			$diff = $new;

		// unserialize the result
		
//		print_r($diff);
//		exit();
		if (count($diff) && !empty($diff))
		{
			if (update_option('ground_settings', $new))
				return true;
		}
	}
	
	static function clean_path($path = NULL)
	{
		$files = glob(PATH_TO_SITE.'/wp-content/plugins/plink/'.$path.'/*'); // get all file names
		foreach($files as $file)
		{ 
			if(is_file($file))
				unlink($file);
		}
		return 0;
	}
	
    static function addInParamsList($newParamsList, $oldParamsList, $act = 1)
	{
		global $site;

		$a = array();
		if ($act == 1)
			$x = 'paramsListFields';
		else
			$x = 'donorParamsListFields';
		foreach ($site[$x] as $p)
		{
			if (!$oldParamsList[$p] && $newParamsList[$p])
				$a[$p]	= $newParamsList[$p];	
			if ($oldParamsList[$p] && $newParamsList[$p] && ($oldParamsList[$p] != $newParamsList[$p]))
				$a[$p]	= $newParamsList[$p];
			if ($oldParamsList[$p] && $newParamsList[$p] && ($oldParamsList[$p] == $newParamsList[$p]))
				$a[$p]	= $oldParamsList[$p];	
		}
		return json_encode($a);
	}
    
	static private function createAPIfile($filename = null) {
		$text = "<?php
header('Content-Type: application/json; charset=utf-8');
require(\$_SERVER['DOCUMENT_ROOT'].'/wp-blog-header.php' );
require_once('class/add.class.php');
require_once('class/img.class.php');
require_once('class/api.class.php');
\$api = new api(true);
?>";
		$siteURL = get_site_url();
		$salt = 'dfajklsdjaklsdjaklsjdakls2312***+';
		if (!$filename)
			$filename = md5(md5(md5($siteURL.$salt.time())));
		file_put_contents(WP_PLUGIN_DIR.'/plink/'.$filename.'.php', $text, LOCK_EX);
		return($filename);
	}

	static public function createConfigFile($a) 
    {
        global $PLINK_CONFIG;
        
        $reservedFields = array('domain', 'hash_file', 'hash', 'userId', 'groundId', 'path_tw_fb', 'path_vk', 'path_logo', 'path_img', 'path_watermark', 'url_watermark', 'tmp_path');
        $arr = array();
        foreach ($reservedFields as $value => $key) {
            $arr[$key] = '';
            if(!empty($a[$key]))
                $arr[$key] = $a[$key];
            else if($PLINK_CONFIG[$key] != '')
                $arr[$key] = $PLINK_CONFIG[$key];
        }
        $i = 0;
        $text = '<?php $PLINK_CONFIG = array(';
        foreach ($arr as $key => $value) {
            if($i > 0)
                $text .= ',';
            $text .= "'".$key."' => '".$value."'";
            $i++;
        }
        $text .= ');';
        if (file_put_contents(PATH_TO_CONFIG, $text, LOCK_EX))
			return TRUE;
		return FALSE;
	}

	function get_client_info($domain)
	{
		$html = new simple_html_dom;
		$text = self::api('https://'.$domain, 0, 'out');
		if (!$text)
			$text = self::api('http://'.$domain, 0, 'out');
		if ($text)
		{
			$html = str_get_html($text);
			$fav = false; $big = false;
			$title = $html->find('title', 0)->plaintext;
			
			foreach($html->find('link[rel="icon"]') as $a)
			{
				if ($a->href && !$a->sizes)
					$fav = $a->href;
				if ($a->href && $a->sizes && !$big)
					$big = $a->href;
			}
			if (!$fav && $big)
				$fav = $big;
			if (!$fav && !$big)
				$fav = '';
			$arr = array('fav' => $fav, 'title' => $title);
			print_r($arr);
			return $arr;	
			
		}
		return NULL;
	}
	
	static public function activate_plugin() 
    {
		global $PLINK_CONFIG;
        $a = array(
            'domain'    => $_SERVER['HTTP_HOST'],
            'hash_file' => self::createAPIfile(),
        );
        self::createConfigFile($a);
        $a = self::generate_folder_name($a);
        self::create_necessary_folders($a);
        self::createConfigFile($a);
		update_option('plink_version', PLINK_VERSION);
	}
    
    static function generate_folder_name($arr)
    {
        global $PLINK_CONFIG;
        
        $hash = substr(md5($_SERVER['HTTP_HOST']), 0, 7);
        $path  = '/wp-content/uploads/';
        if (empty($PLINK_CONFIG['path_tw_fb']))
            $arr['path_tw_fb'] = $path.'tw_fb'.$hash.'/';
        if (empty($PLINK_CONFIG['path_vk']))
            $arr['path_vk'] = $path.'vk'.$hash.'/';
        if (empty($PLINK_CONFIG['path_img'])) 
            $arr['path_img'] = $path.'img'.$hash.'/';
        if (empty($PLINK_CONFIG['path_logo']))
            $arr['path_logo'] = $path.'logo'.$hash.'/';
		$arr['path_watermark'] = '/wp-content/plugins/plink/resources/watermark/';	
		$arr['tmp_path'] = '/wp-content/uploads/tmp/';	
        return($arr);
    }
    
    static public function create_necessary_folders($a) 
    {
        if (!file_exists(PATH_TO_SITE.$a['path_tw_fb']))
            mkdir(PATH_TO_SITE.$a['path_tw_fb']);
        if (!file_exists(PATH_TO_SITE.$a['path_vk']))
             mkdir(PATH_TO_SITE.$a['path_vk']);
        if (!file_exists(PATH_TO_SITE.$a['path_img']))
            mkdir(PATH_TO_SITE.$a['path_img']);
        if (!file_exists(PATH_TO_SITE.$a['path_logo']))
            mkdir(PATH_TO_SITE.$a['path_logo']);
		if (!file_exists(PATH_TO_SITE.$a['path_watermark']))
            mkdir(PATH_TO_SITE.$a['path_watermark']);
		if (!file_exists(PATH_TO_SITE.$a['tmp_path']))
            mkdir(PATH_TO_SITE.$a['tmp_path']);
    }
    
    static function remove_config_file() {
        $a = array(
            'hash'       =>  '-1',
            'hash_file'   => '-1',
            'groundId'    => '-1',
            'domain'      => '-1',
            'userId'      => '-1',
            );
        
        self::createConfigFile($a);
    }
    
	 static function deactivate_plugin() {
         global $PLINK_CONFIG, $PLUGIN_CONFIG;
         
         $groundId      = $PLINK_CONFIG['groundId'];
         $plinkHash     = $PLINK_CONFIG['hash'];
         $pluginHash    = $PLINK_CONFIG['hash_file'];
         $domain        = $PLINK_CONFIG['domain'];
         
         $json = json_decode(self::api($PLUGIN_CONFIG['api'], array(array(
			'action' => 'pluginDeactivation', 
			'groundId' => $groundId,
			'plinkHash' => $plinkHash, 
			'pluginHash' => $pluginHash,
			'domain' => $domain))), true);
        unlink(WP_PLUGIN_DIR.'/plink/'.$pluginHash.'.php');
        self::remove_config_file();
		self::removeTmpInfo();
	}
    
    static function api($url, $fields = null, $type = 'panel') {
        global $PLUGIN_CONFIG;
	  
        $ch = curl_init();
        if(strtolower((substr($url,0,5))=='https'))
        {
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        }
        if ($fields)
            $fields = http_build_query($fields); 
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_REFERER, $url);
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        if ($fields)
            curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
        if ($type != 'out')
            curl_setopt($ch, CURLOPT_HTTPHEADER, array('AccountId: '.$type));
        curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/4.0 (Windows; U; Windows NT 5.0; En; rv:1.8.0.2) Gecko/20070306 Firefox/1.0.0.4");
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
        curl_setopt($ch, CURLOPT_COOKIEJAR, $_SERVER['DOCUMENT_ROOT'].'/config/cookie.txt');
        $result = curl_exec($ch);
        curl_close($ch);
        return self::remove_utf8_bom($result);
	}
	
	static function remove_utf8_bom($text)
	{
		$bom = pack('H*','EFBBBF');
		$text = preg_replace("/^$bom/", '', $text);
		return $text;
	}
	
//	static function api($url, $fields, $type = 'panel')
//	{
//	   global $PLINK_CONFIG;
//		
//	   $ch = curl_init();
//	   if ($PLINK_CONFIG['api_htpd_login'] && $PLINK_CONFIG['api_htpd_pass'])
//		   	curl_setopt($ch, CURLOPT_USERPWD, $PLINK_CONFIG['api_htpd_login'].":".$PLINK_CONFIG['api_htpd_pass']);
//	    $scheme = strtolower(substr($url, 0, 5));
//	    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
//	    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
//		curl_setopt($ch, CURLOPT_URL, $url);
//		curl_setopt($ch, CURLOPT_REFERER, $url);
//		curl_setopt($ch, CURLOPT_VERBOSE, 1);
//		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 7);
//		curl_setopt($ch, CURLOPT_POST, 1);
//		if ($fields)
//			curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($fields));
//		curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/4.0 (Windows; U; Windows NT 5.0; En; rv:1.8.0.2) Gecko/20070306 Firefox/1.0.0.4");
//		curl_setopt($ch, CURLOPT_HEADER, 0);
//		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
//		curl_setopt($ch, CURLOPT_COOKIEJAR, $_SERVER['DOCUMENT_ROOT'].'/config/cookie.txt');
//		$result = curl_exec($ch);
//		curl_close($ch);
//		if ($scheme == 'https' && empty($result))
//			return self::api(str_replace('https://', 'http://', $url), $fields, $type);
//		return self::remove_utf8_bom($result);
//	}
	
	function msg($txt, $type, $color = 1, $arr = array())
	{
		$randClass			= "class_rand_".mt_rand(1, 99).mt_rand(99, 999).mt_rand(1, 999999);
		array_push(
                $arr,
				array("add" => 1, "selector" => ".flyAlerts", "html" => '<div class="wrap_alert '.$randClass.'"><div data-id="'.$randClass.'" class="errorsBlock color'.$color.' active">'.$txt.'</div></div>'),
				array("add" => 25, "selector" => "body", "func" => "msgTimer", "arg1" => $randClass)
		);
		return ($arr);	
	}
    
    public function new_file_name($ext)
	{
		if (empty($ext))
			return (FALSE);
		return (time().'_'.rand(1000, 9999).'.'.$ext);
	}
    
    public static function curl($url = NULL)
	{	
		$curl					= curl_init();
		$auth					= false;
		$options				= array(
			CURLOPT_URL            => $url,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_ENCODING       => "",
			CURLOPT_AUTOREFERER    => true,
			CURLOPT_CONNECTTIMEOUT => 10,
			CURLOPT_TIMEOUT        => 10,
			CURLOPT_MAXREDIRS      => 10,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_SSL_VERIFYPEER => true,
			CURLOPT_USERPWD		   => $auth
		);
		curl_setopt_array($curl, $options);
		$response				= curl_exec($curl);
		if($response === false)
			curl_error($curl);
		curl_close($curl);
		return($response);
	}
    
    public function clean_trash($document)
	{
		$search = array ("'<script[^>]*?>.*?</script>'si", 
                 "'<[\/\!]*?[^<>]*?>'si",		 					
                 "&quot;",               
                 "&lt;",
                 "&gt;",
                 "&nbsp;",
				 "&laquo;",
				 "&raquo;",
				 "&amp;quot;",               
                 "&amp;lt;",
                 "&amp;gt;",
                 "&amp;nbsp;",
				 "&amp;laquo;",
				 "&amp;raquo;");
 
		$replace = array ("",
					 "",
					 "\"",
					 "<",
					 ">",
					 " ",
					 "«",
					 "»",
					 "\"",
					 "<",
					 ">",
					 " ",
					 "«",
					 "»");
		$document = str_replace($search, $replace, $document);
		return $document;
	}
	
	function 	removeTmpInfo()
	{
		global $PLINK_CONFIG;
		
		unlink($_SERVER['DOCUMENT_ROOT'].$PLINK_CONFIG['tmp_path'].'tmp.php');
		delete_option( 'ground_settings' );
	}
	
	function 	saveCookieInfo()
	{	
		require(PATH_TO_CONFIG);
		
		if (!empty($PLINK_CONFIG['hash']))
			file_put_contents($_SERVER['DOCUMENT_ROOT'].$PLINK_CONFIG['tmp_path'].'tmp.php', json_encode($PLINK_CONFIG));
	}
	
	static function activateAfterUpdate()
	{	
		

		if (!empty(PATH_TO_TMP) && file_exists(PATH_TO_TMP.'tmp.php'))
		{
			$t = file_get_contents(PATH_TO_TMP.'tmp.php');
			$config = json_decode($t, true);
		}
		if (isset($config) && !empty($config))
		{
			
			$hash_file 	= $config['hash_file'];
			if (isset($hash_file) && !empty($hash_file))
				$apiFile = self::createAPIfile($hash_file);
			if (isset($config) && !empty($config))
				$configFile = self::createConfigFile($config);
			if (!empty($apiFile) && !empty($configFile))
				update_option('plink_version', PLINK_VERSION);
		}
	}
}
?>