<?php
class user
{
	public function loginToPlink()
	{
		global $PLINK_CONFIG, $PLUGIN_CONFIG;

		if (isset($_POST['params']) && isset($_POST['action']) && $_POST['action'] == 'auth')
		{
			$a 			= array();
			$email 		= $this->sys->array_val($_POST['params'], "email");
			$password 	= $this->sys->array_val($_POST['params'], "password");
			$domain 	= $_SERVER['HTTP_HOST'];
			$hash 		= $this->sys->array_val($_POST['params'], "hash_file");
			if (filter_var($email, FILTER_VALIDATE_EMAIL))
				$type	= 2;
			else if ($this->sys->valid_nick($email))
				$type	= 3;
			else if ($this->sys->valid_phone($email))
				$type	= 4;
			else 
				return ($this->sys->msg("Ошибка, заполните все поля корректно. <br>Укажите Email (логин или номер телефона) и пароль от Вашей учетной записи Plink", "Авторизация", 3, $a));
			$x = array(array('action' => 'pluginActivation', 'email' => $email, 'password' => $password, 'domain' => $domain, 'hash' => $hash, 'type' => $type));
			$z = $this->sys->api($PLUGIN_CONFIG['api'], $x);
			$json = json_decode($z , true);
			
			if ($json['pluginActivation'][0] == 0)
				return ($this->sys->msg("Произошла ошибка. Обратитесь в службу технической поддержки.", "Авторизация", 1, $a));
			else if ($json['pluginActivation'][0] == -1)
				return ($this->sys->msg("Невалидный Email.", "Авторизация", 1, $a));
			else if ($json['pluginActivation'][0] == -2)
				return ($this->sys->msg("Ошибка. Площадка <strong>$domain</strong> не найдена в Вашем аккаунте. Необходимо ее добавить в панели управления Plink.", "Авторизация", 1, $a));
			else if ($json['pluginActivation'][0] == -3)
				return ($this->sys->msg("Неверный пароль.", "Авторизация", 1, $a));
			else if ($json['pluginActivation'][0] == -4)
				return ($this->sys->msg("Не удаётся войти. Пожалуйста, проверьте правильность написания логина и пароля.", "Авторизация", 1, $a));
			else if ($json['pluginActivation'][0] == -5)
				return ($this->sys->msg("Плагин установлен не правильно. Попробуйте переустановить.", "Авторизация", 1, $a));
			else if ($json['pluginActivation'][0] == -6)
				return ($this->sys->msg("Площадка принадлежит другому пользователю.", "Авторизация", 1, $a));
			else
			{
				$arr = array();
				if (isset($json['pluginActivation'][0]['hash']))
					$arr['hash'] = $json['pluginActivation'][0]['hash'];
				if (isset($json['pluginActivation'][0]['groundId']))
					$arr['groundId'] = $json['pluginActivation'][0]['groundId'];
				if (isset($json['pluginActivation'][0]['uid']))
					$arr['userId'] = $json['pluginActivation'][0]['uid'];
				if (isset($json['pluginActivation'][0]['key_a']))
					$arr['key_a'] = $json['pluginActivation'][0]['key_a'];
				if (isset($json['pluginActivation'][0]['key_b']))
					$arr['key_b'] = $json['pluginActivation'][0]['key_b'];
				array_push($a, 
						   array("add" => 20, "selector" => "body")
						  );
				if (!$this->sys->createConfigFile($arr))
					return ($this->sys->msg("Ошибка создания конфигурационного файла.", "Авторизация", 1, $a));
				return $a;
			}
			return ($this->sys->msg("Ошибка. [A125807]", "Авторизация", 1, $a));
			
		}
	}
}