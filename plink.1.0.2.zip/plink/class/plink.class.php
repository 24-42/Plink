<?php
class plink {
	protected $loader;
	static public $settings;

	public function __construct() {
		
		global $PLINK_CONFIG, $PLUGIN_CONFIG;
		$this->sys = new sys;
		
		if ($PLINK_CONFIG['hash'])
			self::$settings   	= get_option('ground_settings');
		$this->define_admin_hooks();
	}

	private function define_admin_hooks() {
		$plugin_admin = new admin();
		$this->loader = new loader();

		$this->loader->add_action( 'plugins_loaded', $plugin_admin, 'checkPluginVersion');
		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_styles' );
		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts' );
		$this->loader->add_action( 'wp_footer', $plugin_admin, 'enqueue_fancybox' );
		$this->loader->add_action( 'admin_menu', $plugin_admin, 'init_menu');
	}
	
	function checkUpdate()
	{
		global $PLUGIN_CONFIG;
		
		$t = file_get_contents($PLUGIN_CONFIG['metadata']);
		$plink_v = get_option('plink_version');
		if (isset($t) && !empty($t))
		{
			$info = json_decode($t, true);
			if($info['version'] != $plink_v)
				update_option('plink_update', 1);
			else
				update_option('plink_update', 0);
		}
	}
	
	function checkPostImages()
	{
		global $PLUGIN_CONFIG;
			$args = array(
				'post_status' 	=> 'pending',
				'post_type'		=> 'post',
				'order'			=> 'ASC',
				'numberposts' => 5
			);
		
		$query = new WP_Query;
		$posts = get_posts($args);
		foreach($posts as $p)
		{
			if ($p)
			{
				$images = $this->cron->getAllImages($p);
				
				if (isset($images) && !empty($images))
					$new_srcs = $this->cron->downloadImages($images);
				else
					$this->cron->updatePost($p, '', true);
				if (isset($new_srcs) && $new_srcs)
					$this->cron->updatePost($p, $new_srcs, false);
			}
		}
	}
	
	function checkConfig()
	{
		global $PLINK_CONFIG;
		
		if (isset($PLINK_CONFIG['hash']) && !empty($PLINK_CONFIG['hash']))
			sys::saveCookieInfo();
		
	}
	
	public function initCheckUpdate()
	{
		$this->cron = new cron(array('id' => 'checkUpdate', 'events' => array('checkUpdate' => array('callback' => array($this, 'checkUpdate'), 'interval_name' => '10 min', 'interval_sec' => '600', 'interval_desc' => 'Каждые 10 минут'))));
	}
	
	public function initCheckConfigCron()
	{
		$this->cron = new cron(array('id' => 'checkConfig', 'events' => array('checkConfig' => array('callback' => array($this, 'checkConfig'), 'interval_name' => 'min', 'interval_sec' => '60', 'interval_desc' => 'Каждую минуту'))));
	}

	public function initCron()
	{
		global $PLUGIN_CONFIG;
		
		$this->cron = new cron(array('id' => 'checkPostImages', 'events' => array('checkPostImages' => array('callback' => array($this, 'checkPostImages'), 'interval_name' => 'min', 'interval_sec' => '60', 'interval_desc' => 'Каждую минуту'))));
		//$this->checkPostImages();
		//cron::deactivate('checkPostImages');
		
	}
    
	public function run() {
		$this->loader->run();
		
	}
}
?>