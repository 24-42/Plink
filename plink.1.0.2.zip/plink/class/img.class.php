<?php defined('_JEXEC') or die('403');
class img extends plink
{
	static public $settings;
	public function __construct()
	{
		global $PLINK_CONFIG, $PLUGIN_CONFIG;
		
		$this->sys = new sys;
		self::$settings = parent::$settings;
	}
	
	function resizeImage($filename, $max_width, $max_height, $ext)
	{
		list($orig_width, $orig_height) = getimagesize($filename);

		$width = $orig_width;
		$height = $orig_height;

		# taller
		if ($height > $max_height) {
			$width = ($max_height / $height) * $width;
			$height = $max_height;
		}

		# wider
		if ($width > $max_width) {
			$height = ($max_width / $width) * $height;
			$width = $max_width;
		}

		$image_p = imagecreatetruecolor($width, $height);
		if ($ext == 'jpg')
			$image = imagecreatefromjpeg($filename);
		else if ($ext == 'png')
			$image = imagecreatefrompng($filename);
		

		imagecopyresampled($image_p, $image, 0, 0, 0, 0,
										 $width, $height, $orig_width, $orig_height);
		
		if ($ext == 'jpg')
			imagejpeg($image_p, $filename, 75);
		else if ($ext == 'png')
			imagepng($image_p, $filename, 7);
		imagedestroy($image_p);

		return $filename;
	}
	
	
	function save_pc_image($img, $path, $type)
	{		
		$tmp_path 						= $path;
		$path							= $_SERVER['DOCUMENT_ROOT'].$path;
		$fileType						= $this->getExtension($img['name']);
		$filename						= $this->sys->new_file_name($fileType);
		if ($type == 1)
			$y = $x = 200;
		else
		{
			$x = 50;
			$y = 50;
		}
		
		if (move_uploaded_file($img['tmp_name'], $path.$filename))
		{
//			print_r($path.$filename);
//			exit();
			$resize						= $this->resizeImage($path.$filename, $x, $y, $fileType);
			
			if (empty($resize))
			{
				unlink($path.$filename);
				return (FALSE);
			}
			return ($filename);
		}
		return (FALSE);
	}
	
	function saver($link, $type = 'path_img')
	{
		global $PLINK_CONFIG;
		
		$save			= $this->sys->curl(trim($link));
		$ext			= $this->getExtension($link);
        $format_array 	= array('jpg', 'jpeg', 'gif', 'png');
		if (!in_array($ext, $format_array))
			return FALSE;
		$new_name		= $this->sys->new_file_name($ext);
        $today      	= date("d-m-y");
        
        if(!file_exists(PATH_TO_SITE.$PLINK_CONFIG[$type].$today.'/'))
            mkdir(PATH_TO_SITE.$PLINK_CONFIG[$type].$today.'/');
		$new_url		= $PLINK_CONFIG[$type].$today.'/'.$new_name;
		if (!$handle 	= fopen(PATH_TO_SITE.$new_url, 'a'))
			return false;
		if (fwrite($handle, $save) == TRUE)
			return $new_url;
		return FALSE; 
	}
	
	function check_img($link)
	{
		global $PLINK_CONFIG;
		
//		print_r($settings);
//		exit();
//		file_put_contents($_SERVER['DOCUMENT_ROOT'].'/44.txt', json_encode($PLINK_CONFIG));
//		exit();
		$src = $this->saver(str_replace('"','', $link), 'path_img');
		if (!empty(self::$settings['postSettings']['imgBlur']) || !empty(self::$settings['postSettings']['imgMirror']))
			$src = $this->resize_quolity($src, 1366, 768, false);
         if (!empty(self::$settings['postSettings']['myAvatarInput']))
            $src = $this->create_watermark($src, $_SERVER['DOCUMENT_ROOT'].$PLINK_CONFIG['path_watermark'].self::$settings['postSettings']['myAvatarInput'], self::$settings['postSettings']['watermarkOpacity']);
		if ($src)
			return "<a href =\"$src\" data-fancybox=\"gallery\" data-fancybox=\"images\"><img src=\"$src\"></a>";
		return '';
	}
	
   function resave_img($post)
	{
		global $PLINK_CONFIG;
		
	   if ($post['post_logo'])
		{
			$new_logo		= $this->saver($post['post_logo'], 'path_logo');
		   
            if (!empty(self::$settings['postSettings']['myAvatarInput']))
                $new_logo 	= $this->create_watermark($new_logo, $_SERVER['DOCUMENT_ROOT'] . self::$settings['postSettings']['myAvatarInput'], self::$settings['postSettings']['watermarkOpacity']);
			$post['post_logo'] = $new_logo;
		}
		if ($post['post_content'])
		{
			$post_content = $post['post_content'];
			if (!empty($html))
			{
                if (isset(self::$settings['postSettings']['removePictures']) && self::$settings['postSettings']['removePictures'])
                    $post_content = preg_replace('#({)(.*?)}#g', '', $post_content);
				$post['post_content'] = $post_content;			
			}
		}
		return $post;
	}
	
	function getExtension($filename)
	{
		$path_info						= pathinfo($filename, PATHINFO_EXTENSION);
		$s = explode("?", $path_info);

		return (trim(mb_strtolower($s[0])));
	}
	
	function create_watermark($main_img_obj, $watermark_img_obj, $alpha_level = 100 ) 
	{
        global $PLINK_CONFIG;
        
		$tmp_mio = $main_img_obj;
//				print_r($tmp_mio);
//		exit();
		$main_img_obj = $_SERVER['DOCUMENT_ROOT'].$main_img_obj;
		$ext = self::getExtension($main_img_obj);
		$save = $main_img_obj;
		if ($ext == 'jpg')
			$main_img_obj 		        = imagecreatefromjpeg($main_img_obj);
		else if($ext == 'png')
			$main_img_obj 		        = imagecreatefrompng($main_img_obj);
		else
			return $main_img_obj;
			
		$watermark_img_obj              = imagecreatefrompng($_SERVER['DOCUMENT_ROOT'].$PLINK_CONFIG['path_watermark'].self::$settings['postSettings']['myAvatarInput']);
		$alpha_level                   /= 100;
		$main_img_obj_w                 = imagesx( $main_img_obj );
		$main_img_obj_h                 = imagesy( $main_img_obj );
		$watermark_img_obj_w            = imagesx( $watermark_img_obj );
		$watermark_img_obj_h            = imagesy( $watermark_img_obj );
        
        $top_position_watermark         = floor($main_img_obj_h - $main_img_obj_h + 50);
        $left_position_watermark        = floor( $main_img_obj_w - $main_img_obj_w + 50);
        $center_position_watermark_x    = floor( $main_img_obj_w / 2 - ($watermark_img_obj_w / 2));
        $center_position_watermark_y    = floor($main_img_obj_h / 2 - ($watermark_img_obj_h) / 2);
        $right_position_watermark       = floor( $main_img_obj_w - $watermark_img_obj_w - 50);
        $bottom_position_watermark      = floor($main_img_obj_h - $watermark_img_obj_h - 50);
        
        $positionWatermark = self::$settings['postSettings']['watermarkPosition'];
        $arrPosition = array(1,2,3,4,5,6,7,8,9);
        
        if ($positionWatermark == 10) //random
            $positionWatermark = $arrPosition[rand(0, 8)];
        if ($positionWatermark == 1) // left-top
        {
            $my_new_min_x = $left_position_watermark;
            $my_new_min_y = $top_position_watermark;
        }
        if ($positionWatermark == 2) //left-center
        {
            $my_new_min_x = $left_position_watermark;
            $my_new_min_y = $center_position_watermark_y;
        }
        if ($positionWatermark == 3) // left-bottom
        { 
            $my_new_min_x = $left_position_watermark;
            $my_new_min_y = $bottom_position_watermark;
        }
        if ($positionWatermark == 4)//'center-top'
        {
            $my_new_min_x = $center_position_watermark_x;
            $my_new_min_y = $top_position_watermark;
        }
        if ($positionWatermark == 5) //center 
        {  
            $my_new_min_x = $center_position_watermark_x;
            $my_new_min_y = $center_position_watermark_y;
        }
        if ($positionWatermark == 6) //center-bottom
        {
            $my_new_min_x = $center_position_watermark_x;
            $my_new_min_y = $bottom_position_watermark;
        }
        if ($positionWatermark == 7) //right-top
        {
            $my_new_min_x = $right_position_watermark;
            $my_new_min_y = $top_position_watermark;
        }
        if ($positionWatermark == 8) //'right-center'
        {
            $my_new_min_x = $right_position_watermark;
            $my_new_min_y = $center_position_watermark_y;
        }
        if ($positionWatermark == 9) //right-bottom
        {
            $my_new_min_x = $right_position_watermark;
            $my_new_min_y = $bottom_position_watermark;
        }
        
        $main_img_obj_min_x = $my_new_min_x;
        $main_img_obj_min_y = $my_new_min_y;
        $main_img_obj_max_x = ceil( ( $main_img_obj_w / 2 ) + ( $watermark_img_obj_w / 2 ) );
        $main_img_obj_max_y = ceil( ( $main_img_obj_h - 50 ) + ( $watermark_img_obj_h / 2 ) );
        
		$return_img = imagecreatetruecolor( $main_img_obj_w, $main_img_obj_h );
		for( $y = 0; $y < $main_img_obj_h; $y++ ) 
		{
			for( $x = 0; $x < $main_img_obj_w; $x++ ) 
			{
				$return_color= NULL;
				$watermark_x= $x - $main_img_obj_min_x;
				$watermark_y= $y - $main_img_obj_min_y;
				$main_rgb = imagecolorsforindex( $main_img_obj, imagecolorat( $main_img_obj, $x, $y ) );
				if ($watermark_x >= 0 && $watermark_x < $watermark_img_obj_w &&
				$watermark_y >= 0 && $watermark_y < $watermark_img_obj_h ) 
				{
					$watermark_rbg = imagecolorsforindex( $watermark_img_obj, imagecolorat( $watermark_img_obj, $watermark_x, $watermark_y ) );
					$watermark_alpha= round( ( ( 127 - $watermark_rbg['alpha'] ) / 127 ), 2 );
					$watermark_alpha= $watermark_alpha * $alpha_level;
					$avg_red= self::_get_ave_color( $main_rgb['red'],$watermark_rbg['red'],$watermark_alpha );
					$avg_green= self::_get_ave_color( $main_rgb['green'],$watermark_rbg['green'],$watermark_alpha );
					$avg_blue= self::_get_ave_color( $main_rgb['blue'],$watermark_rbg['blue'],$watermark_alpha );
					$return_color= self::_get_image_color( $return_img, $avg_red, $avg_green, $avg_blue );
				} 
				else 
				{
					$return_color= imagecolorat( $main_img_obj, $x, $y );
				}
				imagesetpixel( $return_img, $x, $y, $return_color );
			}
		} 
		if ($ext == 'jpg')
			imagejpeg($return_img, $save);
		else if ($ext == 'png')
			imagepng($return_img, $save);
		return $tmp_mio;
	}

	static function _get_ave_color( $color_a, $color_b, $alpha_level ) 
	{
		return round( ( ( $color_a * ( 1 - $alpha_level ) ) + ( $color_b* $alpha_level ) ) );
	}
	
	static function _get_image_color($im, $r, $g, $b) 
	{
		$c=imagecolorexact($im, $r, $g, $b);
		if ($c!=-1) return $c;
		$c=imagecolorallocate($im, $r, $g, $b);
		if ($c!=-1) return $c;
		return imagecolorclosest($im, $r, $g, $b);
	}

	
	function get_social_img($filename, $post_id, $tw_fb = false) //get_zaglushka
	{
		global $PLINK_CONFIG, $PLUGIN_CONFIG;
		
		$parse        = parse_url($filename);
		if (isset($parse['host']) && $parse['host'])
			$filename = $parse['path'];
		if ($tw_fb) 
			$img      = $this->resize_quolity(trim($filename), 1200, 630, true, 'tw', true);
		else
			$img      = $this->resize_quolity(trim($filename), 1074, 480, true, 'vk', true);
		$ext          = strtolower($this->getExtension($img));
		$img 			= $_SERVER['DOCUMENT_ROOT'] .$img;
		if ($ext == 'jpg')
			$im       = ImageCreateFromjpeg($img);
		else if ($ext == 'png')
			$im       = ImageCreateFrompng($img);
		else
			$im       = ImageCreateFromjpeg($img);
		$font         = $_SERVER['DOCUMENT_ROOT'] . $PLUGIN_CONFIG['fonts'][self::$settings['postSettings']['zagFontFamily'] - 1];
		$size         = getimagesize($img);
		$w            = $size[0];
		$color        = imagecolorallocatealpha($im, 0, 0, 0, 40);
		$h            = $size[1];
		imagefilledrectangle($im, 0, 0, $w, $h, $color);
		$new          = $this->sys->new_file_name($ext);
		if ($tw_fb) 
			$path     = $PLINK_CONFIG['path_tw_fb'];
		else
			$path     = $PLINK_CONFIG['path_vk'];
		$path_to_img  = $path.$new;
		$font_size    = self::$settings['postSettings']['zagFontSize'];
		$width        = $w;
		$margin       = 50;
		$text         = get_the_title($post_id);
        if (self::$settings['postSettings']['zagCategoryStatus'])
		  $category   = get_the_category($post_id);
		$text_a       = explode(' ', $text);
		$text_new     = '';
		foreach($text_a as $word)
		{
			$box      = imagettfbbox($font_size, 0, $font, $text_new.' '.$word);
			if($box[2] > $width - $margin * 2)
				$text_new .= "\n".$word;
			else 
				$text_new .= " ".$word;
		}
		$text_new     = $this->sys->clean_trash(trim($text_new));
		$box          = imagettfbbox($font_size, 0, $font, $text_new);
		$height       = $box[1] + $font_size + $margin * 2;
		$white        = imagecolorallocate($im, 255, 255, 255);
		imagettftext($im, $font_size, 0, $margin, $font_size + $margin, $white, $font, html_entity_decode($text_new));
        if (self::$settings['postSettings']['zagCategoryStatus'])
		  imagettftext($im, $font_size, 0, $margin,  $h - $margin, $white, $font, "#".$category[0]->cat_name);
        if (self::$settings['postSettings']['zagSiteNameStatus'])
        {
            $box2 = imagettfbbox($font_size, 0, $font, self::$settings['postSettings']['zagSiteName']);
            $text_w_pos = $w - ($box2[2]-$box2[0]);
            imagettftext($im, $font_size, 0, $text_w_pos - $margin,  $h - $margin, $white, $font, self::$settings['postSettings']['zagSiteName']);
        }
        
		$ret          = $path_to_img;
		$path_to_img  = $_SERVER['DOCUMENT_ROOT'] . $path_to_img;
		if ($ext == 'jpg')
			imagejpeg($im, $path_to_img);
		else if ($ext == 'png')
			imagepng($im, $path_to_img);
		else
			imagejpeg($im, $path_to_img);
		imagedestroy($im);
		unlink($img);
		return (substr($ret, 1));
	}
	
   
	function resize_quolity($file,  $size_x = 1366, $size_y = 768, $addr = false, $social = 'vk', $check = false)
	{
		global $PLINK_CONFIG;
		/*
        * Создаем объект изображения
        */
		$tmp_file = $file;
		$file = $_SERVER['DOCUMENT_ROOT'] . $file;
		$ext							= strtolower(self::getExtension($file));
		if ($ext == 'jpeg')
			$ext						= 'jpg';
		if ($ext == 'jpg')
			$im							= imagecreatefromjpeg($file);
		else if ($ext == 'png')
			$im							= imagecreatefrompng($file);
		else if ($ext == 'gif')
			$im							= imagecreatefromgif($file);
		else 
			return(0);
        /*
        * Получаем размеры ширину и высоту полученного изображения, и расчитываем нужные размеры 
        */
		list($x, $y)					= getimagesize($file);
		$tmp_x							= $size_x;
		$tmp_y							= $size_y;
		$ratio							= min($x / $tmp_x, $y / $tmp_y);
		$src_w							= $tmp_x * $ratio;
		$src_h							= $tmp_y * $ratio;
		$src_x							= floor(($x-$src_w) / 2);
        
		if ($src_x < 0)
		{ 
			$src_x						= 0;
			if ($tmp_x > $x)
				$tmp_x					= $x;
			$src_w						= $x;
		} 
		$src_y							= floor(($y - $src_h) / 2);
		if ($src_y < 0)
		{ 
			$src_y						= 0;
			if ($tmp_y > $y)
				$tmp_y					= $y;
			$src_h						= $y;
		}
		//print_r(self::$settings);
        if (self::$settings['postSettings']['imgBlur'] == 1 || $check == true)
            $dst_im							= imagecreatetruecolor($size_x, $size_y); // Создаем новое изображение
        else
            $dst_im 						= imagecreatetruecolor($x, $y);

		imagealphablending($dst_im, false); // непонятная фигня
		imagesavealpha($dst_im, true); // Сохранять информацию о альфа канале
		imagecopyresampled($dst_im, $im, 0, 0, $src_x, $src_y, $size_x, $size_y, $src_w, $src_h); // Ресемплирование 
        /*
        *Размытие краев изображения
        */
		$blur							= 3;
		$min_width						= ceil($size_x * pow(0.5, $blur)); 
		$min_height						= ceil($size_y * pow(0.5, $blur)); 
		$tmp_image						= $dst_im;
		$prev_width						= $size_x;
		$prev_height					= $size_y;
		for ($i = 0; $i < $blur; $i++)
		{ 
			$new_width					= $min_width * pow(2, $i);
			$new_height					= $min_height * pow(2, $i);
			$new_image					= imagecreatetruecolor($new_width, $new_height); 
			imagealphablending($new_image, false);
			imagesavealpha($new_image, true);
			imagecopyresampled($new_image, $tmp_image, 0, 0, 0, 0, $new_width, $new_height, $prev_width, $prev_height);
			imagefilter($new_image, IMG_FILTER_GAUSSIAN_BLUR);
			$tmp_image					= $new_image;
			$prev_width					= $new_width;
			$prev_height				= $new_height;
		} 
		imagecopyresized($dst_im, $new_image, 0, 0, 0, 0, $size_x, $size_y, $new_width, $new_height);
		imagefilter($dst_im, IMG_FILTER_GAUSSIAN_BLUR);
		imagefilter($dst_im, IMG_FILTER_BRIGHTNESS, 50);
		imagedestroy($new_image);
		if ($x < $tmp_x && $y < $tmp_y)
		{ 
			$dst_w						= $x; 
			$dst_h						= $y; 
			$dst_x						= floor(($size_x - $dst_w) / 2); 
			$dst_y						= floor(($size_y - $dst_h) / 2); 
		} 
		else 
		{ 
			$ratio						= max($x / ($size_x), $y / ($size_y));
			$dst_w						= ceil($x / $ratio);
			$dst_h						= ceil($y / $ratio);
			$dst_x						= floor(($size_x-$dst_w) / 2);
			$dst_y						= floor(($size_y-$dst_h) / 2);
		}
        if ($check == true)
            imagecopyresampled($dst_im, $im, $dst_h, $dst_w, 0, 0, $size_x, $size_y, $x, $y); 
        else
        {
            if (self::$settings['postSettings']['imgBlur'] == 1)
                imagecopyresampled($dst_im, $im, $dst_x, $dst_y, 0, 0, $dst_w, $dst_h, $x, $y); 
            else
                imagecopyresampled($dst_im, $im, 0, 0, 0, 0, $x, $y, $x, $y);
        }
		imagedestroy($im);
        if (self::$settings['postSettings']['imgMirror'] == 1)
            imageflip($dst_im, IMG_FLIP_HORIZONTAL);
        
        /*
        * Сохраняем новое изображение и возвращаем путь
        */
		if (!$addr)
			$new_file					= $tmp_file;
		else if ($social == 'vk')
			$new_file					= $PLINK_CONFIG['path_vk'].$this->sys->new_file_name($ext);
		else
			$new_file					= $PLINK_CONFIG['path_tw_fb'].$this->sys->new_file_name($ext);
		if ($ext == 'jpg')
			imagejpeg($dst_im, $_SERVER['DOCUMENT_ROOT'].$new_file, 75);
		else if ($ext == 'png')
			imagepng($dst_im, $_SERVER['DOCUMENT_ROOT'].$new_file, 7);
		else if ($ext == 'gif')
			imagegif($dst_im, $_SERVER['DOCUMENT_ROOT'].$new_file);
		imagedestroy($dst_im);

		if (filesize($_SERVER['DOCUMENT_ROOT'].$new_file))
		{
//			if (!$addr)
//			{
//				print_r($new_file);
//				exit();	
//			}
			return ($new_file);
		}
			
		return (NULL);
	}
}