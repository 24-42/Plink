<?php
class apivk{
	
	const METHOD_URL_VK 			= 'https://api.vk.com/method/wall.post?'; //Метод постинга сообщений
    const METHOD_URL_VKIMAGE 		= 'https://api.vk.com/method/photos.getWallUploadServer?'; //Метод получения сервера загрузок изображения
    const METHOD_URL_VKIMAGE_SAVE 	= 'https://api.vk.com/method/photos.saveWallPhoto?'; //Загружает изображение в группу
	protected $version_api='5.101';
	public $sys;
	
	function __construct(){
		$this->sys = new sys;	
	}
	
	public function setVkWall($post_id) {
		global $PLUGIN_CONFIG, $PLINK_CONFIG;
		
		$a          			= array('action' => 'getGround', 'groundId' => $PLINK_CONFIG['groundId'], 'type' => 1);
		$json       			= json_decode($this->sys->api($PLUGIN_CONFIG['core'], array($a)), true);
		
		$ground2   				= $json['getGround'][0];
		$ground 				= json_decode($ground2['paramsList'], true);
		
        $postData				= get_post($post_id);
        $title					= $postData->post_title;
        $text 					= $postData->post_content;
        $link_post 				= get_permalink($post_id); 
        $vkposter_id	 		= $ground['vkAutoPosting']['vkGroupId']; 
        $vkposter_userid		= $ground['vkAutoPosting']['vkUserId']; 
        $vkposter_token 		= $ground['vkAutoPosting']['vkGroupSecret']; 
        $postType 				= get_post_type($post_id);
		$description_meta 		= get_post_meta($post_id, 'description');


        $image 					= $this->setImageVK($text, $post_id)->id; 
		
        $text 					= str_replace('<!--more-->', '', strip_tags(strip_shortcodes($text))) . "\n\n";


        $text_clear = wp_kses($title, 'strip') . "\n\n " . wp_kses($text, 'strip');
		
        unset($text);
		$title_1k 		=  $description_meta[0];
            $argument = array(
                "owner_id"		=> $vkposter_id,
                "from_group"	=> 0,
                "message" 		=> $this->sys->clean_trash($title_1k),
                "attachments" 	=> $link_post
            );
        $result = $this->sentRequestVK(self::METHOD_URL_VK, $argument, $vkposter_token);
        return $result;
    }
	
	public function searchImageText($text) {
        $first_img = '';
        ob_start();
        ob_end_clean();
        $output 	= preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $text, $matches);
        $first_img 	= $matches [1] [0];
        $col1 		= strlen(WP_CONTENT_URL);
        $col2 		= strlen($first_img);
        $patch 		= substr($first_img, $col1, $col2);
        $result 	= WP_CONTENT_DIR . $patch;
        if (empty($first_img)) {
            return false;
        }
        return $result;
    }
	
	public function sentRequestVK($method, $arg, $vkposter_token) {
        $arg['access_token']	= $vkposter_token;
        $arg['v']				= $this->version_api;
        $query					= http_build_query($arg);
            $curlinfo 			= wp_remote_post($method, array('body' => $query));
            if (is_wp_error($curlinfo)) {
                $errMessage = $curlinfo->get_error_message();
                echo 'Ошибка отправки: ' . $errMessage;
            }
            return $curlinfo['body'];
    }
	
	public function setImageVK($text, $post_id) {
		$vkposter_id 			= $ground['vkAutoPosting']['vkGroupId']; //ID группы или пользователя
		$images_post 			= wp_get_attachment_url(get_post_thumbnail_id($post_id));
        $vkposter_token 		= $ground['vkAutoPosting']['vkGroupSecret']; //Токен приложения
        if (empty($images_post)) 
		{
            $media 				= get_attached_media('image', $post_id);
            $image 				= array_shift($media);
            print $images_post 	= get_attached_file($image->ID); //Изображение прикреплённое к посту
            if (empty($images_post)) {
                $images_post 	= $this->searchImageText($text); // Ищем изображение в тексте
                if (empty($images_post)) {
                    return false;
                }
            }
        }
        $argument = array(
            "group_id" 			=> trim($vkposter_id, '-'),
            "version" 			=> $this->version_api
        );
        $curlinfo = $this->sentRequestVK(self::METHOD_URL_VKIMAGE, $argument, $vkposter_token);
        unset($argument);

        if ($curlinfo) 
		{
            $UrlObj = json_decode($curlinfo);
            $urlimgvk = $UrlObj->response->upload_url;
        }
        if ($urlimgvk) 
		{
            $curl = curl_init();
			$_SESSION['test'] =  $urlimgvk;
            curl_setopt($curl, CURLOPT_URL, $urlimgvk);
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
			print $s = realpath(substr($images_post, 18));
			$file = new CURLFile($s);
            curl_setopt($curl, CURLOPT_POSTFIELDS, array('photo' => $file));
            $curlinfo = curl_exec($curl); //Результат запроса
            $response = curl_getinfo($curl); //Информация о запросе
            curl_close($curl);
            $imageObject = json_decode($curlinfo);
            if (!empty($imageObject->server) && !empty($imageObject->photo) && !empty($imageObject->hash)) 
			{
                $argument = array(
                    "group_id" => trim($vkposter_id, '-'),
                    "server" => $imageObject->server,
                    "photo" => $imageObject->photo,
                    "hash" => $imageObject->hash
                );
                $curlinfo = $this->sentRequestVK(self::METHOD_URL_VKIMAGE_SAVE, $argument, $vkposter_token);
                unset($argument);
                $resultObject = json_decode($curlinfo);
                if (isset($resultObject) && isset($resultObject->response[0]->id)) 
                    return $resultObject->response[0];
				else 
                    return false;
            }
        }
    }
}