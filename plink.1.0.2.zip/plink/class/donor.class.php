<?php
class donor
{
	function saveDonorSettings($arr)
	{	
		global $PLUGIN_CONFIG;
		
		$a										= array();
		//print_r($arr);
		$groundId								= $this->sys->array_val($arr, 'groundId');
		$donorId								= $this->sys->array_val($arr, 'donorId');
		array_push($a, array("add" => 0, "selector" => "#popUpGroundSettings",  "class" => "-1", "className" => "saving"));
		if (!is_numeric($groundId) || !is_numeric($donorId))
			return ($this->sys->msg("Ошибка. [D233141]", "Настройки донора", 1, $a));/*--error--*/
			
		$json = json_decode($this->sys->api($PLUGIN_CONFIG['core'], array(array('action' => 'getGround', 'type' => 1, 'groundId' => $groundId))), true);
		/*if (!$json['getGround'][0]['ground_id'])
			return ($this->sys->msg("Площадка за которой закреплен донор не найдена", "Настройки донора", 1, $a));*//*--error--*/
			
		$don = json_decode($this->sys->api($PLUGIN_CONFIG['core'], array(array('action' => 'getDonor', 'type' => 1, 'donorId' => $donorId))), true);
		//print_r($arr);
		if (!$don['getDonor'][0]['donor_id'])
			return ($this->sys->msg("Невозможно сохранить настройки, так как донор удален или отклонен модератором.", "Настройки донора", 1, $a));/*--error--*/
		
		$donor									= $don['getDonor'][0];
		$ground									= $json['getGround'][0];
			
		/*$groundUrl								= 'https://'.$ground['domain'].'/wp-content/plugins/plink/'.$this->sys->cleanVar($ground['hash']).'.php';
		$json 									= json_decode($this->sys->api($groundUrl, array(array('action' => 'checkFile'),array('action' => 'getWPUsers'), array('action' => 'getWPCategory'))), true);*/
		$wpUsers								= $this->api->getWpUsers();
		$wpCategory								= $this->api->getWpCategory();
		//print_r($wpCategory);
		
		if ($ground['act'] != 1 && $ground['act'] != 2)
			return ($this->sys->msg("Прежде чем сохранять настройки донора убедитесь, что площадка активирована.", "Настройки донора", 1, $a));/*--error--*/
			
		if ($donor['act'] == 3 || $donor['act'] == 5)
			return ($this->sys->msg("Невозможно сохранить настройки, так как донор удален.", "Настройки донора", 1, $a));/*--error--*/
			
		$inp 									= array('status', 'blockTitle', 'blockMetaD', 'blockMetaK', 'blockLogo', 'blockTags', 'blockText', 'donorUrl', 'donorCategory', 'donorAuthor', 'deleteIfNoLogo', 'deleteIfNoMedia', 'deleteIfInLinks', 'deleteIfOutLinks', 'titleMinLen', 'titleMaxLen', 'imagesInText', 'videoInText', 'audioInText', 'youtubeInText', 'facebookInText', 'instagramInText', 'twitterInText', 'iframeInText', 'textMinLen', 'textMaxLen', 'titlePrev', 'textPrev', 'sourcePrev', 'inLinksInText', 'outLinksInText', 'source', 'sourcePosition', 'sourceAdr', 'sourceIndex', 'postSetComments', 'postSetPing', 'timePostMinus', 'donorName', 'imgMinCount', 'imgMaxCount');
		$bigInp									= array('postsDayLimit', 'moneyDayLimit');
		$data									= array();
		foreach ($inp as $p)
			$data[$p]							= $this->sys->array_val($arr, $p);
		
		//	
		if ($data['status'] != 'on' && $data['status'] != '')
			return ($this->sys->msg("Ошибка. [D132624]".$data['status'], "Настройки площадки", 3, $a));/*--error--*/
		if ($data['status'] == 'on')
			$data['status'] = 1;
		if ($data['status'] == '')
			$data['status'] = 2;
		for ($i = 1; $i <= 1000; $i++)
		{
			$val = trim($this->sys->array_val($arr, 'form_proov_deleteLinksInText_num'.$i));
			
			$val = explode("_.@._", $val);

			if (empty($val[0]) && empty($val[1]))
				break ;
			$data['proovs']['deleteLinksInText'][] = array('url' => $val[0], 'text' => $val[1], 'deleteOuterBlock' => $val[2]);
			unset($val);
		}	
		for ($i = 1; $i <= 1000; $i++)
		{
			$val = trim($this->sys->array_val($arr, 'form_proov_deleteTitle_num'.$i));
			if (!$val)
				break ;
			$data['proovs']['stopTitleWords'][] = $val;
		}
		if (isset($data['proovs']['stopTitleWords']) && !empty($data['proovs']['stopTitleWords']))
			$data['proovs']['stopTitleWords'] = array_unique($data['proovs']['stopTitleWords']);
		for ($i = 1; $i <= 1000; $i++)
		{
			$val = trim($this->sys->array_val($arr, 'form_proov_deleteText_num'.$i));
			if (!$val)
				break ;
			$data['proovs']['stopTextWords'][] = $val;
		}
		if (isset($data['proovs']['stopTextWords']) && !empty($data['proovs']['stopTextWords']))
			$data['proovs']['stopTextWords'] = array_unique($data['proovs']['stopTextWords']);
		for ($i = 1; $i <= 1000; $i++)
		{
			$val = trim($this->sys->array_val($arr, 'form_proov_deleteString_num'.$i));
			if (!$val)
				break ;
			$data['proovs']['stopStringWords'][] = $val;
		}
		if (isset($data['proovs']['stopStringWords']) && !empty($data['proovs']['stopStringWords']))
			$data['proovs']['stopStringWords'] = array_unique($data['proovs']['stopStringWords']);
		for ($i = 1; $i <= 1000; $i++)
		{
			$val = trim($this->sys->array_val($arr, 'form_proov_replaceInTitle_num'.$i));
			if (!$val)
				break ;
			$val = explode("_.@._", $val);
			$data['proovs']['replaceTitleWords'][] = array('find' => $val[0], 'replace' => $val[1]);
		}
		if (isset($data['proovs']['replaceTitleWords']) && !empty($data['proovs']['replaceTitleWords']))
			$data['proovs']['replaceTitleWords'] = array_unique($data['proovs']['replaceTitleWords']);
		for ($i = 1; $i <= 1000; $i++)
		{
			$val = trim($this->sys->array_val($arr, 'form_proov_replaceInText_num'.$i));
			if (!$val)
				break ;
			$val = explode("_.@._", $val);
			$data['proovs']['replaceTextWords'][] = array('find' => $val[0], 'replace' => $val[1]);
		}
		if (isset($data['proovs']['replaceTextWords']) && !empty($data['proovs']['replaceTextWords']))
			$data['proovs']['replaceTextWords'] = array_unique($data['proovs']['replaceTextWords']);
		if(!stristr($data['titlePrev'], '{TITLE}'))
			$data['titlePrev'] = '{TITLE}';
			
		if(!stristr($data['textPrev'], '{TEXT}'))
			$data['textPrev'] = '{TEXT}';
		if(!stristr($data['sourcePrev'], '{SOURCE}'))
			$data['sourcePrev'] = '{SOURCE}';
		$i = 1;
		//print_r($data);
		$donorCategory = array();
		
		foreach($wpCategory as $c)
		{
			$cat = $this->sys->array_val($arr, 'category'.$i);
			
			if ($cat == 1)
				$donorCategory[] = $c->cat_ID;
			$i++;
			unset($cat);
		}

		$donorCategory = array_unique($donorCategory);
			
		if (!is_numeric($data['timePostMinus']) || $data['timePostMinus'] > 20080 || $data['timePostMinus'] < -20080)
			$data['timePostMinus'] = -3600;
		$donorParams 							= json_decode($donor['donorParams'], true);
		
		$issetBlocks							= array('title' => '1', 'meta_d' => $data['blockMetaD'], 'meta_k' => $data['blockMetaK'], 'logo' => $data['blockLogo'], 'tags' => $data['blockTags'], 'text' => '1');
		$stop									= array('nologo' => $data['deleteIfNoLogo'], 'inlinks' => $data['deleteIfInLinks'], 'outlinks' => $data['deleteIfOutLinks'], 'nomedia' => $data['deleteIfNoMedia']);
		$length									= array('titleMinLen' => $data['titleMinLen'], 'titleMaxLen' => $data['titleMaxLen'], 'textMinLen' => $data['textMinLen'], 'textMaxLen' => $data['textMaxLen']);
		$mediaInText							= array('images' => $data['imagesInText'], 'video' => $data['videoInText'], 'audio' => $data['audioInText'], 'youtube' => $data['youtubeInText'], 'facebook' => $data['facebookInText'], 'instagram' => $data['instagramInText'], 'twitter' => $data['twitterInText'], 'iframe' => $data['iframeInText']);
		$textLinks								= array('in' => $data['inLinksInText'], 'out' => $data['outLinksInText']);
		$sourse									= array('source' => $data['source'], 'position' => $data['sourcePosition'], 'address' => $data['sourceAdr'], 'index' => $data['sourceIndex']);
		$paramsList 							= array(
				'domain'					=> $donor['domain'],
				'url'						=> $donor['url'],
				'donorInfo'					=> $donorParams['donorInfo'],
				'titlePrev'					=> htmlspecialchars($data['titlePrev']),
				'textPrev'					=> htmlspecialchars($data['textPrev']),
				'sourcePrev'				=> htmlspecialchars($data['sourcePrev']),
				'parseBlocks'				=> $issetBlocks,
				'stopPost'					=> $stop,
				'postLength'				=> $length,
				'postImg'						=> array('imgMinCount' => $data['imgMinCount'], 'imgMaxCount' => $data['imgMaxCount']),
				'category'					=> $donorCategory,
				'author'					=> $data['donorAuthor'],
				'mediaContent'				=> $mediaInText,
				'postSet'					=> array('comments' => $data['postSetComments'], 'ping' => $data['postSetPing']),
				'linksInText'				=> $textLinks,
				'source'					=> $sourse,
				'proovs'					=> $data['proovs'],
				'timePostMinus'				=> $data['timePostMinus']
			);
		//print_r($paramsList);
		$dataArray = array(
			'act'								=> $data['status'],
			'donorParams'						=> json_encode($paramsList, JSON_UNESCAPED_UNICODE)
		);

		$answer = $this->sys->api($PLUGIN_CONFIG['core'], array(array('action' => 'editDonor', 'donorId' => $donor['donor_id'], 'data' => $dataArray)));
		//print $answer;
		$json									= json_decode($answer, true);
		$x = array(array('action' => 'editDonor', 'donorId' => $donor['donor_id'], 'data' => $dataArray));
		
		//print_r($x);
			//print_r($json);
	
		if ($json['editDonor'][0]['donor_id'])
		{
			//print 1;
			return ($this->sys->msg("Настройки донора успешно сохранены", "Настройки донора", 2, $a));
		}
		return $a;
	}
	
	function initAddDonors($arr)
	{
		global $PLUGIN_CONFIG;
		
		$groundId 					= $this->sys->array_val($arr, "groundId");
		$donorsList 				= $this->sys->array_val($arr, "donorsList");
		$a 							= array();
//		if (!$groundId)
//		{
//			array_push($a, array("add" => 9, "selector" => "#popUpAddDonors"));
//			return ($this->sys->msg("Ошибка. [D203712]", "Добавление доноров", 1, $a));	
//		}
		if (is_numeric($groundId))
		{
//			$userId					= $this->users->get_my_uid();
			$json 					= json_decode($this->sys->api($PLUGIN_CONFIG['core'], array(array('action' => 'getGround', 'groundId' => $groundId, 'type' => 1))), true);
			$ground 				= $json['getGround'][0];
			
			if (!$ground['ground_id'])
				return ($this->sys->msg("Ошибка, площадка не найдена.", "Добавление доноров", 1, $a));	
//			if ($ground['userId'] != $userId)
//			{
//				array_push($a, array("add" => 9, "selector" => "#popUpGroundSettings"));
//				return ($this->sys->msg("У вас нет прав для добавления доноров к данной площадке.", "Добавление доноров", 1, $a));	
//			}
			if ($ground['act'] != 1 && $ground['act'] != 2)
				return ($this->sys->msg("Ошибка, статус площадки не позволяет добавлять доноров.", "Добавление доноров", 1, $a));	
				
			$groundUrl				= 'https://'.$ground['domain'].'/wp-content/plugins/plink/'.$this->sys->cleanVar($ground['hash']).'.php';
//			$json 					= json_decode($this->sys->api($groundUrl, array(array('action' => 'checkFile'), array('action' => 'getWPUsers'), array('action' => 'getWPCategory'))), true);
//			$checkFile				= $json['checkFile'][0];
			$wpUsers				= $this->api->getWpUsers();
			
			$wpCategory				= $this->api->getWpCategory();
//			if (!isset($checkFile['fileCheck']) && $checkFile['fileCheck'] != 1)
//				return ($this->sys->msg("Перед добавлением доноров необходимо устновить и активировать WP-плагин для площадки.", "Добавление доноров", 1, $a));
			$Dx = explode("\n", $donorsList);
			$cleanedDonList = array();
			foreach ($Dx as $x)
			{
				$x = filter_var($x, FILTER_SANITIZE_URL);
				if (strlen($x))
				{
					if (!filter_var($x, FILTER_VALIDATE_URL))
						$a = $this->sys->msg("Некоторые доноры не добавлены из-за ошибки валидации URL.", "Добавление доноров", 1, $a);
					else
						$cleanedDonList[] = $x;
				}
			}
			if (!count($cleanedDonList))
				return ($this->sys->msg("Список доноров пуст.", "Добавление доноров", 1, $a));
			$cleanedDonList = array_unique($cleanedDonList);
			array_push($a, array("add" => 0, "selector" => "#popUpAddDonors",  "class" => "-1", "className" => "load"));
			include(PATH_TO_SITE.'/wp-content/plugins/plink/admin/partials/addDonorsFinish.php');
			//print $html;
			
			array_push($a, array("add" => 3, "selector" => "#popUpAddDonors .aDdContent", "html" => $html));
			
			array_push($a, array("add" => 0, "selector" => "#popUpAddDonors .addDonContent",  "class" => "1", "className" => "displayNone"));
			array_push($a, array("add" => 0, "selector" => "#popUpAddDonors .aDdContent",  "class" => "-1", "className" => "displayNone"));
			array_push($a, array("add" => 17, "selector" => "body"));
			return ($this->sys->msg("Проверьте введеные данные и завершите добавление новых доноров.", "Добавление доноров", 3, $a));
		}
		return ($this->sys->msg("Ошибка. [D001113]", "Добавление доноров", 1, $a));
	}
	
	function addDonors($arr)
	{
		global $PLUGIN_CONFIG, $PLINK_CONFIG;
		
		$donorCount 					= $this->sys->array_val($arr, "donorCount");
		$groundId 						= $this->sys->array_val($arr, "groundId");
		$wpCategory 					= $this->sys->array_val($arr, "wpCategory");
		if (isset($wpCategory))
			$wpCategory					= json_decode($wpCategory, true);
		$userId							= $PLINK_CONFIG['userId'];
		$good							= array();
		$bad							= array();
		if (!$userId)
			return ($this->sys->msg("Ошибка, авторизируйтесь.", "Добавление доноров", 1, $a));
		$a								= array();
		if (!$donorCount || $donorCount < 1)
			return ($this->sys->msg("Список доноров пуст.", "Добавление доноров", 1, $a));
		for ($i = 1; $i <= $donorCount; $i++)
		{
			$a[] = array('url' => $this->sys->array_val($arr, "donor".$i), 'category' => $this->sys->array_val($arr, "donCat_donNUM".$i), 'author' => $this->sys->array_val($arr, "donUser_donNUM".$i), 'status' => $this->sys->array_val($arr, "donStat_donNUM".$i));
		}

		$i = 1;
		foreach ($a as $d)
		{
			$domain = parse_url($d['url']);
			$catList = array();
			if(isset($wpCategory))
			{
				foreach ($wpCategory as $cat)
				{
					$val = $this->sys->array_val($arr, "category".$i."_".$cat['id']);
					if ($val == 1)
						$catList[] = $cat['id'];
				}
			}
			
			$issetBlocks							= array('title' => '1', 'meta_d' => 1, 'meta_k' => 1, 'logo' => 1, 'tags' => 1, 'text' => '1');
			$stop									= array('nologo' => 0, 'inlinks' => 0, 'outlinks' => 0, 'nomedia' => 0);
			$length									= array('titleMinLen' => '', 'titleMaxLen' => '', 'textMinLen' => '', 'textMaxLen' => '');
			$mediaInText							= array('images' => 1, 'video' => 1, 'audio' => 1, 'youtube' => 1, 'facebook' => 1, 'instagram' => 1, 'twitter' => 1, 'iframe' => 1);
			$textLinks								= array('in' => 0, 'out' => 1);
			$sourse									= array('source' => 1, 'position' => 4, 'address' => 2, 'index' => 1);
			$paramsList 							= array(
					'domain'					=> $domain['host'],
					'url'						=> $d['url'],
					'donorInfo'					=> array('afterModer' => $d['status']),
					'titlePrev'					=> '{TITLE}',
					'textPrev'					=> '{TEXT}',
					'sourcePrev'				=> '{SOURCE}',
					'parseBlocks'				=> $issetBlocks,
					'stopPost'					=> $stop,
					'postLength'				=> $length,
					'category'					=> $catList,
					'author'					=> $d['author'],
					'mediaContent'				=> $mediaInText,
					'postSet'					=> array('comments' => 1, 'ping' => 1),
					'linksInText'				=> $textLinks,
					'source'					=> $sourse,
					'proovs'					=> array(),
					'timePostMinus'				=> -3600
				);
			$dataArray = array(
				'url'								=> $d['url'],
				'domain'							=> $domain['host'],
				'act'								=> 4,
				'ground'							=> $groundId,
				'userId'							=> $userId,
				'donorParams'						=> json_encode($paramsList)
			);
			$x = array(array('action' => 'addDonor', 'type' => '1', 'groundId' => $groundId, 'data' => $dataArray));
			$json									= json_decode($this->sys->api($PLUGIN_CONFIG['core'], $x), true);
			//print_r($json);
			if ($json['addDonor'][0] == -5)
				$bad[] = $dataArray;
			else if ($json['addDonor'][0]['donor_id'])
				$good[] = $dataArray;
			$i++;
		}
		$good_count = count($good);
		$bad_count = count($bad);
		//print $good_count;
		$json 					= json_decode($this->sys->api($PLUGIN_CONFIG['core'], array(array('action' => 'getGround', 'groundId' => $groundId, 'type' => 1))), true);
		$ground 				= $json['getGround'][0];
		include(PATH_TO_SITE.'/wp-content/plugins/plink/admin/partials/addDonorsFinish_send.php');
		$a = array();
		array_push($a, array("add" => 0, "selector" => "#popUpAddDonors .aDdContent",  "class" => "1", "className" => "displayNone"));
		array_push($a, array("add" => 0, "selector" => "#popUpAddDonors .aDdResult",  "class" => "-1", "className" => "displayNone"));
		array_push($a, array("add" => 3, "selector" => "#popUpAddDonors .aDdResult", "html" => $html));
		return ($a);
	}
	
	function offDonorList()
	{
		global $PLUGIN_CONFIG;
		
		$a								= array();
		$groundId 						= $_POST['groundId'];
		if (!is_numeric($groundId))
		{
			array_push($a, array("add" => 9, "selector" => "#popUpOperDonors"));
			return ($this->sys->msg("Ошибка. [D014014]", "Отключение доноров", 1, $a));
		}
		$checkList 				= $_POST['checkList'];
		if (!count($checkList))
		{
			array_push($a, array("add" => 9, "selector" => "#popUpOperDonors"));
			return ($a);
		}
		
		$json 					= json_decode($this->sys->api($PLUGIN_CONFIG['core'], array(array('action' => 'getDonorList', 'groundId' => $groundId, 'type' => 1))), true);
		$donors 				= $json['getDonorList'][0];
		
		include(PATH_TO_SITE.'/wp-content/plugins/plink/admin/partials/donorOffList.php');
		array_push($a, array("add" => 3, "selector" => "#popUpOperDonors .resultOper", "html" => $html));
		return $a;
	}
	
	function onDonorList()
	{
		global $PLUGIN_CONFIG, $PLINK_CONFIG;
		
		$a								= array();
		$groundId 						= $_POST['groundId'];
		if (!is_numeric($groundId))
		{
			array_push($a, array("add" => 9, "selector" => "#popUpOperDonors"));
			return ($this->sys->msg("Ошибка. [D014014]", "Включение доноров", 1, $a));
		}
		$checkList 				= $_POST['checkList'];
		if (!count($checkList))
		{
			array_push($a, array("add" => 9, "selector" => "#popUpOperDonors"));
			return ($a);
		}
		
		$json 					= json_decode($this->sys->api($PLUGIN_CONFIG['core'], array(array('action' => 'getDonorList', 'groundId' => $groundId, 'type' => 1))), true);
		$donors 				= $json['getDonorList'][0];
		
		include(PATH_TO_SITE.'/wp-content/plugins/plink/admin/partials/donorOnList.php');
		array_push($a, array("add" => 3, "selector" => "#popUpOperDonors .resultOper", "html" => $html));
		return $a;
	}
	
	function offDonors()
	{
		global $PLUGIN_CONFIG, $PLINK_CONFIG;
		
		$a								= array();
		$groundId 						= $_POST['groundId'];
		$checkList						= $_POST['donorList'];
		if (!is_numeric($groundId))
		{
			array_push($a, array("add" => 9, "selector" => "#popUpOperDonors"));
			return ($this->sys->msg("Ошибка. [D003815]", "Выключение доноров", 1, $a));
		}
		$userId					= $PLINK_CONFIG['userId'];
		$json 					= json_decode($this->sys->api($PLUGIN_CONFIG['core'], array(array('action' => 'getGround', 'groundId' => $groundId, 'type' => 1), array('action' => 'getDonorList', 'groundId' => $groundId, 'type' => 1))), true);
		$ground 				= $json['getGround'][0];
		$donorList 				= $json['getDonorList'][0];
		
		if (!count($donorList))
			return ($this->sys->msg("Доноры не найдены.", "Выключение доноров", 1, $a));	
		if (!$ground['ground_id'])
			return ($this->sys->msg("Ошибка, площадка не найдена.", "Выключение доноров", 1, $a));
		if ($ground['act'] == 3)
			return ($this->sys->msg("Ошибка, площадка удалена.", "Выключение доноров", 1, $a));	
		if ($ground['userId'] != $userId )
		{
			array_push($a, array("add" => 9, "selector" => "#popUpGroundSettings"));
			return ($this->sys->msg("У вас нет прав для выключения доноров у данной площадки.", "Выключение доноров", 1, $a));	
		}
		$ar = array();
		foreach ($donorList as $d)
			foreach($checkList as $c)
				if ($c == $d['donor_id'] && $d['act'] == 1)
					$ar[] = array('action' => 'editDonor', 'donorId' => $d['donor_id'], 'data' => array('act' => 2));
		$unswer					= $this->sys->api($PLUGIN_CONFIG['core'], $ar);
		$json 					= json_decode($unswer, true);
		if (is_array($json['editDonor']))
		{
			$countDonor = count($json['editDonor']);
			array_push($a, array("add" => 9, "selector" => "#popUpOperDonors"));
			return ($this->sys->msg("Доноры успешно выключены. [$countDonor шт.]", "Выключение доноров", 2, $a));		
		}
		return ($this->sys->msg("Ошибка. Доноры либо удалены, либо находятся в данный момент на модерации.", "Выключение доноров", 1, $a));
	}
	
	function onDonors()
	{
		global $PLUGIN_CONFIG, $PLINK_CONFIG;
		
		$a								= array();
		$groundId 						= $_POST['groundId'];
		$checkList						= $_POST['donorList'];
		if (!is_numeric($groundId))
		{
			array_push($a, array("add" => 9, "selector" => "#popUpOperDonors"));
			return ($this->sys->msg("Ошибка. [D005305]", "Включение доноров", 1, $a));
		}
		$userId					= $PLINK_CONFIG['userId'];
		$json 					= json_decode($this->sys->api($PLUGIN_CONFIG['core'], array(array('action' => 'getGround', 'groundId' => $groundId, 'type' => 1), array('action' => 'getDonorList', 'groundId' => $groundId, 'type' => 1))), true);
		$ground 				= $json['getGround'][0];
		$donorList 				= $json['getDonorList'][0];
		
		if (!count($donorList))
			return ($this->sys->msg("Доноры не найдены.", "Включение доноров", 1, $a));	
		if (!$ground['ground_id'])
			return ($this->sys->msg("Ошибка, площадка не найдена.", "Включение доноров", 1, $a));
		if ($ground['act'] == 3)
			return ($this->sys->msg("Ошибка, площадка удалена.", "Включение доноров", 1, $a));	
		if ($ground['userId'] != $userId )
		{
			array_push($a, array("add" => 9, "selector" => "#popUpGroundSettings"));
			return ($this->sys->msg("У вас нет прав для включения доноров у данной площадки.", "Включение доноров", 1, $a));	
		}
		$ar = array();
		foreach ($donorList as $d)
			foreach($checkList as $c)
				if ($c == $d['donor_id'] && $d['act'] == 2)
					$ar[] = array('action' => 'editDonor', 'donorId' => $d['donor_id'], 'data' => array('act' => 1));
		$unswer					= $this->sys->api($PLUGIN_CONFIG['core'], $ar);
		$json 					= json_decode($unswer, true);
		if (is_array($json['editDonor']))
		{
			$countDonor = count($json['editDonor']);
			array_push($a, array("add" => 9, "selector" => "#popUpOperDonors"));
			return ($this->sys->msg("Доноры успешно включены. [$countDonor шт.]", "Включение доноров", 2, $a));		
		}
		return ($this->sys->msg("Ошибка. Доноры либо удалены, либо находятся в данный момент на модерации.", "Включение доноров", 1, $a));
	}
	
	function deleteDonors()
	{
		global $PLINK_CONFIG, $PLUGIN_CONFIG;
		
		$a								= array();
		$groundId 						= $_POST['groundId'];
		$checkList						= $_POST['donorList'];
		if (!is_numeric($groundId))
		{
			array_push($a, array("add" => 9, "selector" => "#popUpOperDonors"));
			return ($this->sys->msg("Ошибка. [D231714]", "Удаление доноров", 1, $a));
		}
		$userId					= $PLINK_CONFIG['userId'];
		$json 					= json_decode($this->sys->api($PLUGIN_CONFIG['core'], array(array('action' => 'getGround', 'groundId' => $groundId, 'type' => 1), array('action' => 'getDonorList', 'groundId' => $groundId, 'type' => 1))), true);
		$ground 				= $json['getGround'][0];
		$donorList 				= $json['getDonorList'][0];
		
		if (!count($donorList))
			return ($this->sys->msg("Доноры не найдены.", "Удаление доноров", 1, $a));	
		if (!$ground['ground_id'])
			return ($this->sys->msg("Ошибка, площадка не найдена.", "Удаление доноров", 1, $a));
		if ($ground['act'] == 3)
			return ($this->sys->msg("Ошибка, площадка удалена.", "Удаление доноров", 1, $a));	
		if ($ground['userId'] != $userId )
		{
			array_push($a, array("add" => 9, "selector" => "#popUpGroundSettings"));
			return ($this->sys->msg("У вас нет прав для удаления доноров у данной площадки.", "Удаление доноров", 1, $a));	
		}
		$ar = array();
		foreach ($donorList as $d)
		{
			foreach($checkList as $c)
			{
				if ($c == $d['donor_id'])
				{
					$ar[] = array('action' => 'editDonor', 'donorId' => $d['donor_id'], 'data' => array('act' => 3));
					array_push($a, array("add" => 0, "selector" => ".clientBlock.c".$ground['ground_id']." .oneDonor.don".$d['donor_id'],  "class" => "1", "className" => "displayNone"));
				}
			}
		}
		$unswer					= $this->sys->api($PLUGIN_CONFIG['core'], $ar);
		$json 					= json_decode($unswer, true);
		if (is_array($json['editDonor']))
		{
			if (count($donorList) == count($ar))
				array_push($a, array("add" => 0, "selector" => ".clientBlock.c".$ground['ground_id'],  "class" => "1", "className" => "noDonors"));
			$countDonor = count($json['editDonor']);
			array_push($a, array("add" => 9, "selector" => "#popUpOperDonors"));
			return ($this->sys->msg("Доноры успешно удалены. [$countDonor шт.]", "Удаление доноров", 2, $a));		
		}
		return ($this->sys->msg("Ошибка. Доноры были удалены ранее, либо перемещены к другой площадке.", "Удаление доноров", 1, $a));
	}
	
	function deleteDonorList()
	{
		global $PLUGIN_CONFIG;
		
		$a								= array();
		$groundId 						= $_POST['groundId'];
		if (!is_numeric($groundId))
		{
			array_push($a, array("add" => 9, "selector" => "#popUpOperDonors"));
			return ($this->sys->msg("Ошибка. [D140506]", "Удаление доноров", 1, $a));
		}
		$checkList 				= $_POST['checkList'];
		if (!count($checkList))
		{
			array_push($a, array("add" => 9, "selector" => "#popUpOperDonors"));
			return ($a);
		}
		
		$json 					= json_decode($this->sys->api($PLUGIN_CONFIG['core'], array(array('action' => 'getDonorList', 'groundId' => $groundId, 'type' => 1))), true);
		$donors 				= $json['getDonorList'][0];
		
		include(PATH_TO_SITE.'/wp-content/plugins/plink/admin/partials/deleteDonorList.php');
		array_push($a, array("add" => 3, "selector" => "#popUpOperDonors .resultOper", "html" => $html));
		return $a;
	}
	
	function statPopUp()
	{
		global $PLUGIN_CONFIG, $PLINK_CONFIG;
		
		$a								= array();
		
		$groundId 						= $_POST['groundId'];
		$donorId 						= $_POST['donorId'];
		$statType						= $_POST['statType'];
		$days							= $_POST['days'];
		$userId							= $PLINK_CONFIG['userId'];
		if (!is_numeric($groundId) || !is_numeric($donorId) || ($days != 7 && $days != 31 && $days != 182 && $days != 365) || ($statType != 'donor' && $statType != 'ground'))
		{
			array_push($a, array("add" => 9, "selector" => "#popUpStat"));
			return ($this->sys->msg("Ошибка. [C195623]", "Статистика", 1, $a));
		}
		$q								= array(array('action' => 'getGround', 'groundId' => $groundId, 'type' => 1));
		if ($statType == 'donor')
		{
			$q[]						= array('action' => 'getDonor', 'donorId' => $donorId, 'type' => 1);
			$type						= 2;
		}
		else
			$type						= 1;
		$q[]							= array('action' => 'getStat', 'type' => $type, 'groundId' => $groundId, 'donorId' => $donorId, 'days' => $days);
		$q[] 							= array('action' => 'getCurrentBalance', 'user_id' => $PLINK_CONFIG['userId']);
//		print_r($q);
//		exit();
		$json 							= json_decode($this->sys->api($PLUGIN_CONFIG['core'], $q), true);
		
		$ground 						= $json['getGround'][0];
		$donor 							= $json['getDonor'][0];
		$stat 							= $json['getStat'][0];
		$user_balance 					= $json['getCurrentBalance'][0]['money'];
//		print_r($json);
//		exit();
		if (!$ground['ground_id'])
		{
			array_push($a, array("add" => 9, "selector" => "#popUpStat"));
			return ($this->sys->msg("Ошибка, площадка не найдена.", "Статистика", 1, $a));	
		}
		if ($ground['userId'] != $userId)
		{
			array_push($a, array("add" => 9, "selector" => "#popUpStat"));
			return ($this->sys->msg("У вас нет прав для просмотра статистики.", "Статистика", 1, $a));	
		}
		if ($statType == 'donor' && (!$donor['donor_id'] || $donor['act'] == 3))
		{
			array_push($a, array("add" => 9, "selector" => "#popUpStat"));
			return ($this->sys->msg("Ошибка, донор удален.", "Статистика", 1, $a));
		}
		if ($statType == 'donor' && ($donor['ground'] != $ground['ground_id']))
		{
			array_push($a, array("add" => 9, "selector" => "#popUpStat"));
			return ($this->sys->msg("У вас нет прав для просмотра статистики.", "Статистика", 1, $a));
		} 
		//if($statType == 'donor')
		include(PATH_TO_SITE.'/wp-content/plugins/plink/admin/partials/donorStat.php');
		if ($statType == 'donor')
			array_push($a, array("add" => 16,	"selector"	=> "#popUpStat"));
		array_push($a, array("add" => 3,	"selector"	=> "#popUpStat .popUpAjaxContent",	"html" => $html));	
		array_push($a, array("add" => 0,	"selector"	=> "#popUpStat",  "class" => "-1", "className" => "load"));
		return $a;
	}
	
	function addDonorsFromCatalog()
	{
		global $PLUGIN_CONFIG, $PLINK_CONFIG;
		
		$a								= array();
		array_push($a, array("add" => 0, "selector" => ".loaderInPopUp",  "class" => "1", "className" => "displayNone"));
		$checkList 				= $_POST['checkList'];
		if (!count($checkList))
		{
			array_push($a, array("add" => 9, "selector" => "#popUpOperDonors"));
			return ($a);
		}
		$x						= $this->sys->api($PLUGIN_CONFIG['core'], array(
			array('action' => 'getGroundList', 'clientId' => $PLINK_CONFIG['userId'], 'start' => 0), array('action' => 'getDonorList', 'type' => 2, 'donorIdList' => $checkList)
		));
		
		$json 					= json_decode($x, true);
		$grounds 				= $json['getGroundList'][0];
		$donors 				= $json['getDonorList'][0];
		include(PATH_TO_SITE.'/wp-content/plugins/plink/admin/partials/help/donorAddList.php');
		array_push($a, array("add" => 3, "selector" => "#popUpOperDonors .resultOper", "html" => $html));
		return $a;
	}
	
	function confirmAddDonorsFromCatalog()
	{
		global $PLUGIN_CONFIG, $PLINK_CONFIG;
	//	print_r($_POST);
		$a								= array();
		array_push($a, array("add" => 0, "selector" => "#popUpOperDonors",  "class" => "-1", "className" => "wait"));
		$groundId 						= $_POST['newGround'];
		$checkList						= $_POST['donorList'];
		if (!is_numeric($groundId))
		{
			array_push($a, array("add" => 9, "selector" => "#popUpOperDonors"));
			return ($this->sys->msg("Ошибка. [D213819]", "Добавление доноров из каталога", 1, $a));
		}
		$userId					= $PLINK_CONFIG['userId'];
		$json 					= json_decode($this->sys->api($PLUGIN_CONFIG['core'], array(array('action' => 'getGround', 'groundId' => $groundId, 'type' => 1), array('action' => 'addDonorsFromCatalog', 'groundId' => $groundId, 'catalogIdList' => $checkList))), true);
		$donorList 				= $json['addDonorsFromCatalog'][0];
		
		$good_count = 0;
		if ($donorList['good'] != -1)
			$good_count			 	= count($donorList['good']);
		//print_r($donorList);
		$bad_count			 	= count($donorList['bad']);
		$msgRet 				= '';
		include(PATH_TO_SITE.'/wp-content/plugins/plink/admin/partials/help/addedDonorsListFromCatalog.php');
		
		//getGround($groundId = NULL, $type = 1)  $json['getGround'][0]
		array_push($a, array("add" => 3, "selector" => "#popUpOperDonors .resultOper", "html" => $html));
		//array_push($a, array("add" => 9, "selector" => "#popUpPostControl"));
		if ($donorList['good'] != 0 && $good_count > 0)
		{
			$msgRet .= 'Добавлено: '.$good_count.' шт.';
			if ($donorList['bad'] != 0 && $bad_count > 0)
				$msgRet .= '<br>';
		}
		if ($donorList['bad'] != 0 && $bad_count > 0)
		{
			$msgRet .= 'Отклонено: '.$bad_count.' шт.';
		}
		return ($this->sys->msg($msgRet, "Добавление доноров из каталога", 3, $a));
	} 
}