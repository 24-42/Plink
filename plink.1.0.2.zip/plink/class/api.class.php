<?php
class api
{
	protected $json;
	public $settings;
	function __construct($code = false) 
	{
		global $PLINK_CONFIG, $PLUGIN_CONFIG;
		
		$this->sys 										= new sys;
		$this->img 										= new img;
		$this->add 										= new add;
		
		
		$this->result 									= array();
		
		if ($code)
			$this->result 								= array('code' => 200);
		//$_POST[] = array('action' => 'addWPPosts', 'data' => '1,2,3,4,5');
//				print 1;
//		exit();
		//$this->result['code'] = 201;
		foreach ($_POST as $p)
		{
			if (isset($p['action']) && $p['action'] == 'checkFile')
				$this->result['checkFile'][] 			= $this->checkFile();
			if (isset($p['action']) && $p['action'] == 'getWPUsers')
				$this->result['getWPUsers'][] 			= $this->getWPUsers();
			if (isset($p['action']) && $p['action'] == 'getWPCategory')
				$this->result['getWPCategory'][] 		= $this->getWPCategory();
			if (isset($p['action']) && $p['action'] == 'addWPPosts' && isset($p['data']))
				$this->result['addWPPosts'][] 			= $this->addWPPosts($p['data']);
			if (isset($p['action']) && $p['action'] == 'getWPPosts' && isset($p['data']))
				$this->result['getWPPosts'][] 			= $this->getWPPosts($p['data']);
			if (isset($p['action']) && $p['action'] == 'deleteWPPosts' && isset($p['data']))
				$this->result['deleteWPPosts'][] 		= $this->deleteWPPosts($p['data']);
		}
	}
	
	function addWPPosts($data)
	{
		$posts_id 										= array();
		$posts_out 			= array();
		$i = 0;

		$groundSettings = array();
		$groundSettings['postSettings'] 	= $data[0]['postSettings'];
		$groundSettings['vkAutoPosting'] 	= $data[0]['vkAutoPosting'];
		if ($groundSettings)
			$this->sys->checkGroundSettings($groundSettings);
		$arr = array();

//		print_r($data);
//		exit();
		foreach($data as $post)
		{

			if ($post['count_img'] > 0)
				$post['post_status'] = 'pending';
			$p								= $this->img->resave_img($post);
			if ($p['post_content'] && !empty($p['post_content']))
			{
				if(isset($p['debug_post']) && $p['debug_post'] == 1)
					$p['post_title'] .= 'TEST_'.mt_rand(1, 1000);
				if (isset($p['meta_input']['title_dig']) && !empty($p['meta_input']['title_dig']))
					$title_dig = $p['meta_input']['title_dig'];

	
				if (isset($title_dig) && !empty($title_dig))
					$checked_post = $this->sys->getPostIdByMetaKey('title_dig', $title_dig);
				if (empty($checked_post))
					$wp_post_id = $this->add->insert_post($p);

				$view_time = time() + $p['timePostMinus'] * 60;
				if (!empty($wp_post_id) && empty($checked_post))
					$posts_id[] 							= array('linkDig' => $post['linkDig'], 'wp_post_id' => $wp_post_id, 'grubber_id' => $post['grubber_id'], 'view_time' => $view_time);
				else if (!empty($checked_post))
					$posts_id[] 							= array('grubber_id' => $post['grubber_id'], 'added' => 1, 'wp_post_id' => $checked_post['post_id'], 'linkDig' => $post['linkDig']);
			}
		}
		if (isset($posts_id) && !empty($posts_id))
			return ($posts_id);
	}
	
	static function getWPUsers()
	{
		if (count(($users 								= get_users(array('role__in' => array('administrator', 'editor', 'author'))))))
			return ($users);
		return -1;
	}
	
	static function getWPCategory()
	{
		$categories 									= get_categories( array(
					"hide_empty" 						=> 0,
                    "type"      						=> "post",      
                    "orderby"   						=> "name",
                    "order"     						=> "ASC" 
		));
		if (count($categories))
			return ($categories);
		return -1;
	}
	
	function getWPPosts($listID)
	{
		//print_r($listID);
		$args 											= array(
	                'numberposts'      					=> count($listID),
	                'orderby'          					=> 'date',
	                'order'            					=> 'DESC',
	                'include'          					=> $listID,
	                'post_type'        					=> 'post',
					'post_status' 						=> 'publish, pending'
	     );
	
		$posts 											= get_posts($args);
//			print_r($posts);
//		exit();

		if (count($posts))
			return ($posts);
		return -1;
	}
	
	function deleteWPPosts($listID)
	{
		$p = array();
		foreach($listID as $lID)
		{
			if (is_numeric($lID))
			{
				$z = wp_delete_post($lID, false);
				if (!empty($z))
					$p[] = $z->ID;
				unset($z);
			}
		}
		if (!count($p))
			return -1;
		return $p;
	}
	
	function checkFile() 
	{
    	return array('fileCheck' => 1);
	}
	
	public function __destruct() 
	{ 
		if ($this->result)
			print json_encode($this->result);
	}
}
?>