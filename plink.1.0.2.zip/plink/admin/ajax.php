<?php
header('Content-Type: application/json');
//header("HTTP/1.1 200 OK");
error_reporting(0);

class ajax
{
	public function __construct()
	{
		$sys 		= new sys;
		$user 		= new user;
		$donor 		= new donor;
		$api 		= new api;
		$ground 	= new ground;
		
		$user->sys 	= $sys;
		$donor->sys = $sys;
		$donor->api = $api;
		$ground->sys = $sys;
		$ground->api = $api;
		
		if (isset($_POST['params']) && isset($_POST['action']) && $_POST['action'] == 'auth')
			$ret = $user->loginToPlink();
		else if (isset($_POST['params']) && isset($_POST['action']) && $_POST['action'] == 'saveDonorSettings')
		{
			//print_r($_POST['params']);
			$ret = $donor->saveDonorSettings($_POST['params']);	
		}
		else if (isset($_POST['params']) && isset($_POST['action']) && $_POST['action'] == 'saveGroundSettings')
			$ret = $ground->saveGroundSettings($_POST['params']);
		else if (isset($_POST['params']) && $sys->array_val($_POST['params'], "formType") == "initAddDonors")
			$ret = $donor->initAddDonors($_POST['params']);
		else if (isset($_POST['params']) && $sys->array_val($_POST['params'], "formType") == "addDonors")
			$ret = $donor->addDonors($_POST['params']);
		else if ($_POST['action'] == "offDonorList")
			$ret = $donor->offDonorList();
		else if ($_POST['action'] == "offDonors")
			$ret = $donor->offDonors();
		else if ($_POST['action'] == "onDonorList")
			$ret = $donor->onDonorList();
		else if ($_POST['action'] == "onDonors")
			$ret = $donor->onDonors();
		else if ($_POST['action'] == "deleteDonorList")
			$ret = $donor->deleteDonorList();
		else if ($_POST['action'] == "deleteDonors")
			$ret = $donor->deleteDonors();
		else if ($_POST['action'] == "getStat")
			$ret = $donor->statPopUp();
		else if ($_POST['action'] == "uploadAvatar")
		{
//			print 1;
//			exit();
			$ret = $sys->newWatermark();
		}
		else if ($_POST['action'] == "searchCatalog")
			$ret = $sys->catalog_search($_POST['params']);
		else if ($_POST['action'] == "addDonorsFromCatalog") 
			$ret = $donor->addDonorsFromCatalog();
		else if ($_POST['action'] == "confirmAddDonorsFromCatalog") 
			$ret = $donor->confirmAddDonorsFromCatalog();
		if (!empty($ret))
			print json_encode(array('action' => 1, 'content' => $ret));
	}
	
}
new ajax;


