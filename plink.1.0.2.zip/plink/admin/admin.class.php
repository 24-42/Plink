<?php
class admin {
	protected  $sys;
	
	public function __construct()
	{
		$this->sys 	= new sys;
		//$this->api	= new api;
	}

	public function enqueue_styles() {
		global $wp_styles;

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in WP_Parser_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The WP_Parser_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		if (isset($_GET['page']) && stristr($_GET['page'], 'plink')) 
		{
			add_action('wp_enqueue_scripts', 'remove_default_styles');
			wp_enqueue_style( 'material-style', plugin_dir_url( __FILE__ ) . 'css/materialize.min.css' );
			wp_enqueue_style('material-icons', "https://fonts.googleapis.com/icon?family=Material+Icons");
			wp_enqueue_style('fonts-google', "https://fonts.googleapis.com/css?family=Open+Sans|PT+Sans|Roboto+Condensed|Chelsea+Market|Chewy|Faster+One|Freckle+Face|Frijole|Luckiest+Guy");
			wp_enqueue_style( 'Plink-css', plugin_dir_url( __FILE__ ) . 'css/wp-parser-admin.css', array(), '1.0.0', 'all' );
			wp_enqueue_style( 'Plink-css-mobile', plugin_dir_url( __FILE__ ) . 'css/plugin-mobile.css', array(), '1.0.0', 'all' );
			wp_enqueue_style('fontawesome-icons', "https://use.fontawesome.com/releases/v5.4.1/css/all.css");
			
			
		}

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in WP_Parser_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The WP_Parser_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		if (isset($_GET['page']) && stristr($_GET['page'], 'plink')) 
		{
			wp_enqueue_script( 'material-script', plugin_dir_url( __FILE__ ) . '/js/materialize.min.js', array(), '1.0', false );
			wp_enqueue_script( 'Plink-Js', plugin_dir_url( __FILE__ ) . 'js/plink.js', array( 'jquery' ), '1.0.0', false );
			wp_localize_script( 'Plink-Js', 'loginToPlink', array('ajaxurl' => plugins_url('plink/plink.php')));
		}

	}
	
	public function enqueue_fancybox()
	{
		if (!is_admin()) { 
			wp_deregister_script('jquery');
			wp_register_script('jquery', "//code.jquery.com/jquery-3.4.1.min.js");
			wp_enqueue_script( 'jquery' );
		}
		wp_register_script('fancybox', "https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.js");
	 	wp_register_style('fancybox_css', 'https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.css');
	 	wp_enqueue_script('fancybox');
		wp_enqueue_style( 'fancybox_css' );
	}
	
	public function init_menu() 
	{
		global $PLINK_CONFIG, $PLUGIN_CONFIG, $PLINK_ICON;
		
		$page_title 			= "Plink";
		$menu_title 			= "Plink";
		$capability				= "manage_options";
		$menu_slug  			= "plink_index";
		$position 				= null;

		if ($PLINK_CONFIG['hash'])
		{
			if (get_option('plink_update') == 1)
				add_menu_page( $page_title, $menu_title, $capability, $menu_slug, array($this,'get_update_page'), $PLUGIN_CONFIG['logo_for_wp'], $position );
			else
			{
				add_menu_page( $page_title, $menu_title, $capability, $menu_slug, array($this,'get_dashboard_page'), $PLUGIN_CONFIG['logo_for_wp'] ,$position );	
				add_submenu_page($menu_slug, 'Статистика', 'Статистика', $capability,  $menu_slug , array($this,'get_dashboard_page'));
				add_submenu_page($menu_slug, 'Мои доноры', 'Мои доноры', $capability,  'plink_donors' , array($this,'get_donors_page'));
				add_submenu_page($menu_slug, 'Каталог доноров', 'Каталог доноров', $capability,  'plink_catalog_donors' , array($this,'get_catalog_donors_page'));
				add_submenu_page($menu_slug, 'Настройки площадки', 'Настройки площадки', $capability,  'plink_settings' , array($this,'get_settings_page'));
			}
		}
		else
			add_menu_page( $page_title, $menu_title, $capability, $menu_slug, array($this,'get_login_page'), $PLUGIN_CONFIG['logo_for_wp'], $position );
	}
	
	function get_update_page()
	{
		$url = get_site_url();
		require_once(plugin_dir_path( __FILE__ ) .'partials/update.php');
	}
	
	function get_login_page()
	{
		global $PLINK_CONFIG;
		
		$hash_file 			= $PLINK_CONFIG['hash_file'];
		
		require_once(plugin_dir_path( __FILE__ ) .'partials/login.php');
	}
	
	function get_dashboard_page()
	{
		global $PLUGIN_CONFIG, $PLINK_CONFIG;
		
		$q								= array(array('action' => 'getGround', 'groundId' => $PLINK_CONFIG['groundId'], 'type' => 1));
		$q[]							= array('action' => 'getStat', 'type' => 1, 'groundId' => $PLINK_CONFIG['groundId'], 'donorId' => '0', 'days' => 7);
		$q[] 							= array('action' => 'getCurrentBalance', 'user_id' => $PLINK_CONFIG['userId']);
		$json 							= json_decode($this->sys->api($PLUGIN_CONFIG['core'], $q), true);
		$ground 						= $json['getGround'][0];
		$donor 							= $json['getDonor'][0];
		$stat 							= $json['getStat'][0];
		$user_balance 					= $json['getCurrentBalance'][0]['money'];
		$domain							= $ground['domain'];
		$url							= '//'.$ground['domain'];
		$params							= json_decode($ground['paramsList'], true);
		//print_r($params);
		$fav					= $this->sys->getFavIcon($params['clientInfo']['favicon']);
		require_once(plugin_dir_path( __FILE__ ) .'partials/home.php');
	}
	
	
	function checkPluginVersion()
	{
		if (PLINK_VERSION !== get_option('plink_version'))
		{
			sys::activateAfterUpdate();
		}
	}
	
	function get_settings_page()
	{
		global $PLINK_CONFIG, $PLUGIN_CONFIG;

		$wpCategory 		= api::getWPCategory();
		$wpUsers 			= api::getWPUsers();
		$a          		= array(array('action' => 'getGround', 'groundId' => $PLINK_CONFIG['groundId'], 'type' => 1));
		$a[] 				= array('action' => 'getCurrentBalance', 'user_id' => $PLINK_CONFIG['userId']);
		$json       		= json_decode($this->sys->api($PLUGIN_CONFIG['core'], $a), true);
		$ground   			= $json['getGround'][0];
		$user_balance 		= $json['getCurrentBalance'][0]['money'];
		
		require_once(plugin_dir_path( __FILE__ ) .'partials/settings.php');
	}
	
	function get_donors_page()
	{
		global $PLINK_CONFIG, $PLUGIN_CONFIG;
		
		$wpCategory 		= api::getWPCategory();
		$wpUsers 			= api::getWPUsers();
		$a          		= array(array('action' => 'getDonorList', 'groundId' => $PLINK_CONFIG['groundId'], 'type' => 1));
		$a[] 				= array('action' => 'getCurrentBalance', 'user_id' => $PLINK_CONFIG['userId']);
		$a[] 				= array('action' => 'getGround', 'groundId' => $PLINK_CONFIG['groundId'], 'type' => 1); 
		$json       		= json_decode($this->sys->api($PLUGIN_CONFIG['core'], $a), true);
		$ground 			= $json['getGround'][0];
				//print_r($json);
		$donors     		= $json['getDonorList'][0];
		$user_balance 		= $json['getCurrentBalance'][0]['money'];
		$site_url 			= get_site_url();
		
		
		if ($ground['paramsList'])
			$paramsList 	= json_decode($ground['paramsList'], true);
		$fav 				= $this->sys->getFavIcon($paramsList['clientInfo']['favicon'], 2);
		$s_domain 			= $ground['domain'];
		
		require_once(plugin_dir_path( __FILE__ ) .'partials/donors_new.php');
	}
	
	function get_catalog_donors_page()
	{
		global $PLINK_CONFIG, $PLUGIN_CONFIG;
		
		$searchData				= array(
				'iks_start'	 			=> 0,
				'iks_end' 				=> '*',
				'y_index_start' 		=> 0,
				'y_index_end' 			=> '*',
				'g_index_start' 		=> 0,
				'g_index_end' 			=> '*',
				'traffic_start' 		=> 0,
				'traffic_end' 			=> '*',
				'category_list'			=> array()
		);
		$fields					= array(
			array('action' => 'getCatalog',		   	'start' => 0, 'limit' => $PLUGIN_CONFIG['catalog_page_lim'], 'searchParams' => $searchParams),
			array('action' => 'getCatalogCategory')
		);
		$json					= json_decode($this->sys->api($PLUGIN_CONFIG['core'], $fields), true);
		require_once(plugin_dir_path( __FILE__ ) .'partials/donorCatalog.php');
		array_push(
                $arr,
                array("add" => 3, "selector" => ".contentLoad", "html" => $html),
				array("add" => 0, "selector" => ".donorCatalogCountMenu",	"html",  "class" => "1", "className" => "aCt")
            );
		return $arr;
		
	}
} 
?>