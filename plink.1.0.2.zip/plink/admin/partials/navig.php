<div class="nav_wrap">
	<ul>
    	<li><a <?php if ($homeNavig) { ?>class="active"<? } ?> href="/wp-admin/admin.php?page=plink_index">Статистика</a></li>
        <li><a <?php if ($donorsNavig) { ?>class="active"<? } ?> href="/wp-admin/admin.php?page=plink_donors">Мои доноры</a></li>
        <li><a <?php if ($catalogNavig) { ?>class="active"<? } ?> href="/wp-admin/admin.php?page=plink_catalog_donors">Каталог доноров</a></li>
        <li><a <?php if ($setNavig) { ?>class="active"<? } ?> href="/wp-admin/admin.php?page=plink_settings">Настройки площадки</a></li>
        <li><a class="moneyNavBts" href="https://plink.top/panel?x=faq" target="_blank"><i class="fas fa-external-link-square-alt"></i>FAQ</a></li>
        <li><a class="moneyNavBts" href="https://plink.top/panel?x=money" target="_blank"><i class="fas fa-external-link-square-alt"></i>Баланс</a></li>
        <li><a class="feedNavBts" href="https://plink.top/panel?x=feedback" target="_blank"><i class="fas fa-external-link-square-alt"></i>Техподдержка</a></li>
        <li><a class="refNavBts" href="https://plink.top/panel?x=referrals" target="_blank"><i class="fas fa-external-link-square-alt"></i>Реферальная программа</a></li>
    </ul>
</div>