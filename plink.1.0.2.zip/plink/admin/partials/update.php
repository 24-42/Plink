<?php require_once('alerts.php');?>
<div class="loader_form">
  <div class="lds-roller"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>
</div>

<div class="mainrow">
	<div class="row authForm center">
		<div class="updateIcon"></div>
		<div class="activation update">ДОСТУПНО НОВОЕ ОБНОВЛЕНИЕ</div>
		<div class="act-desc up-button">
			<p>Для завершения обновления вам необходимо перейти на страницу "Плагины"</p>
			<p>Найти в списке плагинов - Plink, и нажать кнопку "обновить сейчас"</p>
			<p>Пару секунд и парсер снова готов к работе</p>
		</div>
		<div class="form-act up-button">
			<div class="updateButton">
				<a target="_blank" href ="<?php print $url.'/wp-admin/plugins.php' ?>" class="waves-effect waves-light btn z-depth-0 reg-button ajaxFalse">Перейти к плагинам</a>
			</div>
		</div>
		
	</div>
</div>
<div class="footrow row nomar">
	<ul>
		<li><a target="_blank" href="https://plink.top/">Регистрация</a></li>
		<li><a target="_blank" href="https://plink.top/">Забыли пароль</a></li>
	</ul>
</div>
</form>
