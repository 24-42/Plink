<?php require_once('alerts.php');?>
<form id="auth" onkeydown="if (event.keyCode == 13) {checkForm('auth'); return false}">
	<div class="loader_form">
        		<div class="lds-roller"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>
			</div>
<input type="hidden" name="action" value="loginToPlink">
<input type="hidden" name="hash_file" value = "<?php print $hash_file; ?>">
<div class="mainrow">
	<div class="row authForm center">
		<div class="step">Шаг 2 из 3</div>
		<div class="loginIcon"></div>
		<div class="activation">АКТИВАЦИЯ ПЛАГИНА</div>
		<div class="act-desc">
			<p>Вы находитесь на этапе активации плагина WordPress</p>
			<p>Для завершения этапа введите свои данные для входа в Plink и нажмите кнопку Активировать</p>
		</div>
		<div class="form-act fl">
			<div class="inputField my-input-field fl">
               <span class="inputPrevIcon"><i class="fas fa-at"></i></span>
               <input class="t1 validIT" type="text" name="email" placeholder="Email" data-valid="true">
            </div>
			<div class="inputField my-input-field auBtBl fl">
               <span class="inputPrevIcon"><i class="fas fa-lock"></i></span>
               <input class="t1 validIT" type="password" name="password" placeholder="Пароль">
            </div>
			<div class="inputField fl">
				<a class="waves-effect waves-light btn z-depth-0 reg-button ajaxFalse indexAuthBtn" onclick="checkForm('auth'); return false">Активировать</a>
			</div>
		</div>
	</div>
</div>
<div class="footrow row nomar">
	<ul>
		<li><a target="_blank" href="https://plink.top/">Регистрация</a></li>
		<li><a target="_blank" href="https://plink.top/">Забыли пароль</a></li>
	</ul>
</div>
</form>
