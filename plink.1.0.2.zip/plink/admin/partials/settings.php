<?php require_once('alerts.php'); $setNavig = true; require_once('navig.php');?>
<?php 
if ($ground['paramsList'])
	$paramsList 	= json_decode($ground['paramsList'], true);

$hoursTable 		= $this->sys->generateHoursTable($paramsList['workHoursList']);
$daysTable			= $this->sys->generateDaysTable($paramsList['dayPostsLimit']);
$categoryLimits = '
	<div class="oneCategory top row">
		<div class="col s6">Категория</div>
		<div class="col s6">Публикаций в день</div>
	</div>
';
if (count($wpCategory))
{
	foreach ($wpCategory as $c)
	{
		if (is_numeric($c->cat_ID))
		{
			if (count($wpUsers))
			{
				$userList = '<div class="input-field nomar"><select name="userCat_catID'.$c->cat_ID.'">';
				foreach ($wpUsers as $u)
				{
					$userList .= '<option value="'.$u->data->ID.'"'; if ($paramsList['categoryLimits'][$c->cat_ID]['author'] == $u->data->ID) {$userList .= ' selected="selected"'; } $userList .= '>'.$u->data->user_login.'</option>';
				}
				$userList .= '</select></div>';
			}
			
				$categoryLimits .= '
				<div class="oneCategory bot row nomar">
					<div class="col s6"><a class="targetUrl categoryLink" href="//'.$ground['domain'].'/?cat='.$c->cat_ID.'" target="_blank">'.$c->cat_name.'</a></div>
					<div class="col s6 listNoPad"><input name="dayCatLimit_catID'.$c->cat_ID.'" value="'.(!empty($paramsList['categoryLimits'][$c->cat_ID]['limit']) ? $paramsList['categoryLimits'][$c->cat_ID]['limit'] : '*').'"></div>
				</div>
			';
		}
	}
	
} else 
	$categoryLimits .= '<div class="errorList">Список категорий сайта пуст</div>';
$categoryLimits = '<div class="donorList">'.$categoryLimits.'</div>';

$status = $this->sys->getGroundStatus($ground['act']);
if ($status['act'] == 1) {$avtiveList = ' work'; $statVal = 1; $cheked = 'checked="checked"';}
if ($status['act'] == 2) {$avtiveList = ''; $statVal = 2;}
if ($status['act'] == 4) {$avtiveList = ''; $avtiveListYes = ' disable';}

$html = '<div id="popUpGroundSettings"><div class="wrap settingsTab sds">
<div class="loader_form">
					</div>
<div class="popUpAjaxContent">
			<form id="saveGroundSettings">
			<input type="hidden" name="formType" value="saveGroundSettings">
			<input type="hidden" name="groundId" value="'.$ground['ground_id'].'">
			<input type="hidden" name="myAvatarInput" value="'.(!empty($paramsList['postSettings']['myAvatarInput']) ? $paramsList['postSettings']['myAvatarInput']: '' ).'">
			<input class="displayNone avatarUpload" type="file" onchange="jQuery(this).addClass(\'sendAvatar\');jQuery(\'.avatarUpload\').click();" data-ajax="2" data-type="act" data-action="uploadAvatar" data-file="1" data-fileclass="avatarUpload">
			
            <div class="clientInfo row nopad nomar clearfix">
                <div class="col s8 clientUrl nopad">
                    <div class="btnTops cltUrl"><a href="//'.$ground['domain'].'/" target="_blank" class="t1 waves-effect waves-light ajaxFalse"><span class="favIcon" style="background:url(\''.$this->sys->getFavIcon($paramsList['clientInfo']['favicon'], 2).'\') no-repeat; background-size:100%;"></span>'.$ground['domain'].'</a></div>
					<div class="btnTops balansUrl"><span class="moneyLcl t1"><span class="moneSpCl t1">БАЛАНС:</span> '.$user_balance.' руб.</span></div>
                    <div class="btnTops cltStatus">
						
						<div class="curWorkStatus ar onStatus active '.$avtiveList.'">
							<!-- Switch -->
							<div class="switch statusGroundBt">
								<label class="t1">
								  <input type="checkbox" name="status" '.$cheked.'>
								  <span class="lever"></span>
								  <span class="work_text">В Работе</span>
								  <span class="stop_text">Остановлена</span>
								</label>
							</div>
						</div>
					</div>
                </div>
            </div>
            <div class="popUpGroundMenu">
            	  <div class="row">
                    <div class="col s12 nopad">
                      <ul class="tabs grPl">
					  	<li class="tab col s3"><a href="#tab1" class="ajaxFalse active">Настройки</a></li>
                        <li class="tab col s3"><a href="#tab2" class="ajaxFalse">Лимиты</a></li>
                        <li class="tab col s3"><a href="#tab3" class="ajaxFalse">Изображения</a></li>
                        <li class="tab col s3"><a href="#tab4" class="ajaxFalse">Социальные сети</a></li>
                      </ul>
                    </div>
                  </div>
             </div>
             	
                	<div class="tabsList">
					<div id="tab1" class="col s12">
								<div class="row generalStBl">
									<div class="my-input-field col s12">
										<div class="minRowTi nopad">Название сайта</div>
										<input type="text" name="site_name" value="'.$paramsList['groundSettings']['siteName'].'" placeholder="Укажите название сайта" />
									</div>
									
								</div>
								<div class="row generalStBl">
									<div class="my-input-field col s12">
										<div class="minRowTi nopad">Заменить название сайта в блоках</div>
										<div class="myCheckBox '.($paramsList['groundSettings']['replaceTitle'] ? 'checked' : '').'">
											<input type="hidden" value="'.$paramsList['groundSettings']['replaceTitle'].'" name="replaceTitle">
											<span class="myCheck">
												<span class="myCheckSqrd"><i class="fas fa-check"></i></span>
												<span class="myCheckText">Заголовок</span>
											</span>
										</div>
										<div class="myCheckBox '.($paramsList['groundSettings']['replaceMetad'] ? 'checked' : '').'">
											<input type="hidden" value="'.$paramsList['groundSettings']['replaceMetad'].'" name="replaceMetad">
											<span class="myCheck">
												<span class="myCheckSqrd"><i class="fas fa-check"></i></span>
												<span class="myCheckText">Короткое описание</span>
											</span>
										</div>
										<div class="myCheckBox '.($paramsList['groundSettings']['replaceMetak'] ? 'checked' : '').'">
											<input type="hidden" value="'.$paramsList['groundSettings']['replaceMetak'].'" name="replaceMetak">
											<span class="myCheck">
												<span class="myCheckSqrd"><i class="fas fa-check"></i></span>
												<span class="myCheckText">Ключевые слова</span>
											</span>
										</div>
										<div class="myCheckBox '.($paramsList['groundSettings']['replaceTags'] ? 'checked' : '').'">
											<input type="hidden" value="'.$paramsList['groundSettings']['replaceTags'].'" name="replaceTags">
											<span class="myCheck">
												<span class="myCheckSqrd"><i class="fas fa-check"></i></span>
												<span class="myCheckText">Теги</span>
											</span>
										</div>
										<div class="myCheckBox '.($paramsList['groundSettings']['replaceText'] ? 'checked' : '').'">
											<input type="hidden" value="'.$paramsList['groundSettings']['replaceText'].'" name="replaceText">
											<span class="myCheck">
												<span class="myCheckSqrd"><i class="fas fa-check"></i></span>
												<span class="myCheckText">Текст</span>
											</span>
										</div>
									</div>
								</div>
								<div class="row generalStBl nomar">
									<div class="my-input-field col s12">
										<div class="minRowTi nopad">Система хранения данных</div>
										<select name="dbEngine" class="mySelect">
											<option value="myisam" '.($paramsList['groundSettings']['dbEngine'] == 'myisam' ? 'selected' : '').'>MyISAM</option>
											<option value="innodb" '.($paramsList['groundSettings']['dbEngine'] == 'innodb' ? 'selected' : '').'>InnoDB</option>
										</select>
										<div class="alert-box row">
											<p><strong>Внимание</strong> Процесс обновления может занять довольно длительное время.</p>
											<p>Перед использованием рекомендуем проконсультироваться в службе поддержки Plink</p>
										</div>
									</div>
								</div>
						</div>
                    	<div id="tab2" class="col s12">
							<div class="generalLimitBlock row">
								<div class="col s6">
									<div class="generalInputs"><div class="generalSetHoursBtn topTabTrigger1 topTab1 t1 active" onclick="changeTab(1, 1);"><i class="fas fa-clock m15"></i>Почасовые лимиты публикаций</div></div>
								</div>
								<div class="col s6">
									<div class="generalInputs"><div class="generalSetHoursBtn topTabTrigger1 topTab2 t1" onclick="changeTab(2, 1);"><i class="fas fa-calendar-alt m15"></i>Лимиты по дням недели</div></div>
								</div>
							</div>
							<div class="hoursContainer tabTopClass myTabTrigger1 myTab1 active">'.$hoursTable.'</div>
							<div class="daysContainer tabTopClass myTabTrigger1 myTab2">'.$daysTable.'</div>
            				<div class="categoryListBlock row nopad">'.$categoryLimits.'</div>
                        </div>
                    	<div id="tab3" class="col s12">
							
							<div class="imgGenSet row">
											<div class="row col s6 nomar nopad">
												 <div class="minRowTi">Мутные края у изображений</div>
												<div class="my-input-field col s12">
												  <select name="imgBlur" class="mySelect">
													  <option value="1"'; if ($paramsList['postSettings']['imgBlur']) {$html .= ' selected="selected"'; } $html .= '>Да</option>
													  <option value="0"'; if (!$paramsList['postSettings']['imgBlur']) {$html .= ' selected="selected"'; } $html .= '>Нет</option>
												  </select>
												</div>
											</div>
											<div class="row col s6 nomar nopad">
												<div class="minRowTi">Зеркальные изображения в посте</div>
												<div class="my-input-field col s12">
												  <select name="imgMirror" class="mySelect">
													  <option value="1"'; if ($paramsList['postSettings']['imgMirror']) {$html .= ' selected="selected"'; } $html .= '>Да</option>
													  <option value="0"'; if (!$paramsList['postSettings']['imgMirror']) {$html .= ' selected="selected"'; } $html .= '>Нет</option>
												  </select>

												</div>
											</div>	
							</div>
						
							<div class="generalLimitBlock row">
								<div class="col s6">
									<div class="generalInputs"><div class="generalSetHoursBtn topTabTrigger2 topTab3 t1 active" onclick="changeTab(3, 2);"><i class="fas fa-tint m15"></i>Водяной знак</div></div>
								</div>
								<div class="col s6">
									<div class="generalInputs"><div class="generalSetHoursBtn topTabTrigger2 topTab4 t1" onclick="changeTab(4, 2);"><i class="fas fa-share-alt m15"></i>Заглушка для соц.сетей</div></div>
								</div>
							</div>
							<div class="waterContainer tabTopClass myTabTrigger2 myTab3 active">
								<div class="row nomar">
								<div class="row col s4 nomar nopad">
									<div class="minRowTi">Расположение водяного знака</div>
									<div class="my-input-field col s12 bigSel">
                                    	<select name="watermarkPosition" class="bigSel mySelect" >
                                         	<option'; if ($paramsList['postSettings']['watermarkPosition'] == '1') {$html .= ' selected="selected"'; } $html .= ' value="1">Слева сверху</option>
											
                                        	<option'; if ($paramsList['postSettings']['watermarkPosition'] == '2') {$html .= ' selected="selected"'; } $html .= ' value="2">Слева по центру</option>
											
                                        	<option'; if ($paramsList['postSettings']['watermarkPosition'] == '3') {$html .= ' selected="selected"'; } $html .= ' value="3">Слева снизу</option>
											
                                        	<option'; if ($paramsList['postSettings']['watermarkPosition'] == '4') {$html .= ' selected="selected"'; } $html .= ' value="4">По центру сверху</option>
											
                                        	<option'; if ($paramsList['postSettings']['watermarkPosition'] == '5') {$html .= ' selected="selected"'; } $html .= ' value="5">По центру</option>
											
                                        	<option'; if ($paramsList['postSettings']['watermarkPosition'] == '6') {$html .= ' selected="selected"'; } $html .= ' value="6">По центру снизу</option>
											
                                       		<option'; if ($paramsList['postSettings']['watermarkPosition'] == '7') {$html .= ' selected="selected"'; } $html .= ' value="7">Справа сверху</option>
											
                                        	<option'; if ($paramsList['postSettings']['watermarkPosition'] == '8') {$html .= ' selected="selected"'; } $html .= ' value="8">Справа по центру</option>
											
                                       		<option'; if ($paramsList['postSettings']['watermarkPosition'] == '9') {$html .= ' selected="selected"'; } $html .= ' value="9">Справа снизу</option>
                                        	<option'; if ($paramsList['postSettings']['watermarkPosition'] == '10' || !$paramsList['postSettings']['watermarkPosition']) {$html .= ' selected="selected"'; } $html .= ' value="10">Случайное расположение</option>
                                         </select>
                                     </div>
									 </div>
									 <div class="row col s4 nomar nopad">
										 <div class="minRowTi">Уровень прозрачности водяного знака</div>
										 <div class="my-input-field col s12">
											  <input type="number" id="zc5" name="watermarkOpacity" max="100" min="0" value="'.(($paramsList['postSettings']['watermarkOpacity']) ? $paramsList['postSettings']['watermarkOpacity'] : '100').'" />
										 </div>
									 </div>
									 <div class="row col s4 nomar nopad">
									 	
										 <div class="minRowTi">Водянной знак</div>
										 '.(!empty($paramsList['postSettings']['myAvatarInput']) ? '
										 <div class="my-input-field s12 water row">
										
										 	<div class="col s6">
												<span class="uploadWatermark" onclick="jQuery(\'#showWatermark\').modal(\'open\');">
												<i class="fas fa-check m15"></i>Смотреть</span>
											</div>
											<div class="col s6">
												<span class="uploadWatermark" onclick="removeWatermark();"><i class="fas fa-times m15"></i>Удалить</span>
											</div>
										</div>' : 
											'<div class="my-input-field col s12 water">
											  <div class="uploadWatermark" onclick="jQuery(\'.avatarUpload\').click();">
												<i class="fas fa-upload m15"></i>
												Выбрать
											  </div>
										 </div>').'
										 
										 <div id="showWatermark" class="modal"><div class="modal-content watermarkPopUp"><img src="'.(!empty($paramsList['postSettings']['myAvatarInput']) ? $PLINK_CONFIG['path_watermark'].'/'.$paramsList['postSettings']['myAvatarInput'] : '').'"></div></div>
									</div>
									
								</div>';
									//print_r($paramsList);
								if ($paramsList['postSettings']['watermarkUrl'])
								{
									$html .= '
									<div class="row">
										<div class="col s12">
											<div class="curWater">Текущий водяной знак</div>
											<div class="curWaterImg"><img src="//'.$ground['domain'].$paramsList['postSettings']['watermarkUrl'].'"></div>
										</div>
									</div>';
								}
							$html .= '
							</div>
							<div class="socZagConteiner tabTopClass myTabTrigger2 myTab4">
								<div class="row">
									<div class="col row s4 nomar nopad">
										<div class="minRowTi">Имя сайта на заглушке</div>
										<div class="my-input-field col s12">
											<input type="text" id="zcx2" name="zagSiteName" value="'.($paramsList['postSettings']['zagSiteName'] ? $paramsList['postSettings']['zagSiteName'] : $ground['domain']).'" />
										</div>
									</div>
									<div class="col row s4 nomar nopad">
										<div class="minRowTi">Выберите шрифт заголовка</div>
										<div class="my-input-field col s12">
											  <select name="zagFontFamily" class="mySelect">
												  <option  value="1"'; if ($paramsList['postSettings']['zagFontFamily'] == '1') {$html .= ' selected="selected"'; } $html .= '>Montserrat</option>
												  <option  value="2"'; if ($paramsList['postSettings']['zagFontFamily'] == '2') {$html .= ' selected="selected"'; } $html .= '>Open Sans</option>
												  <option  value="3"'; if ($paramsList['postSettings']['zagFontFamily'] == '3') {$html .= ' selected="selected"'; } $html .= '>Open Sans Condensed</option>
												  <option  value="4"'; if ($paramsList['postSettings']['zagFontFamily'] == '4') {$html .= ' selected="selected"'; } $html .= '>Roboto</option>
												  <option  value="5"'; if ($paramsList['postSettings']['zagFontFamily'] == '5') {$html .= ' selected="selected"'; } $html .= '>Roboto Condensed</option>
											  </select>
                                     	</div>
									 </div>
									 <div class="col row s4 nomar nopad">
										 <div class="minRowTi">Размер шрифта</div>
										 <div class="my-input-field col s12">
											  <input type="text" id="zcx1" name="zagFontSize" value="'.($paramsList['postSettings']['zagFontSize'] ? $paramsList['postSettings']['zagFontSize'] : 24).'" />

										 </div>
									 </div>
								</div>
								<div class="row">
									<div class="col row s6 nomar nopad">
										<div class="minRowTi">Отображать название сайта на заглушке</div>
										<div class="my-input-field col s12">
											<select name="zagSiteNameStatus" class="mySelect">
												  <option value="1"'; if ($paramsList['postSettings']['zagSiteNameStatus']) {$html .= ' selected="selected"'; } $html .= '>Да</option>
												  <option value="0"'; if (!$paramsList['postSettings']['zagSiteNameStatus']) {$html .= ' selected="selected"'; } $html .= '>Нет</option>
											  </select>
										</div>
									</div>
									<div class="col row s6 nomar nopad">
										<div class="minRowTi">Отображать категорию поста на заглушке</div>
										<div class="my-input-field col s12">
											<select name="zagCategoryStatus" class="mySelect">
												  <option value="1"'; if ($paramsList['postSettings']['zagCategoryStatus']) {$html .= ' selected="selected"'; } $html .= '>Да</option>
												  <option value="0"';if (!$paramsList['postSettings']['zagCategoryStatus']) {$html .= ' selected="selected"'; } $html .= '>Нет</option>
											  </select>
										</div>
									</div>
								</div>
							</div>
							<div class="alert-box row">
								<p><strong>Внимание</strong> Plink использует библиотеку <a target="_blank" href ="https://fancyapps.com/fancybox/3/">fancybox</a> для галереи изображений. Если вы используете другую библиотеку отключите ее.</p>
							</div>
						</div>
						
						
						
						
						
                    	<div id="tab4" class="col s12">
							<div class="socContainer ">
								<div class="socTtl">Вконтакте</div>
							<div class="switch switchSet minRowTi">
										<label>
										  Выкл
										  <input type="checkbox" name="isActiveVk" '.(($paramsList['vkAutoPosting']['isActiveVk'] == 'on') ? 'checked="checked"' : '').'>
										  <span class="lever"></span>
										  Вкл
										</label>
									  </div>
								<div class="oneSoc vkSoc '.(($paramsList['vkAutoPosting']['isActiveVk'] == 'on') ? '' : 'displayNone').' ">
									
									<div class="authData row ">
										<div class="row col s6 nopad">
											<div id="showInstructionApp" class="modal">
												<div class="modal-content">
												  <h4>Создание приложения ВК</h4>
												  <p>1. Перейдите по ссылке <a target="_blank" href="https://vk.com/editapp?act=create">Создать приложение</a>.</p>
												  <p>2. Введите название вашего приложения. Например : "'.$ground['domain'].'-автопостинг".</p>
												  <p>3. Укажите платформу - "Standalone-приложение".</p>
												  <p>4. Перейдите на вкладку "Настройки".</p>
												  <p><img src="/wp-content/plugins/plink/resources/instruction/instruction-1.jpg"></p>
												  <p>5. Скопируйте ID приложения и включите OPEN API.</p>
												  <p><img src="/wp-content/plugins/plink/resources/instruction/instruction-2.jpg"></p>
												  <p>6. В поле "Адрес сайта" введите "http://'.$ground['domain'].'" Без кавычек.</p>
												  <p>7. В поле "Базовый домен" введите "'.$ground['domain'].'" Без кавычек.</p>
												  <p><img src="/wp-content/plugins/plink/resources/instruction/instruction-3.jpg"></p>
												  <p>8. Вставьте ID приложения в поле и переходите к следующему шагу - получите секретный ключ для добавления постов на стену сообщества VK.</p>
												</div>
											  </div>
											  <div id="showInstructionKey" class="modal">
												<div class="modal-content">
												  <h4>Как получить секретный ключ(Токен)</h4>
												  '.(!empty($paramsList['vkAutoPosting']['vkAppId']) ? '<p>1. Перейдите по ссылке <a href="https://oauth.vk.com/authorize?client_id='.$paramsList['vkAutoPosting']['vkAppId'].'&scope=wall,photos,offline&redirect_uri=https://oauth.vk.com/blank.html&display=page&response_type=token" target="_blank">Получить ключ</a></p>
												  <p>2. Нажмите кнопку "Разрешить".</p>
												  <p><img src="/wp-content/plugins/plink/resources/instruction/instruction-4.jpg"></p>
												  <p>3. Скопируйте acces_token из адресной строки и вставьте в поле настроек.</p>
												  <p><img src="/wp-content/plugins/plink/resources/instruction/instruction-5.jpg"></p>
												  <p>Осталось ввести ID группы VK и ID создателя группы нажать сохранить и автопостинг настроен.</p>
												  ' : 
											'<p>Сперва сохраните ID приложения.</p>').'
												  
												</div>
											  </div>
											<div class="minRowTi">ID Приложения<div onclick="jQuery(\'#showInstructionApp\').modal(\'open\');" class="tooltip"><i class="fas fa-question-circle tooltipped" data-position="right" data-tooltip="Нажми на меня"></i></div></div>
											<div class="my-input-field col s12">
											  <input type="text" name="vkAppId" value="'.$paramsList['vkAutoPosting']['vkAppId'].'" />
								     		</div>
										</div>
										<div class="row col s6 nopad ">
											<div class="minRowTi">Секретный ключ<div onclick="jQuery(\'#showInstructionKey\').modal(\'open\');" class="tooltip"><i class="fas fa-question-circle tooltipped" data-position="right" data-tooltip="Нажми на меня"></i></div></div>
											<div class="my-input-field col s12">
											  <input type="text" name="vkGroupSecret" value="'.$paramsList['vkAutoPosting']['vkGroupSecret'].'" />
											</div>
										</div>
										<div class="row col s6  nopad nomar">
											<div class="minRowTi">ID Группы VK<div class="tooltip"> <i class="fas fa-question-circle tooltipped" data-position="right" data-tooltip="Впишите сюда ID группы со знаком -<br>Например: -54354332"></i></div></div>
											<div class="my-input-field col s12">
											  <input type="text" name="vkGroupId" value="'.$paramsList['vkAutoPosting']['vkGroupId'].'" />
								     		</div>
										</div>
										<div class="row col s6 nopad nomar">
											<div class="minRowTi">ID Страницы<div class="tooltip"> <i class="fas fa-question-circle tooltipped" data-position="right" data-tooltip="Впишите сюда ID создателя группы"></i></div></div>
											<div class="my-input-field col s12">
											  <input type="text" name="vkUserId" value="'.$paramsList['vkAutoPosting']['vkUserId'].'" />
								     		</div>
										</div>
										
									</div>
									
									<div class="socData row">
										<div class="row col s12 nopad nomar">
											<div class="minRowTi">Публикации с 01:00 до 06:00</div>
											<div class="my-input-field col s12">
											  <select name="vkNightMode" class="mySelect">
												  <option value="0"'; if (!$paramsList['vkAutoPosting']['vkNightMode']) {$html .= ' selected="selected"'; } $html .= '>Публиковать</option>
												  <option value="1"'; if ($paramsList['vkAutoPosting']['vkNightMode']) 	{$html .= ' selected="selected"'; } $html .= '>Не публиковать</option>
											  </select>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						</div>
                	</div>
            	
            <div class="btnBottom">
            	<span class="addClientBtn saveSettingBtn waves-effect waves-light btn z-depth-0" onclick="check_form(\'saveGroundSettings\'); return false"><i class="fas fa-check-circle"></i>Сохранить
				</span>
				<img class="btnloader displayNone" src ="https://plink.top/image/plugin/loader.gif">
            </div>
			</form>
        </div></div></div>'; 
print $html;
?>
