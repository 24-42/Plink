<?php defined('_JEXEC') or die('403'); 
print '<div class="flyAlerts"></div>';