<?php defined('_JEXEC') or die('403'); ?>
<?php require_once('alerts.php'); $catalogNavig = true; require_once('navig.php');?>
<div id ="donorsTab" class="clientBlock c<?php print $PLINK_CONFIG['groundId']?>"> 
<div class="wrap">
	<div>
		<div id="popUpStat">
<?php
$cat_btns = '<div class="buttons_cat_s row">
		<div class="col s6 cancelSearchCatClock">
			<a href="" class="btn waves-effect waves-light z-depth-0 addClientBtn ajaxFalse cancelSearchCat" onclick="clear_catalog_search(\'s_cat_l\'); return false">Очистить</a>
		</div>
		<div class="col s6 acceptSearchCatBlock">
			<a href="" class="btn waves-effect waves-light z-depth-0 addClientBtn ajaxFalse acceptSearchCat" onclick="search_catalog_init(0); return false">Применить</a>
		</div>
	</div>';
$category = '
<div class="categoryList only-click-select search_block s_cat_l">
	'.$cat_btns.'
	<ul class="parent-list row"><div class="block col s4">
		';
$c_count = count($json['getCatalogCategory'][0]);
$step = round($c_count / 3);
$prt = 1;
$blocks = 0;
foreach($json['getCatalogCategory'][0] as $cat)
{
	if ($prt >= $step)
	{
		$category .= '</div><div class="block col s4">';
		$prt = 1;
		$blocks++;
	}
	$child_html = '';
	if (!$cat['parent'])
	{
		$category .= '
		<li class="parent-li bigC'.$cat['ccid'].'">
		
			<div class="one_category_list">
				<div class="checkBtn don fl">
					<span class="inputCkeckBtn t1" data-check="0" data-toggleoff="1" data-sid="'.$cat['ccid'].'" data-cid="category'.$cat['ccid'].'" data-top="1"><i class="fas fa-check"></i></span>
				</div>
				<span class="parentCat ajaxFalse" onclick="selectCategoryGroup('.$cat['ccid'].');">'.$cat['category_name'].'</span>
			</div>
		';
		$prt++;
		foreach($json['getCatalogCategory'][0] as $child)
		{
			if ($child['parent'] == $cat['ccid'])
			{
				$child_html .= '
				<li class="child-li clearfix">
					<div class="one_category_list">
						<div class="checkBtn don fl">
							<span class="inputCkeckBtn t1" data-check="0" data-toggleoff="1" data-sid="'.$child['ccid'].'" data-cid="'.$child['ccid'].'"><i class="fas fa-check"></i></span>
						</div>
						<span class="t1 ctgN">'.$child['category_name'].'</span>
					</div>
				';
				$prt++;
			}
		}
		if ($child_html)
				$child_html	= '<ul class="child-list category'.$cat['ccid'].' clientBlock">'.$child_html.'</ul>';
			$category .= $child_html;
		$category .= '</li>';
	}
}
if ($blocks == 2)
	$category .= '</div>';
$category .= '</ul>
</div>';

$html = '
<form id="searchCatalog" onkeydown="if (event.keyCode == 13) {search_catalog_init(0); return false;}">
 <input type="hidden" name="formType" value="searchCatalog">
<input type="hidden" name="searchCategoryListId" value="">
<input type="hidden" name="num_page" value="1">
<input type="hidden" name="reload" value="0">
<div class="catalog">
<div class="loader_form">
	<div class="lds-roller"></div>
</div>
<div class="clientInfo row nopad nomar clearfix">
		<div class="col s3 catBtnMob nopad">
			<a class="addDnHb catBtnT catBtnTCat t1 waves-effect waves-light ajaxFalse quickSearch"  data-type="s_cat_l" ><span class="mobIco"><i class="fas fa-bars m15"></i></span>Категории
			<span class="searchCounter"><span class="search_min"></span></span>
			</a>
		</div>
		<div class="col s2 nopad">
			<a class="addDnHb catBtnT t1 waves-effect waves-light ajaxFalse quickSearch"  data-type="iks"><span class="mobIco"><i class="fab fa-yandex m15"></i></span>ИКС
			<span class="searchCounter"><span class="search_min"></span><span class="search_def">-</span><span class="search_max"></span></span>
			</a>
			<div class="search_block iks">
				<div class="input_search_list row">
					<div class="col s5 my-input-field nopad">
						<input type="number" name="iks_start" value="0" placeholder="От">
					</div>
					<div class="col s2 center-align nopad lnhb">
						-
					</div>
					<div class="col s5 my-input-field nopad">
						<input type="text" name="iks_end" value="*" placeholder="До">
					</div>
				</div>
				<div class="btnFooterSearch">
					<a href="" class="btn waves-effect waves-light z-depth-0 applyBtn cancelSearchCat addClientBtn ajaxFalse" onclick="clear_catalog_search(\'iks\'); return false">Очистить</a>
					<a href="" class="btn waves-effect waves-light z-depth-0 applyBtn addClientBtn ajaxFalse" onclick="search_catalog_init(0); return false">Применить</a>
					
				</div>
			</div>
		</div>
		<div class="col s2 nopad">
			<a class="addDnHb catBtnT t1 waves-effect waves-light ajaxFalse quickSearch" data-type="y_index"><span class="mobIco"><i class="fab fa-yandex-international m15"></i></span>индекс
			<span class="searchCounter"><span class="search_min"></span><span class="search_def">-</span><span class="search_max"></span></span>
			</a>
			
			<div class="search_block y_index">
				<div class="input_search_list row">
					<div class="col s5 my-input-field nopad">
						<input type="number" name="y_index_start" value="0" placeholder="От">
					</div>
					<div class="col s2 center-align nopad lnhb">
						-
					</div>
					<div class="col s5 my-input-field nopad">
						<input type="text" name="y_index_end" value="*" placeholder="До">
					</div>
				</div>
				<div class="btnFooterSearch">
					<a href="" class="btn waves-effect waves-light z-depth-0 applyBtn cancelSearchCat addClientBtn ajaxFalse" onclick="clear_catalog_search(\'y_index\'); return false">Очистить</a>
					<a href="" class="btn waves-effect waves-light z-depth-0 applyBtn addClientBtn ajaxFalse" onclick="search_catalog_init(0); return false">Применить</a>
					
				</div>
			</div>
			
		</div>
		<div class="col s2 nopad">
			<a class="addDnHb catBtnT t1 waves-effect waves-light ajaxFalse quickSearch" data-type="g_index"><span class="mobIco"><i class="fab fa-google m15"></i></span>индекс
			<span class="searchCounter"><span class="search_min"></span><span class="search_def">-</span><span class="search_max"></span></span>
			</a>
			
			<div class="search_block g_index">
				<div class="input_search_list row">
					<div class="col s5 my-input-field nopad">
						<input type="number" name="g_index_start" value="0" placeholder="От">
					</div>
					<div class="col s2 center-align nopad lnhb">
						-
					</div>
					<div class="col s5 my-input-field nopad">
						<input type="text" name="g_index_end" value="*" placeholder="До">
					</div>
				</div>
				<div class="btnFooterSearch">
					<a href="" class="btn waves-effect waves-light z-depth-0 applyBtn cancelSearchCat addClientBtn ajaxFalse" onclick="clear_catalog_search(\'g_index\'); return false">Очистить</a>
					<a href="" class="btn waves-effect waves-light z-depth-0 applyBtn addClientBtn ajaxFalse" onclick="search_catalog_init(0); return false">Применить</a>
					
				</div>
			</div>
			
		</div>
		<div class="col s3 nopad">
			<a class="addDnHb catBtnT t1 waves-effect waves-light ajaxFalse quickSearch" data-type="traffic"><span class="mobIco"><i class="fas fa-users m15"></i></span>трафик
			<span class="searchCounter"><span class="search_min"></span> <span class="search_def">-</span> <span class="search_max"></span></span>
			</a>
			
			<div class="search_block traffic">
				<div class="input_search_list row">
					<div class="col s5 my-input-field nopad">
						<input type="number" name="traffic_start" value="0" placeholder="От">
					</div>
					<div class="col s2 center-align nopad lnhb">
						-
					</div>
					<div class="col s5 my-input-field nopad">
						<input type="text" name="traffic_end" value="*" placeholder="До">
					</div>
				</div>
				<div class="btnFooterSearch">
					<a href="" class="btn waves-effect waves-light z-depth-0 applyBtn cancelSearchCat addClientBtn ajaxFalse" onclick="clear_catalog_search(\'traffic\'); return false">Очистить</a>
					<a href="" class="btn waves-effect waves-light z-depth-0 applyBtn addClientBtn ajaxFalse" onclick="search_catalog_init(0); return false">Применить</a>
					
				</div>
			</div>
		</div>
		

</div>
'.$category.'
<div class="clientBlock ccatalog">
	<div class="donorsWrapScroll">
		<div class="oneDonor top clearfix">
					<div class="checkBtn don fl"><span class="inputCkeckBtn t1" data-check="0" data-top="1" data-cid="catalog"><i class="fas fa-check"></i></span></div>
								
					<div class="donorDomainCat don fl">Донор (URL)</div>
					<div class="donorCategory don fl">Категория</div>
					<div class="donorIks don fl">ИКС</div>
		
					<div class="donorIndex don fl"><i class="fab fa-yandex-international m15"></i> Индекс</div>
					<div class="donorIndex don fl"><i class="fab fa-google m15"></i> Индекс</div>
					<div class="donorTraf don fl">Трафик</div>
				</div>
		<div class="donListC ">
';
//print_r($json['getCatalog'][0]['donors']);
$donorCount = count($json['getCatalog'][0]['donors']);
foreach($json['getCatalog'][0]['donors'] as $donor)
{
	include('help/catalog_mini_donor.php');	
}
if ($donorCount < $PLUGIN_CONFIG['catalog_page_lim'])
	$clSearch = ' allIsLoad';
else
	$clSearch = '';
$html .= '</div></div></div><div class="navigInFooter'.$clSearch.'" data-form="searchCatalog"></div>
<div class="mobFooterWrap"></div>
<div class="clientFooter row clientBlock ccatalog">
		<div class="col s12 nopad nomar selectDonAct active">
			<div class="selectBg"></div>
			<div class="my-select-top t1 addToGroundDon">
				<a class="ajaxFalse t1 waves-effect waves-light" onclick="get_operation(\'catalog\', 5); return false">Добавить к площадке</a>
			</div>
			<div class="footerCatLoader t2"></div>
		</div>
	</div>
</div></form>
<div id="popUpOperDonors" class="modal active">
<div class="wrap catalogAddedDonors">
<div class="loaderInPopUp">
        	<div class="lds-roller"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>
        </div>
					

<div class="resultOper">

</div>
					</div>
</div>
';
print $html;
