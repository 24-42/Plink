<?php
if ($good_count)
{
	$addToModer = ''; $i = 1;
	foreach ($good as $g)
		$addToModer .= '<li><span class="donCounter">'.($i++).'.</span> <a href="'.$g['url'].'" class="t1 ajaxFalse" target="_blank">'.$g['url'].'</a></li>';
	$addToModer = '<div class="goodList"><div class="ltsTtls"><i class="fas fa-check m15"></i>Успешно добавленные доноры. ['.$good_count.' шт.]</div><div class="infoDDon">Доноры отправлены на модерацию, по результатам которой вы будете оповещены на ваш Email.</div><ul>'.$addToModer.'</ul></div>';
}
if ($bad_count)
{
	$delList = '';
	$i = 1;
	foreach ($bad as $b)
		$delList .= '<li><span class="donCounter">'.($i++).'.</span> <a href="'.$b['url'].'" class="t1 ajaxFalse" target="_blank">'.$b['url'].'</a></li>';
	$delList = '<div class="badList"><div class="ltsTtls"><i class="fas fa-times m15"></i>Отклоненные доноры. ['.$bad_count.' шт.]</div>
	<div class="infoDDon">Доноры отклонены, так как были добавлены к площадке «'.$ground['domain'].'» ранее, либо они заблокированы в системе.</div>
	<ul>'.$delList.'</ul>
	</div>';
}
$html = '<div class="addedListDonors">'.$addToModer.$delList.'</div><div class="pop-btn">
            	<span class="addClientBtn sendAddDonbtn waves-effect waves-light btn z-depth-0 modal-close" onclick="location.reload();"><i class="fas fa-check-circle"></i>Завершить</span>
            </div>';