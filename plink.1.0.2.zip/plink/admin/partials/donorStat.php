<?php 

if ($statType == 'donor')
{
	$params					= json_decode($donor['donorParams'], true);
	$fav					= $this->sys->getFavIcon($params['donorInfo']['favicon']);
	$domain					= $donor['domain'];
	$url					= $donor['url'];
}
if ($statType == 'ground')
{
	$params					= json_decode($ground['paramsList'], true);
	$fav					= $this->sys->getFavIcon($params['clientInfo']['favicon'], 2);
	$domain					= $ground['domain'];
	$url					= '//'.$ground['domain'];
	$donor['donor_id'] = 0;

}
$html = '
<div class="loader_form">
        	<div class="lds-roller"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>
					</div>
<div class="clientInfo row nopad nomar clearfix checkDonorId">
                <div class="col s8 clientUrl nopad">
                    <div class="btnTops cltUrl"><a href="'.$url.'" target="_blank" class="t1 waves-effect waves-light ajaxFalse"><span class="favIcon" style="background:url(\''.$fav.'\') no-repeat; background-size:100%;"></span>'.$domain.'</a></div>

					<div class="btnTops statUrl"><a target="_blank" class="t1 waves-effect waves-light ajaxFalse" onclick="get_stat(\''.$statType.'\', '.$ground['ground_id'].', '.$donor['donor_id'].', 7); return false">неделя</a></div>
					<div class="btnTops statUrl"><a target="_blank" class="t1 waves-effect waves-light ajaxFalse" onclick="get_stat(\''.$statType.'\', '.$ground['ground_id'].', '.$donor['donor_id'].', 31); return false">месяц</a></div>
					<div class="btnTops statUrl"><a target="_blank" class="t1 waves-effect waves-light ajaxFalse" onclick="get_stat(\''.$statType.'\', '.$ground['ground_id'].', '.$donor['donor_id'].', 182); return false">пол года</a></div>
					<div class="btnTops statUrl"><a target="_blank" class="t1 waves-effect waves-light ajaxFalse" onclick="get_stat(\''.$statType.'\', '.$ground['ground_id'].', '.$donor['donor_id'].', 365); return false">год</a></div>
					<div class="btnTops balansUrl"><span class="moneyLcl t1"><span class="moneSpCl t1">БАЛАНС:</span> '.$user_balance.' руб.</span></div>
                </div>';
				if ($statType == 'donor')
                	$html .='<div class="col s4 clientSet">
                    <span class="admBtn t1 waves-effect waves-light modal-close"><i class="fas fa-times"></i></span>
                </div>';
$html .= '</div>
<ul class="statTable topTable row">
	<li class="statDay col t1 s4" data-rev="1" onclick="sortTable(\'day\');">День<i class="fas fa-sort"></i></li>
	<li class="statCount col t1 s4" data-rev="1" onclick="sortTable(\'count\');">Посты<i class="fas fa-sort"></i></li>
	<li class="statMoney col t1 s4" data-rev="1" onclick="sortTable(\'money\');">Стоимость<i class="fas fa-sort"></i></li>
</ul>
<div class="statRows">';
$countPosts = 0;
$countMoney = 0;
/*foreach($stat['daysList'] as $day)
{
	$html .= '<ul class="statTable row t1" data-day="'.$day['unix_min'].'" data-count="'.$day['posts'].'" data-money="'.$day['money'].'">
			<li class="statDay col s4">'.$day['day'].'</li>
			<li class="statCount col s4"><span class="ccStat t1" onclick="posts_control('.$ground['ground_id'].', '.$donor['donor_id'].', '.$day['unix_min'].', '.$day['unix_max'].'); return false">'.$day['posts'].' шт.</span></li>
			<li class="statMoney col s4">'.$day['money'].' руб.</li>
		</ul>';
	$countPosts += $day['posts'];
	$countMoney += $day['money'];
}*/
foreach($stat['allDays'] as $topDay)
{
	foreach($stat['daysList'] as $dd)
	{
		if ($dd['unix_min'] == $topDay['unix'])
			$day = $dd;
	}
	if (!$day)
		$day = array('unix_min' => $topDay['unix'], 'posts' => 0, 'money' => 0);
	if ($topDay['stat']['posts'] > 0)
	{
		$day['posts'] = $topDay['stat']['posts'];
		$day['money'] = $topDay['stat']['money'];
		$day['unix_min'] = $topDay['stat']['min'];
		$day['unix_max'] = $topDay['stat']['max'];
	}
	$html .= '<ul class="statTable row t1" data-day="'.$day['unix_min'].'" data-count="'.$day['posts'].'" data-money="'.$day['money'].'">
			<li class="statDay col s4">'.$topDay['day'].'</li>
			<li class="statCount col s4">';
			if ($day['posts'] == 0)
				$html .= '0 шт.';
			else
				$html .= '<span class="ccStat t1" onclick="posts_control('.$ground['ground_id'].', '.$donor['donor_id'].', '.$day['unix_min'].', '.$day['unix_max'].'); return false">'.$day['posts'].' шт.</span>';
			
			$html .= '</li>
			<li class="statMoney col s4">'.$day['money'].' руб.</li>
		</ul>';
	$countPosts += $day['posts'];
	$countMoney += $day['money'];
	unset($day);
}
	
$html .= '
</div>
<div class="statCounts">
	<ul class="statTable row t1">
		<li class="statDay col s4">Всего</li>
		<li class="statCount col s4">'.$countPosts.' шт.</li>
		<li class="statMoney col s4">'.$countMoney.' руб.</li>
	</ul>
</div>
';
$html .= '<div class="statBtn">';
	
		
$html .= '</div>';
