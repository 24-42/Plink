<?php
$paramsList 			= json_decode($ground['paramsList'], true);

$html = '<form id="addDonorsDone">

<input type="hidden" name="groundId" value="'.$ground['ground_id'].'">
<input type="hidden" name="formType" value="addDonors">
<input type="hidden" name="donorCount" value="'.count($cleanedDonList).'">

<div class="donList topDonList">
<div class="donLi donUrl">Донор (URL)</div>
<div class="donLi donCategory">Категория</div>
<div class="donLi donAuthor">Автор</div>
<div class="donLi donLimit">Статус после модерации</div>
</div>';

$i = 1;
foreach($cleanedDonList as $cdl)
{
	//$catList = '<div class="nomar"><select name="donCat_donNUM'.$i.'"><option disabled>Категория</option>';
	
	if (count($wpCategory))
		$txtVb = 'Выбрать категории <i class="fas fa-caret-down"></i>';
	else
		$txtVb = 'Нет категорий';
	$catList = '<div class="nomar catDownBtn" onclick="slideDonorCategory(\''.$i.'\');">'.$txtVb.'</div><div class="categoryFly my-select catFL'.$i.'">';
	$z = 1;
	foreach ($wpCategory as $c)
	{
		/*$catList .= '<option value="'.$c['cat_ID'].'">'.$c['cat_name'].'</option>';*/
		$catList .= '<div class="myCheckBox ">
					<input type="hidden" value="0" name="category'.$i.'_'.$c->cat_ID.'">
					<span class="myCheck">
						<span class="myCheckSqrd"><i class="fas fa-check"></i></span>
						<span class="myCheckText">'.$c->cat_name.'</span>
					</span>
				</div>';
		$z++;
		$categoryJSON[] = array('id' => $c->cat_ID,'name' => $c->cat_name);
	}
	if ($z > 1)
		$html .= '<textarea class="displayNone" name="wpCategory">'.json_encode($categoryJSON).'</textarea>';
	//$catList .= '</select></div>';
	$catList .= '</div>';
	
	$userList = '<div class="nomar"><select name="donUser_donNUM'.$i.'"><option disabled>Автор</option>';
	foreach ($wpUsers as $u)
	{
		$userList .= '<option value="'.$u->ID.'">'.$u->user_login.'</option>';
	}
	$userList .= '</select></div>';
	
	$statusList = '<div class="nomar"><select name="donStat_donNUM'.$i.'"><option disabled>Статус</option>
	<option value="1">Активна</option>
	<option value="2">Остановлена</option>
	</select></div>';
	
	$html .= '
<div class="donList">
	<div class="donLi donUrl"><input type="hidden" name="donor'.$i.'" value="'.$cdl.'"><a class="ajaxFalse t1" href="'.$cdl.'" target="_blank">'.$cdl.'</a></div>
	<div class="donLi donCategory">'.$catList.'</div>
	<div class="donLi donAuthor">'.$userList.'</div>
	<div class="donLi donLimit">'.$statusList .'</div>
</div>';
$i++;
}

$html .= '

</form><div class="pop-btn done-page">
            	<span class="cancelBtn btn waves-effect waves-light btn z-depth-0 ajaxFalse" onclick="backAddDon();">Назад</span>
            	<span class="addClientBtn sendAddDonbtn waves-effect waves-light btn z-depth-0" onclick="check_form(\'addDonorsDone\'); return false"><i class="fas fa-clipboard-check"></i>Отправить на модерацию</span>
            </div>';