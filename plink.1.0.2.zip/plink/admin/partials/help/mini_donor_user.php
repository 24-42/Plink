<?php
defined('_JEXEC') or die('403');
if ($d['act'] == 1) {
    $textStatus  = 'Активен';
    $classStatus = 'workStatus';
} else if ($d['act'] == 3) {
    $textStatus  = 'Удален';
    $classStatus = 'offlineStatus';
} else if ($d['act'] == 4) {
    $textStatus  = 'На модерации';
    $classStatus = 'moderStatus';
} else if ($d['act'] == 5) {
    $textStatus  = 'Отклонена';
    $classStatus = 'badStatus';
} else {
    $textStatus  = 'Остановлен';
    $classStatus = 'offlineStatus';
}
if ($d['last_add']) {
    $time = time();
    $z    = 'м';
    $cur  = (time() - $d['last_add']) / 60;
    if ($cur > 60) {
        $cur = $cur / 60;
        $z   = 'ч';
        if ($cur > 24) {
            $cur = $cur / 24;
            $z   = 'д';
        }
    }
    $cur = round($cur, 0);
} else {
    $cur = '-';
    $z   = '';
}
$params = json_decode($d['basicParams'], true);
//print_r($d);
//print_r($d); 
$html .= '<div class="oneDonor don' . $d['donor_id'] . ' clearfix">
		<div class="checkBtn don fl"><span class="inputCkeckBtn t1" data-check="0"  data-cid="'.$PLINK_CONFIG['groundId'].'" data-sid="' . $d['donor_id'] . '"><i class="fas fa-check"></i></span></div>
		
		<div class="donorDomain don fl"><span class="favIcon" style="background:url(\'' . sys::getFavIcon($params['donorInfo']['favicon']) . '\') no-repeat; background-size:100%;"></span>
			<span class="targetUrl" onclick="donorSettings('.$d['donor_id'].'); return false">' . $d['url'] . '</span>
		</div>
		<div class="donorStatus don fl '.$classStatus.'">' . $textStatus . '</div>
		<div class="donorHour don fl">' . $d['post_count'] . '</div>
		<div class="donorDay don fl">' . $cur.$z . '</div>
		<div class="donorLast don fl chart_btn" onclick="get_stat(\'donor\', '.$PLINK_CONFIG['groundId'].','.$d["donor_id"].',7)"><i class="fas fa-chart-pie"></i></div>
	</div>';