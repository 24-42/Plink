<?php defined('_JEXEC') or die('403');

if ($donorList['good'] != 0 && $good_count > 0)
{
	$addToModer = ''; $i = 1;
	foreach ($donorList['good'] as $g)
		$addToModer .= '<li><span class="donCounter">'.($i++).'.</span> <a href="'.$g['url'].'" class="t1 ajaxFalse" target="_blank">'.$g['url'].'</a></li>';
	$addToModer = '<div class="goodList"><div class="ltsTtls"><i class="fas fa-check m15"></i>Успешно добавленные доноры. ['.$good_count.' шт.]</div><div class="infoDDon">Доноры добавлены к Вашей площадке «<b>'.$json['getGround'][0]['domain'].'</b>».</div><ul>'.$addToModer.'</ul></div>';
}
if ($donorList['bad'] != 0 && $bad_count > 0)
{
	$delList = '';
	$i = 1;
	foreach ($donorList['bad'] as $b)
	{
		$b['donorParams'] = json_decode($b['donorParams'], true);
		$delList .= '<li><span class="donCounter">'.($i++).'.</span> <a href="'.$b['donorParams']['url'].'" class="t1 ajaxFalse" target="_blank">'.$b['donorParams']['url'].'</a></li>';
	}
	$delList = '<div class="badList"><div class="ltsTtls"><i class="fas fa-times m15"></i>Отклоненные доноры. ['.$bad_count.' шт.]</div>
	<div class="infoDDon">Доноры отклонены, так как были добавлены к площадке «<b>'.$json['getGround'][0]['domain'].'</b>» ранее.</div>
	<ul>'.$delList.'</ul>
	</div>';
}
$html = '<div class="addedListDonors">'.$addToModer.$delList.'</div><div class="pop-btn deleteMoveDon">
            	<span class="addClientBtn sendAddDonbtn waves-effect waves-light btn z-depth-0 modal-close"><i class="fas fa-check-circle"></i>Завершить</span>
            </div>';