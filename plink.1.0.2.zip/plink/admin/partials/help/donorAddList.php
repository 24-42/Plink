<?php defined('_JEXEC') or die('403');

$i = 1;
$donorHTML = '';
	foreach($donors as $d)
	{
		$d['basicParams'] = json_decode($d['basicParams'], true);
		$donorHTML .= '<li class="donEl'.$d['cid'].'"><span class="cancelMoveDel" onclick="deleteElemMoveDonors(\'deleteDonors\', '.$d['cid'].')"><i class="fas fa-times"></i></span><span class="donCounter">'.($i++).'.</span> <a data-donorID="'.$d['cid'].'" href="'.$d['basicParams']['url'].'" class="t1 ajaxFalse" target="_blank">'.$d['basicParams']['url'].'</a></li>';	
	}

$html = '<div class="addedListDonors addLis">
	<div class="goodList">
		<div class="ltsTtls"><i class="fas fa-plus-circle m15"></i>Добавление доноров. [<span class="countDn">'.($i - 1).'</span> шт.]</div>
		<div class="infoDDon">Вы уверенны, что хотите добавить выбранные доноры?</div>
		<ul class="linkList">
';
$html .= $donorHTML;
$html .= '</ul>
	</div>
	<div class="nGrounLis goodList">
		<div class="ltsTtls">Выберите доступную из списка площадку</div>
		<div class="my-input-field col s12">
			<select class="mySelect" name="newGround">';
			
			foreach($grounds as $g)
			{
				if ($g['ground_id'] === $PLINK_CONFIG['groundId'])
					$html .= '<option value="'.$g['ground_id'].'">'.$g['domain'].'</option>';
			}
			$html .= '</select>
		</div>
	</div>
</div>
<div class="pop-btn deleteMoveDon">
	<span class="cancelBtn btn waves-effect waves-light btn z-depth-0 ajaxFalse modal-close">Отмена</span>
	<span class="addClientBtn sendAddDonbtn waves-effect waves-light btn z-depth-0" onclick="move_oper(\'confirmAddDonorsFromCatalog\'); return false"><i class="fas fa-arrow-circle-right"></i>Добавить</span>
</div>
';

unset($donorHTML, $i);
