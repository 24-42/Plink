<?php defined('_JEXEC') or die('403');

if ($d['donorParams'])
	$donorParams		= json_decode($d['donorParams'], true);

if ($d['basicParams'])
	$basicParams		= json_decode($d['basicParams'], true);

				$stopTitleWords 	= '';
				$stopTitleWords		= '';
				$stopStringWords	= '';
				$stopTextWords		= '';
				$replaceTitleWords	= ''; 
				$replaceTextWords	= '';
				$hiddenInputs		= '';
				$catList			= '';
				$userList			= '';
				
				$donorParams = json_decode($d['donorParams'], true);
				$title_temp = "Отличный день, чтобы написать заголовок";
				if ($donorParams['titlePrev'])
					$title_temp = str_replace("{TITLE}", $title_temp, $donorParams['titlePrev']);
				$countStopTitle = 0;
				foreach($donorParams['proovs']['stopTitleWords'] as $proov)
				{
					$stopTitleWords .= '<div class="row nomar oneProv proovNum'.($countStopTitle + 1).'"><div class="col s1 listWord">'.($countStopTitle + 1).'</div><div class="col s9 stopWord" data-text="'.$proov.'">'.$proov.'</div><div class="col s2 delWord"><span class="delProov t1 tooltipped" data-position="left" data-tooltip="Удалить правило" data-num="'.($countStopTitle + 1).'" data-id="deleteTitle" data-donorid="'.$d['donor_id'].'"><i class="fas fa-times"></i></span></div></div>';
					$hiddenInputs .= '<input type="hidden" class="proovInpListdeleteTitle" name="form_proov_deleteTitle_num'.($countStopTitle + 1).'" value="'.$proov.'">';
					$countStopTitle++;
				}
				$countStopString	= 0;
				foreach($donorParams['proovs']['stopStringWords'] as $proov)
				{
					$stopStringWords .= '<div class="row nomar oneProv proovNum'.($countStopString + 1).'"><div class="col s1 listWord">'.($countStopString + 1).'</div><div class="col s9 stopWord" data-text="'.$proov.'">'.$proov.'</div><div class="col s2 delWord"><span class="delProov t1 tooltipped" data-position="left" data-tooltip="Удалить правило" data-num="'.($countStopString + 1).'" data-id="deleteString" data-donorid="'.$d['donor_id'].'"><i class="fas fa-times"></i></span></div></div>';
					$hiddenInputs .= '<input type="hidden" class="proovInpListdeleteString" name="form_proov_deleteString_num'.($countStopString + 1).'" value="'.$proov.'">';
					$countStopString++;
				}
							
				$countStopText = 0;
				foreach($donorParams['proovs']['stopTextWords'] as $proov)
				{
					$stopTextWords .= '<div class="row nomar oneProv proovNum'.($countStopText + 1).'"><div class="col s1 listWord">'.($countStopText + 1).'</div><div class="col s9 stopWord" data-text="'.$proov.'">'.$proov.'</div><div class="col s2 delWord"><span class="delProov t1 tooltipped" data-position="left" data-tooltip="Удалить правило" data-num="'.($countStopText + 1).'" data-id="deleteText" data-donorid="'.$d['donor_id'].'"><i class="fas fa-times"></i></span></div></div>';
					$hiddenInputs .= '<input type="hidden" class="proovInpListdeleteText" name="form_proov_deleteText_num'.($countStopText + 1).'" value="'.$proov.'">';
					$countStopText++;
				}
				$countReplaceTitle = 0;
				foreach($donorParams['proovs']['replaceTitleWords'] as $proov)
				{
					$p = "Найти ".$proov['find']." и заменить на ".$proov['replace'];
					$replaceTitleWords .= '<div class="row nomar oneProv proovNum'.($countReplaceTitle + 1).'"><div class="col s1 listWord">'.($countReplaceTitle + 1).'</div><div class="col s9 stopWord" data-text="'.$proov['find'].'_.@._'.$proov['replace'].'">'.$p.'</div><div class="col s2 delWord"><span class="delProov t1 tooltipped" data-position="left" data-tooltip="Удалить правило" data-num="'.($countReplaceTitle + 1).'" data-id="replaceInTitle" data-donorid="'.$d['donor_id'].'"><i class="fas fa-times"></i></span></div></div>';
					$hiddenInputs .= '<input type="hidden" class="proovInpListreplaceInTitle" name="form_proov_replaceInTitle_num'.($countReplaceTitle + 1).'" value="'.$proov['find'].'_.@._'.$proov['replace'].'">';
					$countReplaceTitle++;
				}
				$countReplaceText = 0;
				foreach($donorParams['proovs']['replaceTextWords'] as $proov)
				{
					$p = "Найти ".$proov['find']." и заменить на ".$proov['replace'];
					$replaceTextWords .= '<div class="row nomar oneProv proovNum'.($countReplaceText + 1).'"><div class="col s1 listWord">'.($countReplaceText + 1).'</div><div class="col s9 stopWord" data-text="'.$proov['find'].'_.@._'.$proov['replace'].'">'.$p.'</div><div class="col s2 delWord"><span class="delProov t1 tooltipped" data-position="left" data-tooltip="Удалить правило" data-num="'.($countReplaceText + 1).'" data-id="replaceInText" data-donorid="'.$d['donor_id'].'"><i class="fas fa-times"></i></span></div></div>';
					$hiddenInputs .= '<input type="hidden" class="proovInpListreplaceInText" name="form_proov_replaceInText_num'.($countReplaceText + 1).'" value="'.$proov['find'].'_.@._'.$proov['replace'].'">';
					$countReplaceText++;
				}
				$countDeleteLinks = 0;
				foreach($donorParams['proovs']['deleteLinksInText'] as $proov)
				{
					$p = "Найти ссылку, в";
					if ($proov['url'])
						$p .= " url которой содержится \"".$proov['url']."\"";
					if ($proov['url'] && $proov['text'])
						$p .= " и в";
					if ($proov['text'])
						$p .= " тексте которой содержится \"".$proov['text']."\"";
					if ($proov['deleteOuterBlock'] == 1)
						$p .= " [Удалить внешний блок]";
						
					$deleteLinksInText .= '<div class="row nomar oneProv proovNum'.($countDeleteLinks + 1).'"><div class="col s1 listWord">'.($countDeleteLinks + 1).'</div><div class="col s9 stopWord" data-text="'.$proov['url'].'_.@._'.$proov['text'].'_.@._'.$proov['deleteOuterBlock'].'">'.$p.'</div><div class="col s2 delWord"><span class="delProov t1 tooltipped" data-position="left" data-tooltip="Удалить правило" data-num="'.($countDeleteLinks + 1).'" data-id="deleteLinksInText" data-donorid="'.$d['donor_id'].'"><i class="fas fa-times"></i></span></div></div>';
					$hiddenInputs .= '<input type="hidden" class="proovInpListdeleteLinksInText" name="form_proov_deleteLinksInText_num'.($countDeleteLinks + 1).'" value="'.$proov['url'].'_.@._'.$proov['text'].'_.@._'.$proov['deleteOuterBlock'].'">';
					$countDeleteLinks++;
				}


$i = 1;
foreach ($wpCategory as $c)
{
	$catList .= '<div class="myCheckBox '.(in_array($c->cat_ID, $donorParams['category']) ? 'checked' : '').'">
					<input type="hidden" value="'.(in_array($c->cat_ID, $donorParams['category']) ? '1' : '0').'" name="category'.$i.'">
					<span class="myCheck">
						<span class="myCheckSqrd"><i class="fas fa-check"></i></span>
						<span class="myCheckText">'.$c->cat_name.'</span>
					</span>
				</div>';
	$i++;
}

foreach ($wpUsers as $u)
{
	$userList .= '<option value="'.$u->data->ID.'"'; if ($donorParams['author'] == $u->data->ID) {$userList .= ' selected="selected"'; } $userList .= '>'.$u->data->user_login.'</option>';
}
	
$title_temp = "Отличный день, чтобы написать заголовок";
if ($donorParams['titlePrev'])
	$title_temp = str_replace("{TITLE}", $title_temp, $donorParams['titlePrev']);

$textSt = $PLUGIN_CONFIG['donorStatusList'][2]['status'];
if ($d['act'] == 1) {$avtiveList = ' work'; $cheked = 'checked="checked"';}
if ($d['act'] == 2) {$textSt = $PLUGIN_CONFIG['donorStatusList'][2]['status'];}
if ($d['act'] == 3) {$textSt = $PLUGIN_CONFIG['donorStatusList'][3]['status'];}
if ($d['act'] == 5) {$textSt = $PLUGIN_CONFIG['donorStatusList'][5]['status'];}
if ($d['act'] == 4) {$avtiveList = ' moder'; $textSt = $PLUGIN_CONFIG['donorStatusList'][4]['status']; $zSt = ' disable'; $tooltp1 = ' tooltipped'; $tooltp2 = '" data-position="bottom" data-tooltip="Модерация занимает не больше суток, после чего донор станет активным"';}

$html .= '
			<form id="saveDonorSettings'.$d['donor_id'].'">
			<div class="loader_form"></div>
			<div class="displayNone donorSetContainer donorNum'.$d['donor_id'].'">
			<input type="hidden" name="formType" value="saveDonorSettings">
			<input type="hidden" name="groundId" value="'.$PLINK_CONFIG['groundId'].'">
			<input type="hidden" name="donorId" value="'.$d['donor_id'].'">
			<div class="hiddenFields displayNone">'.$hiddenInputs.'</div>
            <div class="clientInfo row nopad nomar clearfix">
                <div class="col s8 clientUrl nopad">
                    <div class="btnTops cltUrl"><a data-position="bottom" data-tooltip="'.$d['url'].'" href="'.$d['url'].'" target="_blank" class="t1 tooltipped waves-effect waves-light ajaxFalse"><span class="favIcon"  style="background:url(\''.sys::getFavIcon($basicParams['donorInfo']['favicon']).'\') no-repeat; background-size:100%;"></span>'.$d['domain'].'</a></div>
                    <div class="btnTops cltStatus">
						
						<div class="curWorkStatus ar onStatus active '.$avtiveList.'">
							<!-- Switch -->
							<div class="switch statusGroundBt'.$zSt.'">
								<label class="t1">
								  <input type="checkbox" name="status" '.$cheked.'>
								  <span class="lever"></span>
								  <span class="work_text">'.$PLUGIN_CONFIG['donorStatusList'][1]['status'].'</span>
								  <span class="stop_text'.$tooltp1.'"'.$tooltp2.'>'.$textSt.'</span>
								</label>
							</div>
						</div>
					</div>
                </div>
                <div class="col s4 clientSet">
                    <span class="admBtn t1 waves-effect waves-light modal-close"><i class="fas fa-times"></i></span>
                </div>
            </div>
			
	
            <div class="popUpGroundMenu">
            	  <div class="row">
                    <div class="col s12 nopad">
                      <ul class="tabs grPl">
                        <li class="tab col s3"><a href="#t1'.$d['donor_id'].'" class="ajaxFalse">Настройки</a></li>
                        <li class="tab col s3"><a href="#t2'.$d['donor_id'].'" class="ajaxFalse">Ограничения</a></li>
                        <li class="tab col s3"><a href="#t3'.$d['donor_id'].'" class="ajaxFalse">Контент</a></li>
                      </ul>
                    </div>
                  </div>
             </div>
             	
                	<div class="tabsList">
					
                  		<div id="t1'.$d['donor_id'].'" class="col s12">
						
						
						
						<div class="bigRowP">
								<div class="rowTi">Основное</div>
								<div class="row nomar ">
								<div class="row col s6 nomar nopad ">
										<div class="minRowTi">URL донора</div>
										<div class="col s12 my-input-field">
											<input type="text" name="donorUrl" value="'.$d['url'].'">
										</div>
									</div>
									';

									if ($userList)
									{
									$html .= '<div class="row col s6 nomar nopad ">
										<div class="minRowTi">Автор публикаций</div>
										<div class="my-input-field col s12">
											<select class="mySelect" name="donorAuthor">
											'.$userList.'
										</select>
										</div>
									</div>';
									}
								$html .= '</div>
								';
								if ($catList) {
								$html .= '<div class="row nomar cPdn">
									<div class="row col s12 nomar nopad ">
									<div class="minRowTi">Категории публикаций</div>
										'.$catList.'
									</div>
								</div>';
								}
								
								
						$html .= '</div>
						<div class="row bigRowP">
								<div class="rowTi">Парсинг информации</div>
								<div class="col s12">
									<div class="myCheckBox disable '.($donorParams['parseBlocks']['title'] ? 'checked' : '').'">
										<input type="hidden" value="'.$donorParams['parseBlocks']['title'].'" name="blockTitle">
										<span class="myCheck">
											<span class="myCheckSqrd"><i class="fas fa-check"></i></span>
											<span class="myCheckText">Заголовок</span>
										</span>
									</div>
									
									<div class="myCheckBox '.($donorParams['parseBlocks']['meta_d'] ? 'checked' : '').'">
										<input type="hidden" value="'.$donorParams['parseBlocks']['meta_d'].'" name="blockMetaD">
										<span class="myCheck">
											<span class="myCheckSqrd"><i class="fas fa-check"></i></span>
											<span class="myCheckText">Meta ключи</span>
										</span>
									</div>
									
									<div class="myCheckBox '.($donorParams['parseBlocks']['meta_k'] ? 'checked' : '').'">
										<input type="hidden" value="'.$donorParams['parseBlocks']['meta_k'].'" name="blockMetaK">
										<span class="myCheck">
											<span class="myCheckSqrd"><i class="fas fa-check"></i></span>
											<span class="myCheckText">Meta описание</span>
										</span>
									</div>
									
									<div class="myCheckBox '.($donorParams['parseBlocks']['logo'] ? 'checked' : '').'">
										<input type="hidden" value="'.$donorParams['parseBlocks']['logo'].'" name="blockLogo">
										<span class="myCheck">
											<span class="myCheckSqrd"><i class="fas fa-check"></i></span>
											<span class="myCheckText">Лого</span>
										</span>
									</div>
									
									<div class="myCheckBox '.($donorParams['parseBlocks']['tags'] ? 'checked' : '').'">
										<input type="hidden" value="'.$donorParams['parseBlocks']['tags'].'" name="blockTags">
										<span class="myCheck">
											<span class="myCheckSqrd"><i class="fas fa-check"></i></span>
											<span class="myCheckText">Теги</span>
										</span>
									</div>
									
									<div class="myCheckBox disable '.($donorParams['parseBlocks']['text'] ? 'checked' : '').'">
										<input type="hidden" value="'.$donorParams['parseBlocks']['text'].'" name="blockText">
										<span class="myCheck">
											<span class="myCheckSqrd"><i class="fas fa-check"></i></span>
											<span class="myCheckText">Текст</span>
										</span>
									</div>
								</div>

							</div>
							
							<div class="row bigRowP">
								<div class="rowTi">Настройки поста</div>
								<div class="col s12">
									<div class="myCheckBox '.($donorParams['postSet']['comments'] ? 'checked' : '').'">
										<input type="hidden" value="'.$donorParams['postSet']['comments'].'" name="postSetComments">
										<span class="myCheck">
											<span class="myCheckSqrd"><i class="fas fa-check"></i></span>
											<span class="myCheckText">Разрешить комментарии</span>
										</span>
									</div>
									
									<div class="myCheckBox '.($donorParams['postSet']['ping'] ? 'checked' : '').'">
										<input type="hidden" value="'.$donorParams['postSet']['ping'].'" name="postSetPing">
										<span class="myCheck">
											<span class="myCheckSqrd"><i class="fas fa-check"></i></span>
											<span class="myCheckText">Отправить пинг</span>
										</span>
									</div>
									
								</div>
								
								
								
								<div class="row col s12 nomar nopad timeMinus">
										<div class="minRowTi">Разница между временем парсинга и временем публикации поста в минутах</div>
										<div class="col s12 my-input-field">
											<input type="text" name="timePostMinus" value="'.$donorParams['timePostMinus'].'">
										</div>
									</div>
							</div>

						</div>
						
                    	<div id="t2'.$d['donor_id'].'" class="col s12">

							<div class="row bigRowP">
								<div class="rowTi">Удалить пост, если:</div>
								<div class="col s12">
								
									<div class="myCheckBox '.($donorParams['stopPost']['nologo'] ? 'checked' : '').'">
										<input type="hidden" value="'.$donorParams['stopPost']['nologo'].'" name="deleteIfNoLogo">
										<span class="myCheck">
											<span class="myCheckSqrd"><i class="fas fa-check"></i></span>
											<span class="myCheckText">Отсутствует главное изображение поста</span>
										</span>
									</div>
								
                                	<div class="myCheckBox '.($donorParams['stopPost']['nomedia'] ? 'checked' : '').'">
										<input type="hidden" value="'.$donorParams['stopPost']['nomedia'].'" name="deleteIfNoMedia">
										<span class="myCheck">
											<span class="myCheckSqrd"><i class="fas fa-check"></i></span>
											<span class="myCheckText">В тексте отсутствует медиа-контент</span>
										</span>
									</div>
									
									<div class="myCheckBox '.($donorParams['stopPost']['inlinks'] ? 'checked' : '').'">
										<input type="hidden" value="'.$donorParams['stopPost']['inlinks'].'" name="deleteIfInLinks">
										<span class="myCheck">
											<span class="myCheckSqrd"><i class="fas fa-check"></i></span>
											<span class="myCheckText">В тексте присутствуют внутренние ссылки</span>
										</span>
									</div>
									
									<div class="myCheckBox '.($donorParams['stopPost']['outlinks'] ? 'checked' : '').'">
										<input type="hidden" value="'.$donorParams['stopPost']['outlinks'].'" name="deleteIfOutLinks">
										<span class="myCheck">
											<span class="myCheckSqrd"><i class="fas fa-check"></i></span>
											<span class="myCheckText">В тексте присутствуют внешние ссылки</span>
										</span>
									</div>
								</div>
							</div>


							<div class="bigRowP">
								<div class="rowTi">Заголовок</div>
								
								<div class="row nomar provInputdeleteTitle" data-input="deleteTitle">
								<div class="minRowTi">Удалить пост, если в заголовке содержится</div>
									<div class="my-input-field col s6">
										<input type="text" name="text" value="" placeholder="Слово или фраза">
									</div>
									<div class="col s6">
										<span class="addApr btn waves-effect waves-light btn z-depth-0" onclick="addProov(1, \'deleteTitle\', '.$d['donor_id'].');">Добавить<span class="mob767"> правило</span></span>
										<span class="addApr pruvLi btn waves-effect waves-light btn z-depth-0 tooltipped" data-position="top" data-tooltip="Список правил"><i class="fas fa-clipboard-list"></i><span class="proovCount">'.$countStopTitle.'</span></span> 
									</div>
								</div>
								<div class="proovList provInputdeleteTitle" data-input="deleteTitle">'.$stopTitleWords.'</div>
								<div class="row nomar">
									<div class="minRowTi">Удалить <b>пост</b>, если длина заголовка</div>
									<div class="my-input-field col s6">
										<input type="text" name="titleMinLen" value="'.$donorParams['postLength']['titleMinLen'].'" placeholder="Короче">
									</div>
									<div class="my-input-field col s6">
										<input type="text" name="titleMaxLen" value="'.$donorParams['postLength']['titleMaxLen'].'" placeholder="Длинее">
									</div>
								</div>
							</div>

							<div class="bigRowP">
								<div class="rowTi">Текст</div>
								<div class="row nomar nblk">
									<div class="minRowTi">Медиа-контент</div>
									<div class="my-input-field col s12">
										
										<div class="myCheckBox '.($donorParams['mediaContent']['images'] ? 'checked' : '').'">
											<input type="hidden" value="'.$donorParams['mediaContent']['images'].'" name="imagesInText">
											<span class="myCheck">
												<span class="myCheckSqrd"><i class="fas fa-check"></i></span>
												<span class="myCheckText">Изображения</span>
											</span>
										</div>
										<div class="myCheckBox '.($donorParams['mediaContent']['video'] ? 'checked' : '').'">
											<input type="hidden" value="'.$donorParams['mediaContent']['video'].'" name="videoInText">
											<span class="myCheck">
												<span class="myCheckSqrd"><i class="fas fa-check"></i></span>
												<span class="myCheckText">Видео</span>
											</span>
										</div>
										<div class="myCheckBox '.($donorParams['mediaContent']['audio'] ? 'checked' : '').'">
											<input type="hidden" value="'.$donorParams['mediaContent']['audio'].'" name="audioInText">
											<span class="myCheck">
												<span class="myCheckSqrd"><i class="fas fa-check"></i></span>
												<span class="myCheckText">Аудио</span>
											</span>
										</div>
										<div class="myCheckBox '.($donorParams['mediaContent']['youtube'] ? 'checked' : '').'">
											<input type="hidden" value="'.$donorParams['mediaContent']['youtube'].'" name="youtubeInText">
											<span class="myCheck">
												<span class="myCheckSqrd"><i class="fas fa-check"></i></span>
												<span class="myCheckText">YouTube</span>
											</span>
										</div>
										<div class="myCheckBox '.($donorParams['mediaContent']['facebook'] ? 'checked' : '').'">
											<input type="hidden" value="'.$donorParams['mediaContent']['facebook'].'" name="facebookInText">
											<span class="myCheck">
												<span class="myCheckSqrd"><i class="fas fa-check"></i></span>
												<span class="myCheckText">Facebook</span>
											</span>
										</div>
										<div class="myCheckBox '.($donorParams['mediaContent']['instagram'] ? 'checked' : '').'">
											<input type="hidden" value="'.$donorParams['mediaContent']['instagram'].'" name="instagramInText">
											<span class="myCheck">
												<span class="myCheckSqrd"><i class="fas fa-check"></i></span>
												<span class="myCheckText">Instagram</span>
											</span>
										</div>
										<div class="myCheckBox '.($donorParams['mediaContent']['twitter'] ? 'checked' : '').'">
											<input type="hidden" value="'.$donorParams['mediaContent']['twitter'].'" name="twitterInText">
											<span class="myCheck">
												<span class="myCheckSqrd"><i class="fas fa-check"></i></span>
												<span class="myCheckText">Twitter</span>
											</span>
										</div>
										<div class="myCheckBox '.($donorParams['mediaContent']['iframe'] ? 'checked' : '').'">
											<input type="hidden" value="'.$donorParams['mediaContent']['iframe'].'" name="iframeInText">
											<span class="myCheck">
												<span class="myCheckSqrd"><i class="fas fa-check"></i></span>
												<span class="myCheckText">iFrame</span>
											</span>
										</div>
										
									</div>
								</div>
								<div class="row nomar nblk provInputdeleteText" data-input="deleteText">
								<div class="minRowTi">Удалить <b>пост</b>, если в тексте содержится</div>
									<div class="my-input-field col s6">
										<input type="text" name="text" value="" placeholder="Слово или фраза">
									</div>
									<div class="col s6">
										<span class="addApr btn waves-effect waves-light btn z-depth-0" onclick="addProov(1, \'deleteText\', '.$d['donor_id'].');">Добавить<span class="mob767"> правило</span></span>
										<span class="addApr pruvLi btn waves-effect waves-light btn z-depth-0"><i class="fas fa-clipboard-list"></i><span class="proovCount">'.$countStopText.'</span></span> 
									</div>
								</div>
								<div class="proovList provInputdeleteText" data-input="deleteText">'.$stopTextWords.'</div>
								<div class="row nomar nblk provInputdeleteString" data-input="deleteString">
								<div class="minRowTi">Удалить <b>абзац</b>, если в нем содержится</div>
									<div class="my-input-field col s6">
										<input type="text" name="text" value="" placeholder="Слово или фраза">
									</div>
									<div class="col s6">
										<span class="addApr btn waves-effect waves-light btn z-depth-0" onclick="addProov(1, \'deleteString\', '.$d['donor_id'].');">Добавить<span class="mob767"> правило</span></span>
										<span class="addApr pruvLi btn waves-effect waves-light btn z-depth-0"><i class="fas fa-clipboard-list"></i><span class="proovCount">'.$countStopString.'</span></span> 
									</div>
								</div>
								<div class="proovList provInputdeleteString" data-input="deleteString">'.$stopStringWords.'</div>
								<div class="row nomar">
									<div class="minRowTi">Удалить <b>пост</b>, если длина текста</div>
									<div class="my-input-field col s6">
										<input type="text" name="textMinLen" value="'.$donorParams['postLength']['textMinLen'].'" placeholder="Короче">
									</div>
									<div class="my-input-field col s6">
										<input type="text" name="textMaxLen" value="'.$donorParams['postLength']['textMaxLen'].'" placeholder="Длинее">
									</div>
								</div>
							</div>
							<div class="bigRowP">
								<div class="rowTi">Изображения в тексте</div>
								<div class="row nomar">
									<div class="minRowTi">Удалить <b>пост</b>, если количество изображений меньше или больше</div>
									<div class="my-input-field col s6">
										<input type="text" name="imgMinCount" value="'.$donorParams['postImg']['imgMinCount'].'" placeholder="Меньше">
									</div>
									<div class="my-input-field col s6">
										<input type="text" name="imgMaxCount" value="'.$donorParams['postImg']['imgMaxCount'].'" placeholder="Больше">
									</div>
								</div>
							</div>
							<div class="bigRowP provInputdeleteLinksInText" data-input="deleteLinksInText">
								<div class="rowTi">Ссылки в тексте</div>
								<div class="row nomar nblk">
									<div class="minRowTi">Удалить <b>ссылку</b>, если в ней содержится</div>
									<div class="my-input-field col s3 provOrMob1">
										<input type="text" name="url" value="" placeholder="URL">
									</div>
									<div class="my-input-field col s1 orField provOrMob2">
										<span class="orText">или</span>
									</div>
									<div class="my-input-field col s3  provOrMob3">
										<input type="text" name="text" value="" placeholder="Текст">
									</div>
									
									<div class="col s5  provOrMob4">
										<span class="addApr btn waves-effect waves-light btn z-depth-0" onclick="addProov(3, \'deleteLinksInText\', '.$d['donor_id'].');">Добавить<span class="mob767"> правило</span></span>
										<span class="addApr pruvLi btn waves-effect waves-light btn z-depth-0"><i class="fas fa-clipboard-list"></i><span class="proovCount">'.$countDeleteLinks.'</span></span> 
									</div>
								</div>
								<div class="row nomar nblk">
									<div class="my-input-field col s12">
										<div class="myCheckBox">
											<input type="hidden" value="" name="deleteLinksInText">
											<span class="myCheck">
												<span class="myCheckSqrd"><i class="fas fa-check"></i></span>
												<span class="myCheckText">Удалить внешний блок(абзац или тег) ссылки</span>
											</span>
										</div>
									</div>
								</div>
								<div class="proovList provInputdeleteLinksInText" data-input="deleteLinksInText">'.$deleteLinksInText.'</div>
								
								
							</div>
							
                        </div>
						

						
						
						
						
						
						
						
                    	<div id="t3'.$d['donor_id'].'" class="col s12 ">
						
						
						
						
						<div class="bigRowP">
								<div class="rowTi">Заголовок</div>
								<div class="row nomar nblk">
									<div class="minRowTi">Вид заголовка<div class="titlePrev">Пример: "'.$title_temp.'"</div></div>
									<div class="my-input-field col s12">
										<input type="text" name="titlePrev" value="'.$donorParams['titlePrev'].'" placeholder="" onchange="" onkeyup="title_prev('.$d['donor_id'].');">
									</div>
								</div>
								<div class="row nomar provInputreplaceInTitle" data-input="replaceInTitle">
								<div class="minRowTi">Найти и заменить слово или фразу в заголовке</div>
									<div class="my-input-field col s3">
										<input type="text" name="find" value="" placeholder="Найти">
									</div>
									<div class="my-input-field col s3">
										<input type="text" name="replace" value="" placeholder="Заменить">
									</div>
									<div class="col s6">
										<span class="addApr btn waves-effect waves-light btn z-depth-0" onclick="addProov(2, \'replaceInTitle\', '.$d['donor_id'].');">Добавить<span class="mob767"> правило</span></span>
										<span class="addApr pruvLi btn waves-effect waves-light btn z-depth-0 tooltipped" data-position="top" data-tooltip="Список правил"><i class="fas fa-clipboard-list"></i><span class="proovCount">'.$countReplaceTitle.'</span></span> 
									</div>
								</div>
								<div class="proovList provInputreplaceInTitle" data-input="replaceInTitle">'.$replaceTitleWords.'</div>
								
							</div>
						
						
						
						
						
						
						
						<div class="bigRowP">
								<div class="rowTi">Текст</div>
								<div class="row nomar nblk">
									<div class="minRowTi">Вид текста</div>
									<div class="my-input-field col s12">
										<input type="text" name="textPrev" value="'.$donorParams['textPrev'].'">
									</div>
								</div>
								<div class="row nomar">
									<div class="row col s6 nomar nopad nblk">
										<div class="minRowTi">Внутренние ссылки в тексте</div>
										<div class="my-input-field col s12">
											<select class="mySelect" name="inLinksInText">
											<option value="1" '.($donorParams['linksInText']['in'] == 1 ? 'selected' : '').'>Преобразовать в текст</option>
											<option value="2" '.($donorParams['linksInText']['in'] == 2 ? 'selected' : '').'>Добавить запрет на индексацию</option>
											<option value="3" '.($donorParams['linksInText']['in'] == 3 ? 'selected' : '').'>JavaScript-ссылка</option>
											<option value="4" '.($donorParams['linksInText']['in'] == 4 ? 'selected' : '').'>Оставить в исходном виде</option>
										</select>
										</div>
									</div>
									<div class="row col s6 nomar nopad nblk">
										<div class="minRowTi">Внешние ссылки в тексте</div>
										<div class="my-input-field col s12">
											<select class="mySelect" name="outLinksInText">
											<option value="1" '.($donorParams['linksInText']['out'] == 1 ? 'selected' : '').'>Преобразовать в текст</option>
											<option value="2" '.($donorParams['linksInText']['out'] == 2 ? 'selected' : '').'>Добавить запрет на индексацию</option>

											<option value="3" '.($donorParams['linksInText']['out'] == 3 || !$donorParams['linksInText']['out'] ? 'selected' : '').'>JavaScript-ссылка</option>
											<option value="4" '.($donorParams['linksInText']['out'] == 4 ? 'selected' : '').'>Оставить в исходном виде</option>
										</select>
										</div>
									</div>
								</div>
								<div class="row nomar provInputreplaceInText" data-input="replaceInText">
								<div class="minRowTi">Найти и заменить слово или фразу в тексте</div>
									<div class="my-input-field col s3">
										<input type="text" name="find" value="" placeholder="Найти">
									</div>
									<div class="my-input-field col s3">
										<input type="text" name="replace" value="" placeholder="Заменить">
									</div>
									<div class="col s6">
										<span class="addApr btn waves-effect waves-light btn z-depth-0" onclick="addProov(2, \'replaceInText\', '.$d['donor_id'].');">Добавить<span class="mob767"> правило</span></span>
										<span class="addApr pruvLi btn waves-effect waves-light btn z-depth-0"><i class="fas fa-clipboard-list"></i><span class="proovCount">'.$countReplaceText.'</span></span> 
									</div>
								</div>
								<div class="proovList provInputreplaceInText" data-input="replaceInText">'.$replaceTextWords.'</div>
							</div>
						
						<div class="bigRowP">
								<div class="rowTi">Источник</div>
								<div class="row nomar nblk">
									<div class="minRowTi">Вид источника</div>
									<div class="my-input-field col s12">
										<input type="text" name="sourcePrev" value="'.$donorParams['sourcePrev'].'">
									</div>
								</div>
								<div class="row nomar">
								
									<div class="row col s6 nomar nblk nopad">
										<div class="minRowTi">Формат</div>
										<div class="my-input-field col s12">
											<select class="mySelect" name="source">
												<option value="1" '.($donorParams['source']['source'] == 1 || !$donorParams['source']['source'] ? 'selected' : '').'>Не указывать</option>
												<option value="2" '.($donorParams['source']['source'] == 2 ? 'selected' : '').'>В формате ссылки</option>
												<option value="3" '.($donorParams['source']['source'] == 3 ? 'selected' : '').'>В текстовом формате</option>
											</select>
										</div>
									</div>
									<div class="row col s6 nomar nblk nopad">
										<div class="minRowTi">Позиция</div>
										<div class="my-input-field col s12">
											<select class="mySelect" name="sourcePosition">
												<option value="1" '.($donorParams['source']['position'] == 1 ? 'selected' : '').'>Перед текстом</option>
												<option value="2" '.($donorParams['source']['position'] == 2 ? 'selected' : '').'>В первых абзацах</option>
												<option value="3" '.($donorParams['source']['position'] == 3 ? 'selected' : '').'>В последних абзацах</option>
												<option value="4" '.($donorParams['source']['position'] == 4 || !$donorParams['source']['position'] ? 'selected' : '').'>После текста</option>
											</select>
										</div>
									</div>
									
									
									
								</div>	
									
								<div class="row nomar">
								<div class="row col s6 nomar nblk nopad">
									<div class="minRowTi ">Адрес</div>
									<div class="my-input-field col s12">
										<select class="mySelect" name="sourceAdr">
										<option value="1" '.($donorParams['source']['address'] == 1 ? 'selected' : '').'>URL статьи</option>
										<option value="2" '.($donorParams['source']['address'] == 2 || !$donorParams['source']['address'] ? 'selected' : '').'>URL главной страницы</option>
									</select>
									</div>
								</div>
								<div class="row col s6 nomar nblk nopad">
									<div class="minRowTi">Индексация</div>
									<div class="my-input-field col s12">
										<select class="mySelect" name="sourceIndex">
										<option value="1" '.($donorParams['source']['index'] == 1 || !$donorParams['source']['index'] ? 'selected' : '').'>Добавить запрет на индексацию</option>
										<option value="2" '.($donorParams['source']['index'] == 2 ? 'selected' : '').'>JavaScript-ссылка</option>
										<option value="3" '.($donorParams['source']['index'] == 3 ? 'selected' : '').'>Открыта для индексации</option>
									</select>
									</div>
								</div>
								</div>
						</div>

							
							
						</div>
		
					</div>
            <div class="btnBottom">
            	<span class="addClientBtn saveSettingBtn waves-effect waves-light btn z-depth-0" onclick="check_form(\'saveDonorSettings\', '.$d['donor_id'].'); return false"><i class="fas fa-check-circle"></i>Сохранить</span>
				<img class="btnloader displayNone" src ="/wp-content/plugins/plink/admin/img/loader.gif">
            </div>
			</div>
		</form>
        ';
