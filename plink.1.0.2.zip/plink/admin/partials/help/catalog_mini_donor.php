<?php defined('_JEXEC') or die('403');
if ($donor['qsi'] == -1)
	$donor['qsi'] = '?';
if ($donor['index_ya'] == -1)
	$donor['index_ya'] = '?';
if ($donor['index_g'] == -1)
	$donor['index_g'] = '?';
if ($donor['traffic'] == -1)
	$donor['traffic'] = '?';
$donor['category'] = json_decode($donor['category'], true);
$categoryList = '';
$i = 0;
$json['getCatalogCategory'][0] = array_reverse($json['getCatalogCategory'][0]);
foreach($json['getCatalogCategory'][0] as $cat)
{
	if (in_array($cat['ccid'], $donor['category']))
	{
		if ($i > 0)
			$categoryList .= ', ';
		$categoryList .= $cat['category_name'];
		$i++;
	}
}
if ($i > 1)
	$z_tol = ' tooltipped';
else
	$z_tol = '';
$params = json_decode($donor['basicParams'], true);
//print_r($donor); 
	$html .= '<div class="oneDonor don'.$donor['cid'].' clearfix">
		<div class="checkBtn don fl"><span class="inputCkeckBtn t1" data-check="0"  data-cid="catalog" data-sid="'.$donor['cid'].'"><i class="fas fa-check"></i></span></div>
		
		<div class="donorDomainCat don fl"><span class="favIcon" style="background:url(\''.sys::getFavIcon($params['donorInfo']['favicon']).'\') no-repeat; background-size:100%;"></span>
			<a class="targetUrl t1 ajaxFalse" href="'.$donor['url'].'" target="_blank">'.$donor['url'].'</a>
		</div>
		<div class="donorCategory don fl'.$z_tol.'" data-position="top" data-tooltip="'.$categoryList.'">'.$categoryList.'</div>
		<div class="donorIks don fl">'.$donor['qsi'].'</div>
		<div class="donorIndex don fl"><a href="#">'.$donor['index_ya'].'</a></div>
		<div class="donorIndex don fl"><a href="#">'.$donor['index_g'].'</a></div>
		<div class="donorTraf don fl">'.$donor['traffic'].'</div>
	</div>';