<?php defined('_JEXEC') or die('403'); ?>
<?php require_once('alerts.php'); $donorsNavig = true; require_once('navig.php');?>
<div id ="donorsTab" class="clientBlock c<?php print $PLINK_CONFIG['groundId']?>"> 
<div class="wrap">
	<div>
		<div id="donors">
<?php
$html = '

<div class="clientInfo row nopad nomar clearfix checkDonorId">
                <div class="col s8 clientUrl nopad">
                    <div class="btnTops cltUrl"><a href="'.$site_url.'" target="_blank" class="t1 waves-effect waves-light ajaxFalse"><span class="favIcon" style="background:url(\''.$fav.'\') no-repeat; background-size:100%;"></span>'.$s_domain.'</a></div>

					<div class="btnTops balansUrl"><span class="moneyLcl t1"><span class="moneSpCl t1">БАЛАНС:</span> '.$user_balance.' руб.</span></div>
                </div>
            </div>

<div class="clientBlock ccatalog">
	<div class="donorsWrapScroll">
		<div class="oneDonor top clearfix">
					<div class="checkBtn don fl"><span class="inputCkeckBtn t1" data-check="0" data-top="1" data-cid="'.$PLINK_CONFIG['groundId'].'"><i class="fas fa-check"></i></span></div>
								
					<div class="donorDomain don fl">Донор (URL)</div>
					<div class="donorStatus don fl">Статус</div>
					<div class="donorHour don fl">Посты</div>
		
					<div class="donorDay don fl">Последний</div>
					<div class="donorLast don fl">Статистика</div>
				</div>
		<div class="donListC ">
';
//print_r($json['getCatalog'][0]['donors']);
//	 print_r($donors);
//	 exit();
foreach($donors as $d)
	include('help/mini_donor_user.php');
	 
$html .= '<div id="popUpDonorEdit" class="modal">
	<div class="modalContent">
		<div class="popUpContent">';
foreach($donors as $d)
	include('help/popUpSaveDonorSettings.php');
$html .= '</div></div></div>';	 
$html .= '</div></div></div>
<div class="clientFooter row">
		<div class="col s3 nopad nomar selectDonAct active">
			<div class="selectBg"></div>
			<div class="my-select-top" onclick="mySelect('.$PLINK_CONFIG['groundId'].');">с выбранными</div>
			<ul class="my-select disable s'.$PLINK_CONFIG['groundId'].'">
				<li class="select-item t1" onclick="get_operation('.$PLINK_CONFIG['groundId'].', 2);">Включить</li>
				<li class="select-item t1" onclick="get_operation('.$PLINK_CONFIG['groundId'].', 1);">Выключить</li>
				<li class="select-item t1" onclick="get_operation('.$PLINK_CONFIG['groundId'].', 4);">Удалить</li>
			</ul>

		</div>
	</div>
</div>

';
	 $html .= '
<div id="popUpStat" class="modal load">
    <div class="modalContent sds">
	<div class="loader_form">
        	<div class="lds-roller"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>
					</div>
        <div class="popUpAjaxContent">
			
        </div>
    </div>
</div>
</div></div>';
	 $html .= '<div id="popUpOperDonors" class="modal load">
	 <div class="modalContent sds">
	 <div class="loader_form">
        	<div class="lds-roller"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>
					</div>
					</div>
<div class="resultOper">

</div>
</div>';
print $html;
