<?php
$i = 1;
$donorHTML = '';
foreach ($donors as $d)
{
	foreach($checkList as $c)
	{
		if ($c == $d['donor_id'])
			$donorHTML .= '<li class="donEl'.$d['donor_id'].'"><span class="cancelMoveDel" onclick="deleteElemMoveDonors(\'deleteDonors\', '.$d['donor_id'].')"><i class="fas fa-times"></i></span><span class="donCounter">'.($i++).'.</span> <a data-donorID="'.$d['donor_id'].'" href="'.$d['url'].'" class="t1 ajaxFalse" target="_blank">'.$d['url'].'</a></li>';
			$ground = $d['ground'];
	}
}

$html = '<div class="addedListDonors offLis" data-ground="'.$ground.'">
	<div class="goodList">
		<div class="ltsTtls"><i class="fas fa-power-off m15"></i></i>Отключение доноров. [<span class="countDn">'.($i - 1).'</span> шт.]</div>
		<div class="infoDDon">Вы уверенны, что хотите выключить выбранные доноры?</div>
		<ul class="linkList">
';
$html .= $donorHTML;
$html .= '</ul>
	</div>
</div>
<div class="pop-btn deleteMoveDon">
	<span class="cancelBtn btn waves-effect waves-light btn z-depth-0 ajaxFalse modal-close">Отмена</span>
	<span class="addClientBtn sendAddDonbtn waves-effect waves-light btn z-depth-0" onclick="move_oper(\'offDonors\'); return false"><i class="fas fa-arrow-circle-right"></i>Выключить</span>
</div>
';

unset($donorHTML, $i);
