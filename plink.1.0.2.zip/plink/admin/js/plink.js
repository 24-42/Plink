'use strict'

jQuery(document).scroll(function()
{
	//console.log(jQuery(".categoryList").hasClass('active'));
	if (!jQuery(".categoryList").hasClass('active'))
		scrolControl();
});

function scrolControl()
{
	
	if(jQuery(".navigInFooter").length != 0 && !jQuery(".navigInFooter").hasClass('loading') && !jQuery(".navigInFooter").hasClass('allIsLoad'))
	{
		if(jQuery(window).scrollTop() + jQuery(window).height() >=  jQuery(".navigInFooter").offset().top)
		{
			var dataForm = jQuery(".navigInFooter").data();
			var cur_page = jQuery('#'+dataForm.form+' input[name=num_page]').val();
			jQuery('#'+dataForm.form+' input[name=num_page]').val(parseInt(cur_page) + 1);
			jQuery(".navigInFooter").click();
		}
	}
}

function clear_catalog_search(id)
{
	if (id == 's_cat_l')
	{
		jQuery(".categoryList .inputCkeckBtn").removeClass("checked");
		search_catalog_init(2);
	}
	else
	{
		jQuery('.search_block.'+id+' input[name='+id+'_start]').val('0');
		jQuery('.search_block.'+id+' input[name='+id+'_end]').val('*');
		search_catalog_init(0);
	}
}

function cleanMsg(c)
{
	jQuery('.wrap_alert.'+c).slideUp(300);
	jQuery('.wrap_alert.'+c).addClass('myHide');
	setTimeout(function() {
		jQuery('.wrap_alert.'+c).remove();
	}, 300);
}

function msgTimer(c)
{
	setTimeout(cleanMsg, 4000, c);
}

function search_catalog_init(act)
{

	var ret = "";
	var data;
	var i = 0;
	jQuery(".categoryList .inputCkeckBtn.checked").each(function ()
	{
		data = jQuery(this).data();
		if (i > 0)
			ret += ',';
		ret += data.sid;
		i++;
	});
	if (!ret)
		var ret = '';
	jQuery("#searchCatalog input[name=searchCategoryListId]").val(ret);
	var form = jQuery('#searchCatalog').serializeArray();
	if (act == 0)
	{
		jQuery('.quickSearch').removeClass('active');
		jQuery('.search_block').removeClass('active');
	}
	jQuery(".catalog .quickSearch").each(function ()
	
	{
		var data = jQuery(this).data();
		if (data.type == 's_cat_l')
		{
			var i = 0;
			jQuery(".categoryList .inputCkeckBtn.checked").each(function ()
			{
				i++;
			});
			if (!i)
				jQuery('.quickSearch[data-type='+data.type+'] .searchCounter').addClass('displayNone');
			else
				jQuery('.quickSearch[data-type='+data.type+'] .searchCounter').removeClass('displayNone');
			jQuery('.quickSearch[data-type='+data.type+'] .searchCounter .search_min').html(i);
		}
		else if (data.type == 'else')
		{
			
		}
		else
		{
			var start	= jQuery('.search_block.'+data.type+' input[name='+data.type+'_start]').val();
			if (!start)
				start = 0;
			var end		= jQuery('.search_block.'+data.type+' input[name='+data.type+'_end]').val();
			if (!end)
				end = "*";
			if (end != '*' && end < start)
			{	
				start = 0;
				end = "*";
			}
			jQuery('.quickSearch[data-type='+data.type+'] .searchCounter .search_min').html((start * 1));
			jQuery('.quickSearch[data-type='+data.type+'] .searchCounter .search_max').html(end);
			if ((start > 0 && end != 0) || (start == 0 && end != '*'))
				jQuery('.quickSearch[data-type='+data.type+'] .searchCounter').addClass('deffIsset');
			else
				jQuery('.quickSearch[data-type='+data.type+'] .searchCounter').removeClass('deffIsset');
				
			if (start > 0 || (start == 0 && end != '*'))
				jQuery('.quickSearch[data-type='+data.type+'] .searchCounter .search_min').removeClass('displayNone');
			else
				jQuery('.quickSearch[data-type='+data.type+'] .searchCounter .search_min').addClass('displayNone');
				
			if ((start > 0 && end != 0) || (start == 0 && end != '*'))
				jQuery('.quickSearch[data-type='+data.type+'] .searchCounter .search_max').removeClass('displayNone');
			else
				jQuery('.quickSearch[data-type='+data.type+'] .searchCounter .search_max').addClass('displayNone');
			jQuery('.search_block.'+data.type+' input[name='+data.type+'_start]').val((start * 1));
			jQuery('.search_block.'+data.type+' input[name='+data.type+'_end]').val(end);
		}
	});
	if (act != 2)
	{
		jQuery('#searchCatalog input[name=num_page]').val('1');
		jQuery('#searchCatalog input[name=reload]').val('1');
		check_form('searchCatalog');
	}
}

jQuery(document).on('click', function(e)
{
	if (!jQuery(e.target).closest(".categoryList").length && !jQuery(e.target).closest(".catBtnTCat").length  && !jQuery(e.target).closest(".search_block").length && !jQuery(e.target).closest(".catBtnT").length)
	{
		jQuery('.categoryList').removeClass('active');
		jQuery('.search_block').removeClass('active');
		jQuery('.quickSearch').removeClass('active');
  	}
  e.stopPropagation();
}).on('click', ".catBtnTCat", function(e)
{
	jQuery(this).toggleClass("active");
	//var data = jQuery(this).data();
	//console.log(data);
	
}).on('click', ".quickSearch", function(e)
{
	var data = jQuery(this).data();
	console.log('.search_block.'+data.type);
	if (jQuery('.search_block.'+data.type).hasClass('active'))
	{
		jQuery('.quickSearch').removeClass('active');
		jQuery('.search_block').removeClass('active');
		jQuery('.only-click-select').removeClass('active');
		jQuery('.quickSearch').removeClass('active');
		//console.log('1');
	} else
	{
		jQuery('.quickSearch').removeClass('active');
		jQuery('.search_block').removeClass('active');
		jQuery('.only-click-select').removeClass('active');
		jQuery('.search_block.'+data.type).addClass('active');
		jQuery(this).addClass("active");
		if (data.type != 's_cat_l')
		{
			jQuery('.search_block.'+data.type+' input[name='+data.type+'_start]').focus();
		}
	}

	
	//jQuery('.quickSearch').removeClass('active');
	
	//var data = jQuery(this).data();
	//console.log(data);
	
}).on('click', ".one_category_list", function(e)
{
	var f = jQuery(this).find('.inputCkeckBtn');
	var data = jQuery(f).data();
	if (data.top != 1)
		jQuery(f).toggleClass('checked');
	search_catalog_init(2);
}).on('click', ".navigInFooter", function(e)
{
	console.log(1111);
	jQuery(".navigInFooter").addClass('loading')
	check_form('searchCatalog');
	//console.log('click');
}).on('click', ".miniMoneyBt", function(e)
{
	jQuery('.moneyAccesJs').html(jQuery('.moneyCountB').html());
});


function selectCategoryGroup(id)
{
	var i = 0;
	var c = 0;
	jQuery(".category"+id+" .inputCkeckBtn").each(function ()
	{
			
		if (!jQuery(this).hasClass('displayNone'))
		{
			if (jQuery(this).hasClass('checked'))
				c++;
			i++;
		}
	});
	
	if (i == c)
	{
		jQuery(".category"+id+" .inputCkeckBtn").removeClass('checked');
		jQuery(".bigC"+id+" .inputCkeckBtn[data-top=1]").removeClass('checked');
	}
	else
	{
		jQuery(".category"+id+" .inputCkeckBtn").addClass('checked');
		jQuery(".bigC"+id+" .inputCkeckBtn[data-top=1]").addClass('checked');
	}
	search_catalog_init(2);
}

jQuery(document).ready(function()
{
	load_materialize();
	jQuery('.modal').modal();
});

function addWatermark(){
	console.log('watermark');
}

function removeWatermark(){
	jQuery(".water").html('<div class="uploadWatermark" onclick="jQuery(\'.avatarUpload\').click();"><i class="fas fa-upload m15"></i>Выбрать</div>');
	jQuery(".watermarkPopUp").html('');
	jQuery(".watermarkInput").val('');
	jQuery("input[name=myAvatarInput]").val('');
}

function ft_FileAjax(e)
{
	var http = new XMLHttpRequest; 
	http.open("POST", loginToPlink.ajaxurl, true);
	http.onreadystatechange = function() {
		console.log(e);
		if(http.readyState == 4 && http.status == 200) 
		{
			
			var data = JSON.parse(http.responseText);
			console.log(data);
			jQuery(".water").html('<div class="col s6"><span class="uploadWatermark" onclick="jQuery(\'#showWatermark\').modal(\'open\');"><i class="fas fa-check m15"></i>Смотреть</span></div><div class="col s6"><span class="uploadWatermark" onclick="removeWatermark();"><i class="fas fa-times m15"></i>Удалить</span></div>');
			jQuery(".watermarkPopUp").html('<img src ="'+data.content[1].html+'">');
			unswerResult(data);
		}
	};
	http.send(e);
	
	return (false);
}

function dayAndHourSet(mH)
{
	var z = 0;
	for (var d = 0; d < 7 ; d++)
		for (var h = 0; h < 24 ; h++)
			if (h == mH)
				if (jQuery('.d'+d+'h'+h).hasClass('active'))
					z++;
	for (var d = 0; d < 7 ; d++)
		for (var h = 0; h < 24 ; h++)
			if (h == mH)
				if (z == 7)
				{
					jQuery('.d'+d+'h'+h+' input').val(0);
					jQuery('.d'+d+'h'+h).removeClass('active');
				}
				else
				{
					jQuery('.d'+d+'h'+h+' input').val(1);
					jQuery('.d'+d+'h'+h).addClass('active');
				}
}

function move_oper(t)
{
	var ar 				= [];
	var i 				= 0;
	var c;
	var n				= '';
	if (t == 'moveDonors')
	{
		var c 			= 'moveLis';
		n				= jQuery('.'+c+' select[name=newGround]').val();
	}
	else if (t == 'deleteDonors')
		var c 			= 'deleteLis';
	else if (t == 'offDonors')
		var c 			= 'offLis';
	else if (t == 'onDonors')
		var c 			= 'onLis';
	else if (t == 'confirmAddDonorsFromCatalog')
	{
		var c 			= 'addLis';
		n				= jQuery('.'+c+' select[name=newGround]').val();
	}
		
	var data 			= jQuery('.'+c).data();
	var groundId 		= data.ground;
	
	jQuery('.'+c+' .linkList li a').each(function ()
	{
		data 			= jQuery(this).data();
		ar[i] 			= data.donorid;
		i++;
	});
	jQuery('#popUpOperDonors').addClass('wait');
	myAjax({"ajax":1, "type":"act", "action":t, "address":loginToPlink.ajaxurl, "groundId":groundId, "donorList":ar, "newGround":n});
}

function addFile(t)
{
    if (t == 'photo') {jQuery('.albumUploadMultiple').click();}
}

function slideDonorCategory(n)
{
	jQuery('.catFL'+n).toggleClass('active');
}

function disable_sel(cid)
{
	var i = 0;
	var c = 0;
	jQuery(".clientBlock.c"+cid+" .inputCkeckBtn").each(function ()
	{
		if (jQuery(this).hasClass('checked'))
			c++;
		i++;
	});
	if (c > 0)
	{
		jQuery(".clientBlock.c"+cid+" .selectDonAct").removeClass('active');
		jQuery(".clientBlock.c"+cid+" .selectDonAct .my-select").removeClass('disable');
	}
	else
	{
		jQuery(".clientBlock.c"+cid+" .selectDonAct").addClass('active');
		jQuery(".clientBlock.c"+cid+" .selectDonAct .my-select").addClass('disable');
	}
}

function backAddDon()
{
	jQuery('.aDdContent').addClass('displayNone');
	jQuery('.addDonContent').removeClass('displayNone');
}


function checkForm(id, donorId)
{
	ifload(id);
  //console.log(jQuery('#'+id).serializeArray());
  if (donorId)
	var fields = jQuery('#'+id+donorId).serializeArray();
else
	var fields = jQuery('#'+id).serializeArray();
	console.log(fields);
	//console.log(fields);
	var data;
	jQuery.each( fields, function(i, field)
	{
		data = jQuery('#'+id+' *[name='+field.name+']').data();
    });
	send_form(id, fields);
}

function changeTab(tab, tr)
{
	if (jQuery('.myTab'+tab).hasClass('active'))
	{
		jQuery('.myTab'+tab).toggleClass('active');
		jQuery('.topTab'+tab).toggleClass('active');
	}
	else
	{
		jQuery('.topTabTrigger'+tr).removeClass('active');
		jQuery('.myTabTrigger'+tr).removeClass('active');
		jQuery('.myTab'+tab).toggleClass('active');
		jQuery('.topTab'+tab).toggleClass('active');
	}
}

function hourSet(d, h)
{
	var z = jQuery('.d'+d+'h'+h+' input').val();
	if (z == 0)
	{
		jQuery('.d'+d+'h'+h+' input').val('1');
		jQuery('.d'+d+'h'+h).addClass('active');
	}
	else
	{
		jQuery('.d'+d+'h'+h+' input').val('0');
		jQuery('.d'+d+'h'+h).removeClass('active');
	}
}

function daySet(d)
{
	var z = 0;
	for (var i = 0; i < 24 ; i++)
		if (jQuery('.d'+d+'h'+i).hasClass('active'))
			z++;
	for (var i = 0; i < 24; i++)
		if (z == 24)
		{
			jQuery('.d'+d+'h'+i+' input').val(0);
			jQuery('.d'+d+'h'+i).removeClass('active');
		}
		else
		{
			jQuery('.d'+d+'h'+i+' input').val(1);
			jQuery('.d'+d+'h'+i).addClass('active');
		}
}

function preSend(json) //
{
	if (json.notif != 1)
	{
		console.log(json);
		if (json.action == 'saveDonorSettings')
		{
				var result = json.params.filter(obj => {
				  return obj.name === 'donorId'
				});
			//console.log(result);
    			jQuery("#saveDonorSettings"+result[0].value).addClass("loading");
			jQuery(".btnloader").removeClass("displayNone")
		}
		else if (json.action == 'addDonorsFromCatalog')
		{
			jQuery('.loaderInPopUp').removeClass("displayNone");
		}
		else if (json.action == 'saveGroundSettings')
		{
    			//jQuery("#saveDonorSettings"+result[0].value).addClass("loading");
				jQuery(".btnloader").removeClass("displayNone");
				jQuery(".sds").addClass("loading");
		}
		
		else
			jQuery(".sds").addClass("loading");
	}
		
}

function afterLoad(json)
{
	//console.log(json);
    if (json.firstLoad == 1)
        jQuery(".contentLoad").removeClass("valign-wrapper");
    jQuery(".ajaxProgressLoad").removeClass("active");


    if(jQuery('*').is('.userDialogs'))
        jQuery(".userDialogs").mCustomScrollbar({setTop: "0px"});
    if(jQuery('*').is('.scrollMeOnBottom'))
        jQuery(".scrollMeOnBottom").mCustomScrollbar({setTop: "-99999px"});
    if(jQuery('*').is('.datepicker'))
    {
        jQuery('.datepicker').pickadate({
            selectMonths: true, // Creates a dropdown to control month
            selectYears: 90, // Creates a dropdown of 15 years to control year,
            today: '',
            clear: 'Clear',
            close: 'Ok',
            closeOnSelect: false, // Close upon selecting a date,
			setDefaultDate: new Date(2011, 0, 1, 0, 0, 0, 0)
        });
    }
	if(jQuery('*').is('.chips') && json.ajax != 2/*&& jQuery('*').is('.trtrTags')*/)
	{
		var trptg = jQuery('.trtrTags').html();
		if (trptg)
		{
			var obj = jQuery.parseJSON(trptg);
			jQuery('.chips').material_chip({
				data: obj,
				limit: 3
			});
		} else
		{
			jQuery('.chips').material_chip({
				limit: 3
			});	
		}
	}
	if (json.type != 'form')
    	load_materialize();
	jQuery('.modal.open').removeClass('active');
	jQuery('.addClientBtn').removeClass('disable');
	jQuery(".sds").removeClass("loading");
	jQuery('#popUpOperDonors').removeClass('loading');
	jQuery('.btnloader').addClass("displayNone");
	if (json.action == 'saveDonorSettings')
	{
		var result = json.params.filter(obj => {
			return obj.name === 'donorId'
		});
			//console.log(result);
    	jQuery("#saveDonorSettings"+result[0].value).removeClass("loading");
		jQuery(".btnloader").addClass("displayNone")
	}
}


function alerts_off(c)
{
	jQuery('.one_alert.'+c+'.open').slideToggle(100);
	jQuery('.one_alert.'+c+'.open').removeClass('open');
	jQuery('.errorsBlock.active.'+c).removeClass('active');
	jQuery('.errorsBlock').removeClass(c);
}

function classContent(data, x)
{
    if (data.class == 1 && !x)
        jQuery(data.selector).addClass(data.className);
    if (data.class == -1)
        jQuery(data.selector).removeClass(data.className);
}

function printContent(data)
{
	var type;
    jQuery.each(data.content, function(key, arr)
    {
		type = parseInt(arr.add);
        if (jQuery('*').is(arr.selector) || jQuery(arr.selector).length)
        {
            if (type == 1)
                jQuery(arr.selector).append(arr.html);
            else if (type == 2)
                jQuery(arr.selector).prepend(arr.html);
            else if (type == 3)
                jQuery(arr.selector).html(arr.html);
            else if (type == 4)
                jQuery(arr.selector).css(arr.css, arr.val);
            else if (type == 5)
                jQuery(arr.selector).attr(arr.attr, arr.val);
			else if (type == 6)
				jQuery(arr.selector).text(arr.html);
			else if (type == 7)
				jQuery(arr.selector).click();
			else if (type == 8 || type == 11)
				page(arr.url, 0);
			else if (type == 9)
				jQuery(arr.selector).modal("close");
			else if (type == 10)
				jQuery(arr.selector).val(arr.html);
			else if (type == 12)
				jQuery(arr.selector).focus();
			else if (type == 13)
				window.setTimeout(alerts_off, 20000, arr.html);
			else if (type == 14)
				window.location = arr.url;
			else if (type == 15) {jQuery(arr.selector).tabs(); jQuery(arr.selector).tabs('select_tab', arr.val);}
			else if (type == 16)
				jQuery(arr.selector).modal("open");
			else if (type == 17)
				load_materialize();
			else if (type == 18)
				jQuery(arr.selector).remove();
			else if (type == 19)
				get_text_a();
			else if (type == 20)
				location.reload(true);
			else if (type == 21)
				grecaptcha.reset();
			else if (type == 22)
				scrollWindowToBottom();
			else if (type == 23)
				refresh_files(arr.selector);
			else if (type == 24)
				jQuery(arr.selector).submit();
			else if (type == 25)
				window[''+arr.func+''](''+arr.arg1+'');
			else if (arr.class)
				classContent(arr, jQuery(data.selector).is("."+arr.className));
        }
    });
}

function get_count_donors(id)
{
	//console.log(id);
	var count = 0;
	jQuery('.clientBlock.c'+id+' .inputCkeckBtn').removeClass('checked');
	jQuery('.clientBlock.c'+id+' .selectDonAct').addClass('active');
	jQuery('.clientBlock.c'+id+' .my-select').addClass('disable');
	
	
	jQuery('.clientBlock.c'+id+' .oneDonor').each(function ()
	{
		if (!jQuery(this).hasClass('top') && !jQuery(this).hasClass('deleteMe'))
		{
			if (count > 2)
				jQuery(this).addClass('displayNone').addClass('slideMeBack');
			else
				 jQuery(this).removeClass('displayNone').removeClass('slideMeBack');
			count++;
		}
	});
	if (count > 3)
	{
		jQuery('.clientBlock.c'+id+' .showAllDonor').removeClass('displayNone');
		var text = '<span data-id="'+id+'" class="showBtn t1 waves-effect waves-light"><span class="vievBtn hideB displayNone">Скрыть</span><span class="vievBtn viewB">Показать еще</span> '+(count - 3)+' из '+count+' шт.</span>';
		jQuery('.clientBlock.c'+id+' .showAllDonor').html(text);
	}
	else
	{
		jQuery('.clientBlock.c'+id+' .showAllDonor').addClass('displayNone');
	}
}


function unswerResult(data, data_or)
{
	var cls,name;
	//console.log(data_or.params);
	console.log(1,data_or);
	if (data)
	{
    	if (data.action == 1)
        	printContent(data);
	}
	if (data_or){
		if (data_or.params)
			{
				var result = data_or.params.filter(obj => {
			  return obj.name === "vkAppId";
			})
				if (result.length)
				{
					console.log(result);
					if (!result[0].value)
						jQuery('#showInstructionKey .modal-content').html('<h4>Как получить секретный ключ(Токен)</h4><p>Сперва сохраните ID приложения.</p>');
					else
						jQuery('#showInstructionKey .modal-content').html('<h4>Как получить секретный ключ(Токен)</h4><p>1. Перейдите по ссылке <a href="https://oauth.vk.com/authorize?client_id='+result[0].value+'&scope=wall,photos,offline&redirect_uri=https://oauth.vk.com/blank.html&display=page&response_type=token" target="_blank">Получить ключ</a></p><p>2. Нажмите кнопку "Разрешить".</p><p><img src="/wp-content/plugins/plink/resources/instruction/instruction-4.jpg"></p><p>3. Скопируйте acces_token из адресной строки и вставьте в поле настроек.</p><p><img src="/wp-content/plugins/plink/resources/instruction/instruction-5.jpg"></p><p>Осталось ввести ID группы VK и ID создателя группы нажать сохранить и автопостинг настроен.</p>');
				}
			}
		if(data_or.action == 'offDonors' || data_or.action == 'onDonors')
		{
			if(data_or.action == 'offDonors')
			{
				cls = 'offlineStatus';
				name = 'Остановлен';
			}
			else if (data_or.action == 'onDonors')
			{
				cls = 'workStatus';
				name = 'Активен';
			}
			var span = '<span class='+cls+'>'+name+'</span>';
			jQuery.each(data_or.donorList, function(el){
				jQuery('.status'+data_or.donorList[el]).html(span);
			});
		}
		else if (data_or.action == 'deleteDonors')
		{
			jQuery.each(data_or.donorList, function(el){
				jQuery('.donorN'+data_or.donorList[el]).html('');
			});
		}

	//console.log(result);
		if (data_or.action == 'saveDonorSettings')
		{
			var result = data_or.params.filter(obj => {
				return obj.name === 'donorId'
			});
			jQuery("#saveDonorSettings"+result[0].value).removeClass("loading");
		}
		else
			jQuery(".sds").removeClass("loading");
		jQuery(".btnloader").addClass("displayNone");
		//jQuery(".clientBlock").removeClass("displayNone");
	}
}

function sortTable(type)
{
	var el = [];
	var i = 0;
	var data;
	jQuery('.statRows .statTable').each(function ()
	{
		data = jQuery(this).data();
		el[i] = {'day':data.day,'count':data.count,'money':data.money}
		i++;
	});
	if (type == 'day')
	{
		data = jQuery('.topTable .statDay').data();
		el.sort((prev, next) => prev.day - next.day);
		if (data.rev == 1) jQuery('.topTable .statDay').data('rev', 0); else jQuery('.topTable .statDay').data('rev', 1);
	}
	else if (type == 'count')
	{
		data = jQuery('.topTable .statCount').data();
		el.sort((prev, next) => prev.count - next.count);
		if (data.rev == 1) jQuery('.topTable .statCount').data('rev', 0); else jQuery('.topTable .statCount').data('rev', 1);
	}
	else if (type == 'money')
	{
		data = jQuery('.topTable .statMoney').data();
		el.sort((prev, next) => prev.money - next.money);
		if (data.rev == 1) jQuery('.topTable .statMoney').data('rev', 0); else jQuery('.topTable .statMoney').data('rev', 1);
	}
	var newHTML = '';
	if (data.rev == 1)
		el.reverse();
	el.forEach(function(e, i) {
		newHTML += jQuery('.statRows .statTable[data-day='+e.day+']')[0].outerHTML;
	});
	jQuery('.statRows').html(newHTML);
}

function get_stat(type, ground_id, donor_id, days)
{
	if (donor_id != 0){
		//jQuery('#popUpStat').addClass("load");
		console.log(donor_id);
		jQuery('#popUpStat').modal("open")
	}
	
	myAjax({"ajax":"1", "type":"act", "action":"getStat", "address":loginToPlink.ajaxurl, "statType":type, "groundId":ground_id, "donorId":donor_id, "days":days});
}

function load_materialize()
{
    jQuery('.tooltipped').tooltip({delay: 50});
	//jQuery('.carousel.carousel-slider').carousel({fullWidth: true});
   // jQuery('.dropdown-button').dropdown();
   // jQuery('select').material_select();
	jQuery('.dropdown-trigger').dropdown();
	jQuery('.tabs').tabs();
	//Materialize.updateTextFields();
}

function errorReport(jqXHR, exception)
{
    var msg = '';
    if (jqXHR.status === 0 || exception === 'abort')
        msg = 'Query aborted or no internet connection.';
    else if (jqXHR.status == 404)
        msg = 'Page not found.';
    else if (jqXHR.status == 500)
        msg = 'Internal Server Error.';
    else if (exception === 'parsererror')
    {msg = 'Requested JSON parse failed.';}
    else if (exception === 'timeout')
        msg = 'Time out error.';
    else
        msg = 'Uncaught Error.\n' + jqXHR.responseText;
    if (msg != '')
        console.log(msg);
}


function myAjax(data)
{
	if (data.newUrl)
		var url = data.newUrl;
	else
		var url = '/';
	//console.log(data);
    jQuery.ajax({
        type: "POST",
        url: url,
        dataType: "json",
        data: data,
        beforeSend: function()
        {
            preSend(data);
        },
        success: function (res, textStatus)
        {
			//console.log(res);
            if (textStatus == "success")
			{
				
				if (data.type == 'form' && data.formID)
					jQuery("#"+data.formID).removeClass('loading');
                unswerResult(res);
			}

			if (data.notif != 1)
			{
				//console.log(data);
				afterLoad(data);
			}
        },
        error: function (jx, ex)
        {
			//console.log(jx, ex);
            afterLoad(data);
            errorReport(jx, ex);
        }
    });
}

function deleteElemMoveDonors(type, id)
{
	var p;
	if (type == 'deletePosts')
	{
		p = 'popUpDeletePostsConfirm';
	}
	else
		p = 'popUpOperDonors';
	jQuery('#'+p+' .linkList .donEl'+id).remove();
	var i = 0;
	jQuery('#'+p+' .linkList li').each(function ()
	{
		jQuery(this).find('.donCounter').html((i+1)+'.');
		i++;
	});
	jQuery('#'+p+' .countDn').html(i);
	if (i == 0)
	{
		jQuery('#'+p).modal("close");
		if (type == 'deletePosts')
			jQuery('#popUpPostControl').modal("open");
	}
}

function valid_file(file)
{
    var n = file.size / 1024; var a = file.name.split("."), i = a.pop().toLowerCase();
    if ("png" != i) return ("Неверный формат изображения. Нужный формат PNG");
    if (n > 2048) return ("Максимальный размер файла не более 2 МБ. ["+ parseFloat(n / 1024).toFixed(1) + " MB.]");
    if (1 > n) return ("Минимальный размер файла не менее 1 КБ. ["+ Math.round(n) + " KB.]");
    return (false);
}

/*jQuery('*').on( "click", ".sendAjax", function()
{
    var data = jQuery(this).data();
    if (data['file'] == 1)
    {   
        if (data.t == 1) var c = '.onlyCom'; 
        if (data.t == 2) var c = '.galleryUp';
        var files = new FormData(); var stp; var noAjax = false; var count_p = 0;
        jQuery.each(data, function(key, val) {if (key != 'ajax') files.append(key, val);});
        files.append("ajax", 3);
        files.append("type", data.t);
        jQuery(c+" .upload_list .photo-i").each(function() {count_p++;});
        var z = count_p; var valid;
        jQuery.each(jQuery("."+data['fileclass'])[0].files, function(i, file) {files.append('file-'+i, file); if ((valid = valid_file(file))){alert(valid); stp = true;} z++;});
        jQuery('.'+data.fileclass).val("").removeClass("sendAjax");
        var multi = jQuery("."+data['fileclass']).attr("multiple");
        if (multi) {if (z > 1) {alert("Максимум 1 файл"); stp = true;}}
        if (!stp) {jQuery(c+' .bg_load_files').addClass('active'); myFileAjax(files);}
    }
});*/

function unswerFileResult(data)
{
    jQuery(".upload_list").html(data.html); 
	jQuery(".watermarkInput").val(data.watermark); 
	jQuery('.bg_load_files').removeClass('active');
}

function myFileAjax(e)
{
    var http = new XMLHttpRequest; 
    http.open("POST", "/wp-content/plugins/plink/admin/ajax.php", true);
    http.onreadystatechange = function() {if(http.readyState == 4 && http.status == 200) {unswerFileResult(JSON.parse(http.responseText));}};
    http.send(e);   
    return (false);
}

function deleteUpload(id)
{
	jQuery('.upload_list').html('');
	jQuery(".watermarkInput").val('');
}

function donorSettings(donorid)
{
	jQuery('#popUpDonorEdit').modal('open');
	jQuery('.donorSetContainer').addClass('displayNone');
	jQuery('.donorSetContainer.donorNum' + donorid).removeClass('displayNone');
}

function page(href)
{
	myAjax({"ajax":"1", "address":""+href+"", "firstLoad":0, "newUrl":""+href+""});
	page_url(href);
}

function page_url(href)
{
	history.replaceState(null, null, href);
}

//function send_form(id, fields)
//{
//	myAjax({"ajax": 1 , "type":"form", "address": loginToPlink.ajaxurl, "params":fields, "action" : id});
//}

function send_form(id, fields)
{
	if (id == 'reg')
	{
		var data = jQuery('#'+id).data();
		var captcha = grecaptcha.getResponse();
		if (!captcha)
		{
			Materialize.toast(window.error_4, 2000);
			return false;
		}
		jQuery('#'+id+' input[name=captcha]').val(captcha);
		
	}
	
	console.log(id);
	if (!jQuery('#'+id).hasClass('novalid'))
	{	
		jQuery('#'+id).addClass('loading');
		
		//myAjax({"ajax": 1 , "type":"form", "address": loginToPlink.ajaxurl, "params":fields, "action" : id});
		myAjax({"ajax":"1", "type":"form", "formID":id, "address":loginToPlink.ajaxurl, "firstLoad":0, "params":fields, "action" : id});
	}
}	

function ifload(id)
{
	if(id == 'auth')
	{
		jQuery('#auth').addClass('loading');
	}
	
	if (id == 'addGround')
	{
		jQuery('#popUpAddGround').addClass('active');
		jQuery('.addClientBtn').addClass('disable');
	}
	if (id == 'saveSettings')
	{
		jQuery('#popUpGroundSettings').addClass('saving');
	}
	if (id == 'addDonors')
	{
		jQuery('#popUpAddDonors').addClass('load');
	}
}

function check_form(id, donor_id)
{
	ifload(id);
  //console.log(jQuery('#'+id).serializeArray());
  //console.log('#'+id);
	var fields = jQuery('#'+id).serializeArray();
	var data;
	jQuery.each( fields, function(i, field)
	{
		data = jQuery('#'+id+' *[name='+field.name+']').data();
	});
	if (donor_id)
	{
		var fields = jQuery("#"+id+donor_id).serializeArray();
		var data;
		console.log(fields);
		jQuery.each( fields, function(i, field)
		{
			data = jQuery('#'+id+' *[name='+field.name+']').data();
		});
	}
	send_form(id, fields);
}

function title_prev(donorid)
{
	var title = jQuery('.donorNum'+donorid+' input[name=titlePrev]').val();
	title = title.replace(/{TITLE}/g, 'Отличный день, чтобы написать заголовок');
	jQuery('.donorNum'+donorid+' .titlePrev').html('Пример: "'+title+'"');
}

function addProov(type, id, donorid)
{	
	if (type == 1)
	{
		var val = jQuery('.donorNum'+donorid+' .provInput'+id+' input[name=text]').val();
		if(val.length > 3)
			jQuery('.donorNum'+donorid+' .proovList.provInput'+id).prepend('<div class="row nomar oneProv"><div class="col s1 listWord"></div><div class="col s9 stopWord" data-text="'+val+'">'+val+'</div><div class="col s2 delWord"><span class="delProov t1 tooltipped" data-position="left" data-tooltip="Удалить правило" data-donorid="'+donorid+'"><i class="fas fa-times"></i></span></div></div>');
	} else if (type == 2)
	{
		var f = jQuery('.donorNum'+donorid+' .provInput'+id+' input[name=find]').val();
		var r = jQuery('.donorNum'+donorid+' .provInput'+id+' input[name=replace]').val();
		if(f.length > 2 && r.length > 2)
		{
			var val = "Найти "+f+" и заменить на "+r;
			var inp = f+'_.@._'+r;
			jQuery('.donorNum'+donorid+' .proovList.provInput'+id).prepend('<div class="row nomar oneProv"><div class="col s1 listWord"></div><div class="col s9 stopWord" data-text="'+inp+'">'+val+'</div><div class="col s2 delWord"><span class="delProov t1 tooltipped" data-position="left" data-tooltip="Удалить правило" data-donorid="'+donorid+'"><i class="fas fa-times"></i></span></div></div>');
		}
	}
	else if (type == 3)
	{
		var r = jQuery('.donorNum'+donorid+' .provInput'+id+' input[name=text]').val();
		if (!r) r = '';
		var f = jQuery('.donorNum'+donorid+' .provInput'+id+' input[name=url]').val();
		if (!f) f = '';
		var c = jQuery('.donorNum'+donorid+' .provInput'+id+' input[name=deleteLinksInText').val();
		if (!c)
			c = '0';
		if(f.length > 1 || r.length > 1)
		{
			var val = "Найти ссылку, в ";
			if (f)
				val += " url которой содержится \""+f+"\"";
			if (f && r)
				val += " и в";
			if (r)
				val += " тексте которой содержится \""+r+"\"";
			if (c == 1)
				val += " [Удалить внешний блок]";
			var inp = f+'_.@._'+r+'_.@._'+c;
			jQuery('.donorNum'+donorid+' .proovList.provInput'+id).prepend('<div class="row nomar oneProv"><div class="col s1 listWord"></div><div class="col s9 stopWord" data-text="'+inp+'">'+val+'</div><div class="col s2 delWord"><span class="delProov t1 tooltipped" data-position="left" data-tooltip="Удалить правило" data-donorid="'+donorid+'"><i class="fas fa-times"></i></span></div></div>');
			console.log('.donorNum'+donorid+' .proovList.provInput'+id);
		}
	}
	update_num(donorid);
}

function get_operation(cid, oper)
{
	var d = [];
	var url = jQuery('.clientBlock.c'+cid+' .clientUrl .cltUrl').html();
	jQuery('#popUpOperDonors input[name=groundId]').val(cid);
	jQuery('#popUpOperDonors .clientUrl .cltUrl').html(url);
	jQuery('#popUpOperDonors').modal('open');
	jQuery('.my-select').removeClass('active');
	var i = 0;
	var c = 0;
	var u = 0;
	var action = '';
	jQuery(".clientBlock.c"+cid+" .inputCkeckBtn").each(function ()
	{
		var data = jQuery(this).data();
		if (jQuery(this).hasClass('checked') && !data.top && data['sid'])
		{
			d[c] = data['sid'];
			c++;
		}
		i++;
	});
	if (oper == '1')
		action = 'offDonorList';
	if (oper == '2')
		action = 'onDonorList';
	if (oper == '3')
		action = 'moveDonorList';
	if (oper == '4')
		action = 'deleteDonorList';
	else if (oper == '5')
		action = 'addDonorsFromCatalog';
	jQuery('#popUpOperDonors').addClass('loading');
	myAjax({"ajax":1, "type":"act", "action":""+action+"", "address":loginToPlink.ajaxurl, "groundId":cid, "checkList":d});
}

function mySelect(n)
{
	if (!jQuery('.my-select.s'+n).hasClass('disable'))
		jQuery('.my-select.s'+n).toggleClass('active');
}

function update_num(donorid)
{
	//debugger;
	//jQuery('.oneProv.displayNone').remove();
	
	load_materialize();
	var i;
	var id;
	//debugger;
	jQuery(".donorNum"+donorid+" .proovList").each(function ()
	{
		i = 1;
		id = jQuery(this).attr('data-input');
		jQuery('.donorNum'+donorid+' .proovInpList'+id).remove();
		jQuery(jQuery(this).find(".oneProv")).each(function (index, e)
		{
			if (!jQuery(e).hasClass('displayNone'))
			{//
				jQuery(e).find('.listWord').html(i);
				jQuery(e).find('.delProov').attr('data-num', i);
				jQuery(e).find('.delProov').attr('data-id', id);
				jQuery(e).attr('class', 'row nomar oneProv proovNum'+i);
				jQuery('.donorNum'+donorid+' .hiddenFields').prepend('<input type="hidden" class="proovInpList'+id+'" name="form_proov_'+id+'_num'+i+'" value="'+jQuery(e).find('.stopWord').attr('data-text').trim()+'">');
			i++;
			}
		});
		jQuery('.donorNum'+donorid+' .provInput'+id+' .proovCount').html(i - 1);
		
	});
}


jQuery('*').on( "click", ".sendAjax", function()
{
	var data = jQuery(this).data();

	if (data['type'] == "form")
	{
		data['params'] = jQuery('.'+data['form']).serializeArray();
		if (data['valid'] && !valid_form(data['params']))
			error_valid();
	} 
	else
	{
		if (jQuery(this).hasClass("alertAjax"))
		{
			if (confirm(data['alert']))
				myAjax(data);
		} else
			myAjax(data);
	}
	return false;
}).on( "click", ".sendAvatar", function()
{
	var data = jQuery(this).data();
	if (data['file'] == 1)
	{	
		var files = new FormData(); var stp; var noAjax = false; var count_p = 0;
		jQuery.each(data, function(key, val) {if (key != 'ajax') files.append(key, val);});
		files.append("ajax", 1);
		files.append("type", "avatarUpload");
		var valid;
		jQuery.each(jQuery("."+data['fileclass'])[0].files, function(i, file) {files.append('file-'+i, file); if ((valid = valid_file(file))){alert(valid); stp = true;}});
		jQuery('.'+data.fileclass).val("").removeClass("sendAvatar");
		if (!stp) {jQuery('.bg_load_avatar').addClass('active'); ft_FileAjax(files);}
	}
//}).on("click", ".catBtnT", function()
//{
//	//jQuery(".categoryList").toggleClass('active');
//
}).on("click", ".errorsBlock", function()
{
	var data = jQuery(this).data();
	jQuery('.wrap_alert.'+data.id).slideUp(300);
	jQuery('.wrap_alert.'+data.id).addClass('myHide');
	setTimeout(function() {
		jQuery('.wrap_alert.'+data.id).remove();
	}, 300);
}).on( "change", ".switch.statusGroundBt", function()
{
	if (jQuery(this).hasClass("disable"))
		return false;
	var v = jQuery(".curWorkStatus input[name=status]").prop('checked')
	if (v)
		jQuery('.curWorkStatus input[name=status]').attr("checked", true);
	else
		jQuery('.curWorkStatus input[name=status]').attr("checked", false);
	jQuery('.curWorkStatus.ar').toggleClass('work');
}).on( "click", ".inputCkeckPosts", function()
{
	var data = jQuery(this).data();
	var i = 0;
	var c = 0;
	jQuery(".checkerList .inputCkeckPosts").each(function()
	{
		if (jQuery(this).hasClass('checked'))
			c++;
		i++;
	});
	if (data.top == 1)
	{
		if (jQuery('.topChecker .inputCkeckPosts').hasClass('checked'))
		{
			jQuery(".topChecker .inputCkeckPosts").removeClass('checked');
			jQuery(".checkerList .inputCkeckPosts").removeClass('checked');
			jQuery(".checkerControl").addClass('off');
		}
		else
		{
			i = 0;
			c = 0;
			jQuery(".checkerList .inputCkeckPosts").each(function()
			{
				if (i < 50)
					jQuery(this).addClass('checked');
				i++;
			});
			jQuery(".topChecker .inputCkeckPosts").addClass('checked');
			//jQuery(".checkerList .inputCkeckPosts").addClass('checked');
			jQuery(".checkerControl").removeClass('off');
		}
	} else if (c < 50) jQuery(this).toggleClass('checked'); else if (c >= 50) jQuery(this).removeClass('checked');
	
	i = 0;
	c = 0;
	jQuery(".checkerList .inputCkeckPosts").each(function()
	{
		if (jQuery(this).hasClass('checked'))
			c++;
		i++;
	});
	if (c == 0)
		jQuery(".checkerControl").addClass('off');
	else
		jQuery(".checkerControl").removeClass('off');
		
}).on( "click", ".inputCkeckBtn", function()
{

	var data = jQuery(this).data();
	
	if (data.top == 1 && data.cid)
	{
		var i = 0;
		var c = 0;
		var u = 0;
		//console.log(".clientBlock.c"+data.cid+" .donListC .inputCkeckBtn");
		jQuery(".clientBlock.c"+data.cid+" .inputCkeckBtn").each(function ()
		{
			
			if (!jQuery(this).hasClass('displayNone'))
			{
				if (jQuery(this).hasClass('checked'))
					c++;
				i++;
			}
		});
		if (i == c)
		{
			if (!jQuery('.clientBlock.c'+data.cid+' .vievBtn.hideB').hasClass('displayNone') && !jQuery('.clientBlock.c'+data.cid).hasClass('openedList'))
			{
				jQuery('.clientBlock.c'+data.cid+' .showBtn').click();
				jQuery('.clientBlock.c'+data.cid).removeClass('openedList');
			}
			jQuery(".clientBlock.c"+data.cid+" .inputCkeckBtn").removeClass('checked');
		}
		else
		{
			if (jQuery('.clientBlock.c'+data.cid+' .vievBtn.hideB').hasClass('displayNone') && !jQuery('.clientBlock.c'+data.cid).hasClass('openedList'))
			{
				jQuery('.clientBlock.c'+data.cid+' .showBtn').click();
				jQuery('.clientBlock.c'+data.cid).removeClass('openedList');
			}
			jQuery(".clientBlock.c"+data.cid+" .inputCkeckBtn").addClass('checked');
		}
	} else {
		if (data.toggleoff != 1)
			jQuery(this).toggleClass('checked');
	}
	if (data.cid)
		disable_sel(data.cid);
}).on( "click", ".showBtn", function()
{
	var data = jQuery(this).data();
	jQuery('.clientBlock.c'+data.id).toggleClass('openedList');
	jQuery('.clientBlock.c'+data.id+' .donorList .slideMeBack').toggleClass('displayNone');
	jQuery('.clientBlock.c'+data.id+' .vievBtn.hideB').toggleClass('displayNone');
	jQuery('.clientBlock.c'+data.id+' .vievBtn.viewB').toggleClass('displayNone');
}).on( "click", ".myCheckBox", function()
{
	if (jQuery(this).hasClass("disable"))
		return false;
		
	var val = 0;
	jQuery(this).toggleClass("checked");
	
	if (jQuery(this).hasClass("checked"))
		val = 1;
	jQuery(this).find("input").val(val);
}).on("click", ".delProov", function()
{
	var data = jQuery(this).data();
	jQuery('.provInput'+data.id+' .proovNum'+data.num).addClass('displayNone');
	//jQuery('.proovInpList'+data.id).remove();
	update_num(data.donorid);

}).on("change", ".selectGroundL", function()
{

  console.log(1);

}).on("click", ".selectGroundL", function()
{
	jQuery(this).change();

})
.on("change", ".switchSet", function()
   {
	jQuery('.vkSoc').toggleClass('displayNone');
});