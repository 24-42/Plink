<?php
$PLUGIN_CONFIG = array(
	'core'				=> 'https://api.plink.top/',
	'http'				=> 'https://plink.top',
	'maxDownloadImages' => 20,
	'api' 				=> 'https://plink.top/api.php',
	'social_time' 		=> 1728,
	'time_file' 		=> '/wp-content/plugins/plink/resources/social.txt',
	'social_img_bg' 	=> '/wp-content/plugins/plink/resources/image/black.jpg',
	'badFavicon'		=> '/wp-content/plugins/plink/admin/img/blank.png',
	'cronPostsId' 		=> '/wp-content/plugins/plink/resources/tmp/id.php',
	'logo_for_wp' 		=> '/wp-content/plugins/plink/resources/image/logo_for_WP.svg',
	'metadata' 			=> 'https://plink.top/download/plink.json',
	'fonts' 			=> array(
		'/wp-content/plugins/plink/resources/fonts/Montserrat-Medium.ttf',
        '/wp-content/plugins/plink/resources/fonts/OpenSans-SemiBold.ttf',
        '/wp-content/plugins/plink/resources/fonts/OpenSansCondensed-Bold.ttf',
        '/wp-content/plugins/plink/resources/fonts/Roboto-Medium.ttf',
        '/wp-content/plugins/plink/resources/fonts/RobotoCondensed-Bold.ttf'
	),
	'catalog_page_lim'	=> 40,
	"donorStatusList"	=> array(
		1 				=> array('action' => 1, 'status' => 'Активен', 'class' => 'workStatus'),
		2				=> array('action' => 2, 'status' => 'Остановлен', 'class' => 'offlineStatus'),
		3				=> array('action' => 3, 'status' => 'Удален', 'class' => 'offlineStatus'),
		4				=> array('action' => 4, 'status' => 'На модерации', 'class' => 'moderStatus'),
		5				=> array('action' => 5, 'status' => 'Отклонен', 'class' => 'badStatus')
	)
);
