<?php
/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://plink.top
 * @since             1.0.0
 * @package           Plink
 *
 * @wordpress-plugin
 * Plugin Name:       Plink
 * Plugin URI:        https://plink.top
 * Description:       Парсер статей и новостей из различных источников
 * Version:           1.0.2
 * Author:            Plink
 * Author URI:        https://plink.top
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       Plink
 * Domain Path:       /languages
 */

if (!defined('PLINK_VERSION'))
    define('PLINK_VERSION', '1.0.2');

if (isset($_POST['ajax']) && $_POST['ajax'] == 1)
{
	require($_SERVER['DOCUMENT_ROOT'].'/wp-blog-header.php' );
	header("HTTP/1.1 200 OK");
}
error_reporting(0); //E_ALL
define('PATH_TO_CONFIG', plugin_dir_path( __FILE__ ) . '/include/config.php');
define('PATH_TO_SITE', $_SERVER['DOCUMENT_ROOT']);
if (!defined('PATH_TO_TMP'))
    define('PATH_TO_TMP', $_SERVER['DOCUMENT_ROOT'].'/wp-content/uploads/tmp/');
date_default_timezone_set('Europe/Moscow');

require_once(plugin_dir_path( __FILE__ ) . '/include/secure.php');
require_once(plugin_dir_path( __FILE__ ) . '/include/plink_config.php');
require_once(plugin_dir_path( __FILE__ ) . '/include/config.php');
require_once(plugin_dir_path( __FILE__ ) . '/include/simple_html_dom.php');
require_once(plugin_dir_path( __FILE__ ) . '/class/sys.class.php');
require_once(plugin_dir_path( __FILE__ ) . '/class/api.class.php');
require_once(plugin_dir_path( __FILE__ ) . '/class/plink.class.php');
require_once(plugin_dir_path( __FILE__ ) . '/class/add.class.php');
require_once(plugin_dir_path( __FILE__ ) . '/class/user.class.php');
require_once(plugin_dir_path( __FILE__ ) . '/class/donor.class.php');
require_once(plugin_dir_path( __FILE__ ) . '/class/ground.class.php');
require_once(plugin_dir_path( __FILE__ ) . '/admin/admin.class.php');
require_once(plugin_dir_path( __FILE__ ) . '/class/loader.class.php');
require_once(plugin_dir_path( __FILE__ ) . '/class/cron.class.php');
require_once(plugin_dir_path( __FILE__ ) . '/class/img.class.php');
require_once(plugin_dir_path( __FILE__ ) . '/class/apivk.class.php');
require(plugin_dir_path( __FILE__ ).'/include/checkUpdate/plugin-update-checker.php');

if (isset($_POST['ajax']) && $_POST['ajax'] == 1)
{
	require_once(plugin_dir_path( __FILE__ ) . '/admin/ajax.php');
	exit();
}

function activate_Plink(){
	sys::activate_plugin();
}

function deactivate_Plink(){
	sys::deactivate_plugin();
}

register_activation_hook( __FILE__, 'activate_Plink' );
register_deactivation_hook( __FILE__, 'deactivate_Plink' );


function run_plugin(){
	global $PLINK_CONFIG;
	
	$plugin = new plink();
	$plugin->initCron();
	$plugin->initCheckConfigCron();
	$plugin->checkUpdate();
	$plugin->run();
   
}
$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
	'https://plink.top/download/plink.json',
	__FILE__, //Full path to the main plugin file or functions.php.
	'plink'
);
run_plugin();
?>
